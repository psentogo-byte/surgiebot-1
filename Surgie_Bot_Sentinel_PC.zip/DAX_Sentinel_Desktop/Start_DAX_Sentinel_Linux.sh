#!/bin/bash
cd "$(dirname "$0")"
python3 dax_sentinel_desktop.py
