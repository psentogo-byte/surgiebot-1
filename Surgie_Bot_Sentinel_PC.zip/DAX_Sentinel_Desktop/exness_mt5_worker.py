#!/usr/bin/env python3
"""
Standalone Exness MT5 Python Bridge Worker (Windows + Exness MetaTrader 5 Desktop)
Requires: Python 3.10-3.12 (64-bit) + pip install MetaTrader5 requests
Run alongside your logged-in Exness MT5 Terminal.
"""
import sys
import time
import requests
import MetaTrader5 as mt5

SERVER_URL = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8765"
DAX_CANDIDATES = ["DE30m", "DE30", "GER40m", "GER40", "DE40m", "DE40"]
GOLD_CANDIDATES = ["XAUUSDm", "XAUUSD", "XAUUSDc", "GOLD"]
BTC_CANDIDATES = ["BTCUSDm", "BTCUSD", "BTCUSDc"]


def pick_symbol(candidates):
    for s in candidates:
        info = mt5.symbol_info(s)
        if info is not None:
            mt5.symbol_select(s, True)
            return s
    return candidates[0]


def resolve_symbol(req_sym, dax_sym, gold_sym, btc_sym):
    u = (req_sym or "").upper()
    if any(k in u for k in ("DE30", "DE40", "GER", "DAX")):
        return dax_sym
    if any(k in u for k in ("XAU", "GOLD")):
        return gold_sym
    if "BTC" in u:
        return btc_sym
    return req_sym or gold_sym


def filling_mode_for(sym):
    info = mt5.symbol_info(sym)
    if info is not None:
        fm = info.filling_mode
        if fm & 2:
            return mt5.ORDER_FILLING_IOC
        if fm & 1:
            return mt5.ORDER_FILLING_FOK
    return mt5.ORDER_FILLING_RETURN


def main():
    if not mt5.initialize():
        raise RuntimeError(f"MT5 initialize() failed: {mt5.last_error()}")
    dax_sym = pick_symbol(DAX_CANDIDATES)
    gold_sym = pick_symbol(GOLD_CANDIDATES)
    btc_sym = pick_symbol(BTC_CANDIDATES)
    print(f"Connected to Exness MT5 | Server={SERVER_URL} | DAX={dax_sym} | GOLD={gold_sym} | BTC={btc_sym}")

    try:
        while True:
            acct = mt5.account_info()
            d_tick = mt5.symbol_info_tick(dax_sym)
            g_tick = mt5.symbol_info_tick(gold_sym)
            b_tick = mt5.symbol_info_tick(btc_sym)
            payload = {
                "login": acct.login if acct else None,
                "server": acct.server if acct else "",
                "balance": acct.balance if acct else None,
                "equity": acct.equity if acct else None,
                "dax_spread": round(d_tick.ask - d_tick.bid, 2) if d_tick else None,
                "gold_spread": round(g_tick.ask - g_tick.bid, 2) if g_tick else None,
                "btc_spread": round(b_tick.ask - b_tick.bid, 2) if b_tick else None,
            }
            try:
                requests.post(f"{SERVER_URL}/api/bot/mt5-report", json=payload, timeout=3)
                cmds = requests.get(f"{SERVER_URL}/api/bot/bridge/poll", timeout=3).json().get("commands", [])
                for c in cmds:
                    sym = resolve_symbol(c.get("symbol"), dax_sym, gold_sym, btc_sym)
                    mt5.symbol_select(sym, True)
                    tick = mt5.symbol_info_tick(sym)
                    if not tick:
                        print("No tick for", sym)
                        continue
                    fill_mode = filling_mode_for(sym)
                    ctype = c["type"]
                    if ctype == "PLACE_MARKET":
                        is_buy = c["direction"] == "LONG"
                        req = {
                            "action": mt5.TRADE_ACTION_DEAL,
                            "symbol": sym,
                            "volume": float(c["lots"]),
                            "type": mt5.ORDER_TYPE_BUY if is_buy else mt5.ORDER_TYPE_SELL,
                            "price": tick.ask if is_buy else tick.bid,
                            "sl": float(c["sl"]),
                            "tp": float(c["tp2"]),
                            "deviation": 30,
                            "comment": c.get("order_id", "SMC_BOT"),
                            "type_filling": fill_mode,
                        }
                        print("MT5 Market:", mt5.order_send(req))
                    elif ctype == "PLACE_LIMIT":
                        is_buy = c["direction"] == "LONG"
                        req = {
                            "action": mt5.TRADE_ACTION_PENDING,
                            "symbol": sym,
                            "volume": float(c["lots"]),
                            "type": mt5.ORDER_TYPE_BUY_LIMIT if is_buy else mt5.ORDER_TYPE_SELL_LIMIT,
                            "price": float(c["price"]),
                            "sl": float(c["sl"]),
                            "tp": float(c["tp2"]),
                            "comment": c.get("order_id", "SMC_BOT"),
                            "type_time": mt5.ORDER_TIME_DAY,
                        }
                        print("MT5 Limit:", mt5.order_send(req))
                    elif ctype == "MODIFY_SL":
                        for pos in mt5.positions_get(symbol=sym) or []:
                            mt5.order_send({"action": mt5.TRADE_ACTION_SLTP, "position": pos.ticket, "symbol": sym, "sl": float(c["sl"]), "tp": float(c["tp"])})
                    elif ctype in ("PARTIAL_CLOSE", "CLOSE_POSITION"):
                        for pos in mt5.positions_get(symbol=sym) or []:
                            vol = float(c.get("lots", pos.volume)) if ctype == "PARTIAL_CLOSE" else pos.volume
                            is_buy = pos.type == mt5.POSITION_TYPE_BUY
                            mt5.order_send({
                                "action": mt5.TRADE_ACTION_DEAL, "position": pos.ticket, "symbol": sym,
                                "volume": min(vol, pos.volume),
                                "type": mt5.ORDER_TYPE_SELL if is_buy else mt5.ORDER_TYPE_BUY,
                                "price": tick.bid if is_buy else tick.ask, "deviation": 30,
                                "type_filling": fill_mode,
                            })
                    elif ctype == "CANCEL_ORDER":
                        for od in mt5.orders_get(symbol=sym) or []:
                            mt5.order_send({"action": mt5.TRADE_ACTION_REMOVE, "order": od.ticket})
            except Exception as e:
                print("Bridge error:", e)
            time.sleep(2)
    finally:
        mt5.shutdown()


if __name__ == "__main__":
    main()
