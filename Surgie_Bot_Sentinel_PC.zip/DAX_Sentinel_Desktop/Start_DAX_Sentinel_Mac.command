#!/bin/bash
cd "$(dirname "$0")"
if command -v python3 >/dev/null 2>&1; then
  python3 dax_sentinel_desktop.py
else
  echo "Python 3 is required. Installing via Xcode Command Line Tools or visit https://www.python.org/downloads/"
  read -p "Press Enter to exit..."
fi
