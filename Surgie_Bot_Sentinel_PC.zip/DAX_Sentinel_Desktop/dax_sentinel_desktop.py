#!/usr/bin/env python3
"""
DAX Fundamental Sentinel v6.0 (High-Win-Rate SMC Edition) — Standalone Desktop App (Python 3 Stdlib Only)
Zero external packages required. Double-click the launcher or run:
    python3 dax_sentinel_desktop.py
Automatically starts a local server on 127.0.0.1 and opens your default browser.
"""

import email.utils
import hashlib
import html as html_lib
import json
import os
import re
import socket
import threading
import time
import urllib.parse
import urllib.request
import webbrowser
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from html.parser import HTMLParser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# ==============================================================================
# 1. BILINGUAL (EN + DE) CONTRAST-AWARE DAX SENTIMENT ENGINE
# ==============================================================================

CHANNEL_RULES = {
    "dax_bluechips": {
        "label": "DAX Blue Chips & Earnings",
        "impact_type": "direct",
        "keywords": [
            "sap", "siemens", "allianz", "airbus", "deutsche telekom", "munich re", "münchener rück",
            "volkswagen", "vw ", "mercedes", "bmw", "porsche", "basf", "bayer",
            "deutsche bank", "commerzbank", "infineon", "rheinmetall", "adidas",
            "rwe", "e.on", "eon", "beiersdorf", "henkel", "continental", "fresenius",
            "hannover re", "hannover rück", "symrise", "zalando", "vonovia",
            "heidelberg materials", "daimler", "mtu aero", "qiagen", "sartorius",
            "brenntag", "merck kgaa", "dax 40", "dax40", "dax index", "dax ",
            "frankfurt stocks", "gdaxi", "leitindex", "aktie", "aktien", "quartalszahlen",
            "geschäftszahlen", "gewinnwarnung", "dividende", "börse frankfurt"
        ],
    },
    "german_macro": {
        "label": "German Macro & Politics",
        "impact_type": "direct",
        "keywords": [
            "germany", "german ", "deutschland", "deutsche ", "deutschen ", "bundesbank",
            "ifo ", "ifo-", "zew ", "zew-", "destatis", "statistisches bundesamt",
            "berlin", "bundestag", "bundesrat", "scholz", "merz", "debt brake", "schuldenbremse",
            "bund ", "bunds", "bundesanleihe", "german gdp", "bip ", "konjunktur",
            "wirtschaftswachstum", "german inflation", "verbraucherpreise", "german pmi",
            "einkaufsmanagerindex", "factory orders", "auftragseingang", "industrial production",
            "industrieproduktion", "german exports", "exporte", "german retail",
            "arbeitsmarkt", "arbeitslos", "kiel institute", "ifw ", "diw ", "sachverständigenrat"
        ],
    },
    "ecb_rates": {
        "label": "ECB & Eurozone Rates",
        "impact_type": "indirect",
        "keywords": [
            "ecb", "ezb", "european central bank", "europäische zentralbank", "lagarde",
            "eurozone", "euro area", "euroraum", "eur/usd", "eurusd", "euro falls",
            "euro rises", "euro gains", "euro weakens", "euro-kurs", "deposit rate",
            "leitzins", "zinssatz", "zinssenkung", "zinswende", "zinspause", "monetary policy",
            "geldpolitik", "governing council", "ezb-rat", "eu inflation", "hicp",
            "teuerung", "schnabel", "nagel", "lane ", "villeroy"
        ],
    },
    "trade_tariffs": {
        "label": "Trade, Tariffs & Autos",
        "impact_type": "indirect",
        "keywords": [
            "tariff", "tariffs", "zoll", "zölle", "strafzölle", "trade war", "handelskrieg",
            "trade dispute", "handelsstreit", "export", "import duty", "eu-china", "us-eu",
            "china economy", "chinas wirtschaft", "chinese demand", "ev tariffs",
            "electric vehicle", "elektroauto", "auto sector", "autobauer", "autoindustrie",
            "carmaker", "automaker", "wto", "sanctions", "sanktionen", "supply chain", "lieferketten"
        ],
    },
    "energy_commodities": {
        "label": "Energy & Commodities",
        "impact_type": "indirect",
        "keywords": [
            "natural gas", "erdgas", "gaspreis", "ttf", "oil price", "ölpreis", "brent",
            "wti", "crude oil", "rohöl", "opec", "energy crisis", "energiekrise",
            "gas storage", "gasspeicher", "electricity price", "strompreis", "energiepreise",
            "lng", "nord stream", "pipeline", "energy costs", "energiekosten"
        ],
    },
    "global_us": {
        "label": "US Fed & Global Markets",
        "impact_type": "indirect",
        "keywords": [
            "fed", "federal reserve", "powell", "fomc", "wall street", "s&p 500",
            "nasdaq", "dow jones", "us-börse", "us-börsen", "us cpi", "us-inflation",
            "nonfarm payrolls", "us-arbeitsmarkt", "treasury yield", "us-rendite",
            "global growth", "weltwirtschaft", "imf", "iwf", "world bank", "geopolitical",
            "geopolitik", "middle east", "nahost", "ukraine", "risk-off", "risk appetite",
            "tech rout", "goldpreis", "abverkauf"
        ],
    },
}

SECTOR_KEYWORDS = {
    "Autos": ["volkswagen", "vw ", "mercedes", "bmw", "porsche", "auto", "autobauer", "carmaker", "automaker", "ev ", "tariff", "zölle"],
    "Tech & Semis": ["sap", "infineon", "ai ", "ki ", "tech", "software", "chip", "semiconductor", "halbleiter", "nasdaq"],
    "Industrials & Defense": ["siemens", "airbus", "rheinmetall", "thyssenkrupp", "rüstung", "manufacturing", "pmi", "factory orders", "defense", "industrial", "maschinenbau"],
    "Financials": ["allianz", "munich re", "münchener rück", "deutsche bank", "commerzbank", "hannover re", "bank", "banken", "insurer", "versicherung", "yield", "ecb", "ezb", "zins"],
    "Chemicals & Energy": ["basf", "bayer", "brenntag", "rwe", "e.on", "chemie", "natural gas", "erdgas", "oil", "öl", "crude", "energy", "energie"],
    "Consumer & Healthcare": ["adidas", "zalando", "henkel", "beiersdorf", "fresenius", "merck", "retail", "einzelhandel", "consumer", "konsum", "pharma"],
}

# --- Bilingual DAX-Specific Financial Lexicon ---
BULLISH_PHRASES: Dict[str, float] = {
    # English Monetary / Macro
    "rate cut": 0.72, "cuts interest rates": 0.80, "cut interest rates": 0.80,
    "cut rates": 0.75, "cuts rates": 0.75, "rate cuts": 0.70, "dovish": 0.65,
    "easing cycle": 0.65, "stimulus": 0.65, "fiscal stimulus": 0.72,
    "stimulus package": 0.72, "debt brake reform": 0.65, "spending boost": 0.62,
    "defense spending": 0.55, "rate cut expectations": 0.65, "signals rate cut": 0.72,
    "inflation cools": 0.68, "inflation slows": 0.65, "inflation eases": 0.68,
    "cooling inflation": 0.68, "disinflation": 0.55, "inflation falls": 0.65,
    "inflation drops": 0.65, "soft landing": 0.60, "avoid recession": 0.55,
    # English Corporate / Market
    "beats expectations": 0.75, "beat expectations": 0.75, "top estimates": 0.72,
    "beats estimates": 0.72, "earnings beat": 0.75, "stronger than expected": 0.70,
    "better than expected": 0.70, "raises guidance": 0.80, "raised guidance": 0.80,
    "raises outlook": 0.75, "upgrades outlook": 0.75, "lifts outlook": 0.74,
    "profit jump": 0.70, "record high": 0.68, "all-time high": 0.70,
    "rebound": 0.55, "rebounds": 0.55, "rallies": 0.65, "rally": 0.60,
    "surges": 0.58, "soars": 0.60, "jumps": 0.55, "gains": 0.45,
    "climbs": 0.48, "advances": 0.45, "recovery": 0.55, "recovers": 0.55,
    "stabilizes": 0.40, "growth accelerates": 0.65, "strong orders": 0.62,
    "buyback": 0.55, "share buyback": 0.60, "dividend hike": 0.60,
    "trade deal": 0.70, "tariff pause": 0.72, "tariff relief": 0.75,
    "ceasefire": 0.65, "oil drops": 0.48, "oil falls": 0.45,
    "gas prices fall": 0.65, "energy prices fall": 0.65,
    "confidence rises": 0.62, "ifo rises": 0.72, "zew rises": 0.70,
    "pmi rises": 0.68, "improving eurozone": 0.58,
    # German Bullish Phrases
    "zinssenkung": 0.75, "leitzins sinkt": 0.75, "konjunkturpaket": 0.72,
    "inflation sinkt": 0.68, "inflation geht zurück": 0.68, "teuerung lässt nach": 0.68,
    "besser als erwartet": 0.72, "übertrifft erwartungen": 0.75, "erwartungen übertroffen": 0.75,
    "prognose angehoben": 0.80, "hebt ausblick": 0.78, "ausblick angehoben": 0.78,
    "gewinnsprung": 0.72, "rekordhoch": 0.70, "allzeithoch": 0.72,
    "erholt sich": 0.55, "erholung": 0.55, "kursrally": 0.65, "rallye": 0.62,
    "im plus": 0.48, "legt zu": 0.48, "legen zu": 0.48, "klettert": 0.48,
    "steigt über": 0.50, "aufwärts": 0.45, "starke zahlen": 0.68,
    "aktienrückkauf": 0.60, "dividende erhöht": 0.60, "kaufempfehlung": 0.58,
    "ifo steigt": 0.72, "zew steigt": 0.70, "wirtschaft wächst": 0.65,
    "aufschwung": 0.62, "rüstungsausgaben": 0.52, "gaspreis sinkt": 0.62,
}

BEARISH_PHRASES: Dict[str, float] = {
    # English Monetary / Macro
    "rate hike": -0.75, "raises interest rates": -0.80, "raise interest rates": -0.80,
    "hike rates": -0.75, "hikes rates": -0.75, "hawkish": -0.65,
    "higher for longer": -0.62, "inflation surges": -0.72,
    "inflation accelerates": -0.70, "inflation jumps": -0.70,
    "inflation pressures": -0.65, "energy inflation": -0.68,
    "stay elevated": -0.58, "stays elevated": -0.58, "remains elevated": -0.58,
    "pause rate cuts": -0.65, "delay rate cuts": -0.65, "yields surge": -0.60,
    "hotter inflation": -0.68, "sticky inflation": -0.60, "stagflation": -0.85,
    "recession": -0.82, "contraction": -0.72, "contracts": -0.65, "shrinks": -0.65,
    # English Corporate / Market
    "earnings miss": -0.75, "guidance cut": -0.80, "misses expectations": -0.75,
    "missed expectations": -0.75, "misses estimates": -0.72,
    "weaker than expected": -0.70, "worse than expected": -0.72,
    "profit warning": -0.88, "cuts guidance": -0.82, "slashes outlook": -0.82,
    "lowers forecast": -0.72, "downgrades": -0.60, "downgrade": -0.58,
    "layoffs": -0.60, "job cuts": -0.62, "plant closure": -0.72, "strikes": -0.50,
    "tariff": -0.55, "tariffs": -0.60, "trade war": -0.78, "import duties": -0.62,
    "retaliatory": -0.65, "sanctions": -0.55, "oil surges": -0.62,
    "oil spikes": -0.65, "gas prices surge": -0.75, "energy crisis": -0.80,
    "sell-off": -0.72, "selloff": -0.72, "rout": -0.75, "plunge": -0.72,
    "plunges": -0.72, "slumps": -0.68, "tumbles": -0.68, "drops": -0.48,
    "falls": -0.45, "slides": -0.52, "steepest weekly drop": -0.75,
    "declines": -0.48, "retreats": -0.45, "losses": -0.52,
    "turmoil": -0.68, "crisis": -0.72, "scandal": -0.65, "default": -0.75,
    "slowdown": -0.60, "sluggish": -0.55, "stagnation": -0.68, "headwinds": -0.55,
    "weak demand": -0.68, "china slowdown": -0.70, "bearish": -0.65,
    "ifo falls": -0.72, "zew falls": -0.70, "pmi falls": -0.68,
    "geopolitical tension": -0.60, "escalation": -0.65, "supply disruption": -0.62,
    # German Bearish Phrases
    "zinserhöhung": -0.78, "zinsen steigen": -0.68, "inflation steigt": -0.70,
    "teuerung zieht an": -0.68, "rezession": -0.82, "wirtschaft schrumpft": -0.75,
    "konjunkturschwäche": -0.68, "abschwung": -0.65, "stagnation": -0.65,
    "gewinnwarnung": -0.88, "prognose gesenkt": -0.82, "senkt ausblick": -0.80,
    "ausblick gesenkt": -0.80, "gewinn bricht ein": -0.78, "umsatzrückgang": -0.65,
    "schlechter als erwartet": -0.72, "enttäuscht": -0.62, "verfehlt erwartungen": -0.74,
    "stellenabbau": -0.65, "streicht stellen": -0.65, "werksschließung": -0.72,
    "kurssturz": -0.78, "stürzt ab": -0.75, "bricht ein": -0.75, "abverkauf": -0.75,
    "im minus": -0.48, "unter druck": -0.52, "rutscht ab": -0.58, "verliert": -0.45,
    "talfahrt": -0.70, "schlusslicht": -0.45, "handelskrieg": -0.78, "strafzölle": -0.68,
    "zölle": -0.55, "energiekrise": -0.80, "ölpreis steigt": -0.58,
    "gaspreis steigt": -0.70, "ifo fällt": -0.72, "zew fällt": -0.70,
}

SINGLE_BULLISH_WORDS = {
    "rally": 0.45, "bullish": 0.55, "surge": 0.42, "soar": 0.45, "boom": 0.45,
    "strong": 0.30, "resilient": 0.38, "outperforms": 0.45, "upbeat": 0.45,
    "optimistic": 0.42, "tailwind": 0.45, "tailwinds": 0.45, "growth": 0.25,
    "profit": 0.25, "profits": 0.25, "beats": 0.48, "easing": 0.38, "stimulus": 0.50,
    "rebound": 0.42, "recovery": 0.40, "boost": 0.40, "boosts": 0.40,
    "positively": 0.48, "positive": 0.35, "optimism": 0.45, "improves": 0.42, "improving": 0.38,
    # German singles
    "stark": 0.32, "wachstum": 0.30, "gewinn": 0.28, "gewinne": 0.32, "zuversicht": 0.45,
    "optimismus": 0.45, "aufschwung": 0.50, "steigt": 0.25, "positiv": 0.35, "rückenwind": 0.45,
}

SINGLE_BEARISH_WORDS = {
    "slump": -0.50, "plunge": -0.55, "crash": -0.65, "rout": -0.58, "tumble": -0.52,
    "weak": -0.35, "weakness": -0.38, "slowing": -0.38, "slows": -0.35, "shrink": -0.48,
    "threat": -0.38, "risk": -0.25, "risks": -0.25, "deficit": -0.32, "debt": -0.22,
    "cut": -0.20, "cuts": -0.25, "loss": -0.40, "warning": -0.50, "trouble": -0.45,
    "troubled": -0.45, "concern": -0.32, "concerns": -0.35, "pressure": -0.32,
    "strain": -0.38, "drag": -0.40, "drags": -0.40, "fades": -0.38, "pain": -0.45,
    "warns": -0.38, "warned": -0.35, "elevated": -0.25, "fear": -0.42, "fears": -0.45,
    # German singles
    "schwach": -0.42, "schwäche": -0.42, "verlust": -0.45, "verluste": -0.48,
    "warnung": -0.50, "warnt": -0.40, "krise": -0.60, "druck": -0.32, "sorge": -0.38,
    "sorgen": -0.40, "rückgang": -0.45, "einbruch": -0.62, "flaute": -0.52,
    "risiko": -0.28, "risiken": -0.28, "gegenwind": -0.45, "schrumpft": -0.55,
}

NEGATIONS = {
    "not", "no", "never", "unlikely", "fails", "failed", "without", "less", "avoids", "avoid",
    "nicht", "kein", "keine", "ohne", "kaum", "vermeidet",
}

CONTRAST_MARKERS = re.compile(
    r"\b(?:despite|even as|although|though|while|trotz|obwohl|obgleich)\b",
    re.IGNORECASE,
)

GERMAN_HINT_WORDS = {
    "der", "die", "das", "und", "mit", "für", "auf", "bei", "nach", "von",
    "aus", "aktie", "aktien", "börse", "ezb", "zinsen", "wirtschaft", "kurssturz",
    "unter", "über", "steigt", "fällt", "sinkt", "deutschland"
}


def _clean_text(text: str) -> str:
    text = html_lib.unescape(text or "")
    text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def detect_language(title: str, summary: str = "") -> str:
    tokens = set(re.findall(r"[a-zäöüß]+", f"{title} {summary}".lower()))
    de_hits = len(tokens & GERMAN_HINT_WORDS)
    has_umlaut = any(ch in f"{title}{summary}".lower() for ch in "äöüß")
    return "DE" if (de_hits >= 2 or (has_umlaut and de_hits >= 1)) else "EN"


def is_relevant_to_dax(title: str, summary: str = "") -> bool:
    combined = f" {title.lower()} {summary.lower()} "
    for cfg in CHANNEL_RULES.values():
        if any(kw in combined for kw in cfg["keywords"]):
            return True
    broad_macro_terms = [
        "europe", "european", "europa", "europäisch", "frankfurt", "stoxx", "euro",
        "inflation", "gdp", "bip", "interest rate", "leitzins", "central bank",
        "zentralbank", "bond", "anleihe", "yield", "rendite", "stock market",
        "aktienmarkt", "equities", "tariff", "zölle", "trade", "handel", "oil",
        "öl", "gas", "energy", "energie", "recession", "rezession", "economy",
        "wirtschaft", "pmi", "earnings", "quartalszahlen", "manufacturing", "exports"
    ]
    return any(t in combined for t in broad_macro_terms)


def classify_channel_and_sectors(title: str, summary: str, feed_category: str = "") -> Tuple[str, str, str, List[str]]:
    combined = f" {title.lower()} {summary.lower()} "
    scores: Dict[str, int] = {}
    for key, cfg in CHANNEL_RULES.items():
        hits = sum(1 for kw in cfg["keywords"] if kw in combined)
        if hits > 0:
            scores[key] = hits
    if scores:
        best_key = max(
            scores.keys(),
            key=lambda k: (scores[k], 1 if CHANNEL_RULES[k]["impact_type"] == "direct" else 0)
        )
    elif feed_category in CHANNEL_RULES:
        best_key = feed_category
    else:
        best_key = "global_us"

    cfg = CHANNEL_RULES[best_key]
    sectors = [sec for sec, kws in SECTOR_KEYWORDS.items() if any(kw in combined for kw in kws)]
    if not sectors:
        sectors = ["Broad DAX 40"]
    return best_key, cfg["label"], cfg["impact_type"], sectors[:3]


def _build_transmission_note(
    channel_key: str, sentiment_label: str, sectors: List[str], combined_lower: str, lang: str
) -> str:
    sector_str = ", ".join(sectors)
    lang_tag = "[DE Primary] " if lang == "DE" else ""
    if channel_key == "dax_bluechips":
        if "Bullish" in sentiment_label:
            return f"{lang_tag}Direct equity catalyst for {sector_str}, lifting heavyweight DAX 40 earnings expectations."
        if "Bearish" in sentiment_label:
            return f"{lang_tag}Direct fundamental drag on {sector_str}, weighing on Frankfurt benchmark sentiment."
        return f"{lang_tag}Direct corporate/index update affecting {sector_str} constituents inside the DAX 40."
    if channel_key == "german_macro":
        if ("inflation" in combined_lower or "teuerung" in combined_lower) and any(
            x in combined_lower for x in ["accelerate", "rise", "hot", "steigt", "zieht an"]
        ):
            return f"{lang_tag}Direct German macro signal: hotter domestic inflation complicates ECB easing and pressures rate-sensitive equities."
        if "Bullish" in sentiment_label:
            return f"{lang_tag}Direct German macro tailwind: stronger domestic activity supports DAX cyclical revenues and confidence."
        if "Bearish" in sentiment_label:
            return f"{lang_tag}Direct German macro headwind: sluggish domestic growth data dampens earnings outlook for German equities."
        return f"{lang_tag}Direct German macroeconomic development influencing domestic growth and fiscal expectations."
    if channel_key == "ecb_rates":
        if any(x in combined_lower for x in ["cut", "dovish", "cooling", "zinssenkung", "sinkt"]):
            return f"{lang_tag}Indirect monetary tailwind: looser ECB rate expectations lower discount rates and support European valuations."
        if any(x in combined_lower for x in ["hike", "hawkish", "surge", "zinserhöhung", "elevated", "steigt"]):
            return f"{lang_tag}Indirect monetary headwind: tighter ECB policy or sticky Eurozone inflation pressures DAX valuation multiples."
        if "eur" in combined_lower and ("weak" in combined_lower or "falls" in combined_lower or "drops" in combined_lower):
            return f"{lang_tag}Indirect FX channel: a softer Euro enhances overseas revenue translation for export-heavy DAX multinationals."
        return f"{lang_tag}Indirect Eurozone monetary/FX channel shaping borrowing costs and DAX exporter competitiveness."
    if channel_key == "trade_tariffs":
        if "Bearish" in sentiment_label or "tariff" in combined_lower or "zöll" in combined_lower:
            return f"{lang_tag}Indirect trade spillover: tariff or external demand friction hits export-reliant DAX sectors ({sector_str})."
        return f"{lang_tag}Indirect trade catalyst: global trade and external demand developments drive earnings for {sector_str}."
    if channel_key == "energy_commodities":
        if "Bearish" in sentiment_label:
            return f"{lang_tag}Indirect cost shock: elevated oil/gas prices squeeze margins across energy-intensive German industrials and chemicals."
        return f"{lang_tag}Indirect input-cost driver: calmer energy prices ease industrial cost pressures and domestic inflation."
    if "Bullish" in sentiment_label:
        return f"{lang_tag}Indirect global risk-on spillover: supportive US/global macro cues boost cross-border equity flows into Frankfurt."
    if "Bearish" in sentiment_label:
        return f"{lang_tag}Indirect global risk-off spillover: Wall Street/Fed or geopolitical stress triggers global de-risking across the DAX."
    return f"{lang_tag}Indirect global macro signal influencing cross-asset risk appetite and institutional flows into European equities."


def _score_clause(clause: str, weight_mult: float, matched_signals: List[str]) -> float:
    padded = f" {clause.lower()} "
    s = 0.0
    for phrase, w in BULLISH_PHRASES.items():
        if phrase in padded:
            s += w * weight_mult
            matched_signals.append(f"+{phrase}")
    for phrase, w in BEARISH_PHRASES.items():
        if phrase in padded:
            s += w * weight_mult
            matched_signals.append(phrase)

    words = re.findall(r"[a-zäöüß]+", padded)
    for idx, w in enumerate(words):
        negated = bool(set(words[max(0, idx - 2):idx]) & NEGATIONS)
        if w in SINGLE_BULLISH_WORDS:
            val = SINGLE_BULLISH_WORDS[w] * weight_mult * 0.75
            s += (-val * 0.6) if negated else val
        elif w in SINGLE_BEARISH_WORDS:
            val = SINGLE_BEARISH_WORDS[w] * weight_mult * 0.75
            s += (-val * 0.6) if negated else val
    return s


def analyze_dax_news(title: str, summary: str = "", feed_category: str = "") -> Dict:
    """
    Clause-aware bilingual (EN + DE) DAX fundamental sentiment & transmission analyzer.
    """
    clean_title = _clean_text(title)
    clean_summary = _clean_text(summary)
    lang = detect_language(clean_title, clean_summary)
    combined = f"{clean_title}. {clean_summary}".strip()
    combined_lower = f" {combined.lower()} "

    channel_key, channel_label, impact_type, sectors = classify_channel_and_sectors(
        clean_title, clean_summary, feed_category
    )

    matched_signals: List[str] = []
    score = 0.0

    # Clause-contrast weighting on headline: outcome clause gets 1.45x, conceded clause after despite/trotz gets 0.55x
    parts = CONTRAST_MARKERS.split(clean_title, maxsplit=1)
    if len(parts) == 2:
        score += _score_clause(parts[0], 1.45, matched_signals)
        score += _score_clause(parts[1], 0.55, matched_signals)
    else:
        score += _score_clause(clean_title, 1.35, matched_signals)

    if clean_summary:
        score += _score_clause(clean_summary, 0.80, matched_signals)

    # Contextual macro overrides
    if ("inflation" in combined_lower or "teuerung" in combined_lower) and (
        "accelerate" in combined_lower or "rebound" in combined_lower or "zieht an" in combined_lower
    ):
        score -= 0.15 if ("growth" in combined_lower or "wachstum" in combined_lower) else 0.45

    if ("eur/usd" in combined_lower or "euro" in combined_lower) and ("weak" in combined_lower or "falls" in combined_lower):
        if "export" in combined_lower or "improving" in combined_lower:
            score += 0.25

    if any(x in combined_lower for x in ["tech rout", "rout", "kurssturz", "abverkauf"]):
        score -= 0.40

    normalized = int(round(100 * (score / (abs(score) + 1.15)))) if score != 0 else 0
    normalized = max(-98, min(98, normalized))

    if normalized >= 32:
        sentiment_label = "Bullish"
    elif normalized >= 12:
        sentiment_label = "Slightly Bullish"
    elif normalized <= -32:
        sentiment_label = "Bearish"
    elif normalized <= -12:
        sentiment_label = "Slightly Bearish"
    else:
        sentiment_label = "Neutral"

    abs_score = abs(normalized)
    high_impact_terms = [
        "ecb", "ezb", "lagarde", "bundesbank", "ifo", "zew", "cpi", "inflation", "gdp", "bip",
        "tariff", "zölle", "fed", "powell", "dax", "sap", "siemens", "allianz", "volkswagen",
        "airbus", "deutsche bank", "rate cut", "zinssenkung", "rate hike", "zinserhöhung",
        "profit warning", "gewinnwarnung", "recession", "rezession", "kurssturz"
    ]
    term_hits = sum(1 for t in high_impact_terms if t in combined_lower)

    if (impact_type == "direct" and (abs_score >= 28 or term_hits >= 2)) or (abs_score >= 45 and term_hits >= 1):
        impact_level = "High"
    elif abs_score >= 15 or term_hits >= 1 or impact_type == "direct":
        impact_level = "Medium"
    else:
        impact_level = "Low"

    # Deduplicate matched signals preserving order
    unique_signals = list(dict.fromkeys(matched_signals))[:5]

    return {
        "lang": lang,
        "sentiment_score": normalized,
        "sentiment_label": sentiment_label,
        "channel_key": channel_key,
        "channel_label": channel_label,
        "impact_type": impact_type,
        "impact_level": impact_level,
        "sectors": sectors,
        "transmission_note": _build_transmission_note(channel_key, sentiment_label, sectors, combined_lower, lang),
        "signals": unique_signals,
    }


# ==============================================================================
# GOLD (XAU / GC=F) BILINGUAL FUNDAMENTAL SENTIMENT ENGINE
# ==============================================================================

GOLD_CHANNEL_RULES = {
    "gold_fed_yields": {
        "label": "Fed Policy & Real Yields",
        "impact_type": "direct",
        "keywords": [
            "fed", "fomc", "powell", "real yield", "realzins", "treasury", "10-year", "rate cut",
            "rate hike", "zinssenkung", "zinserhöhung", "dovish", "hawkish", "yields", "anleiherenditen",
        ],
    },
    "gold_usd_dxy": {
        "label": "US Dollar (DXY) & FX",
        "impact_type": "direct",
        "keywords": [
            "dollar", "dxy", "greenback", "us-dollar", "currency", "fx", "dollar index",
        ],
    },
    "gold_geopolitics": {
        "label": "Safe-Haven & Geopolitics",
        "impact_type": "indirect",
        "keywords": [
            "safe haven", "safe-haven", "sicherer hafen", "geopolit", "war", "krieg", "conflict",
            "missile", "tariff", "zölle", "crisis", "krise", "uncertainty", "unsicherheit",
        ],
    },
    "gold_central_banks": {
        "label": "Central Bank & ETF Demand",
        "impact_type": "direct",
        "keywords": [
            "central bank", "notenbank", "zentralbank", "pboc", "reserve", "reserven", "etf",
            "inflow", "outflow", "zuflüsse", "abflüsse", "physical demand", "bullion", "wgc",
        ],
    },
    "gold_inflation_macro": {
        "label": "Inflation, CPI & Macro Risk",
        "impact_type": "indirect",
        "keywords": [
            "inflation", "cpi", "pce", "stagflation", "jobs", "payroll", "nfp", "recession",
            "rezession", "debt", "schuld", "deficit", "goldpreis", "xau",
        ],
    },
}

GOLD_BULLISH_PHRASES = {
    "gold rises": 0.9, "gold rallies": 1.0, "gold surges": 1.15, "gold climbs": 0.85, "gold gains": 0.85,
    "gold jumps": 1.0, "gold rebounds": 0.85, "record high": 1.1, "all-time high": 1.15,
    "goldpreis steigt": 0.9, "gold legt zu": 0.85, "rekordhoch": 1.1,
    "safe haven": 0.85, "safe-haven demand": 1.0, "sicherer hafen": 0.85,
    "rate cut": 0.95, "rate cuts": 0.95, "zinssenkung": 0.95, "dovish": 0.85,
    "yields fall": 0.9, "yields drop": 0.9, "dollar weakens": 0.9, "dollar falls": 0.9,
    "weak dollar": 0.85, "schwacher dollar": 0.85, "central bank buying": 1.05,
    "etf inflows": 0.9, "geopolitical tension": 0.8, "stagflation": 0.75,
}

GOLD_BEARISH_PHRASES = {
    "gold falls": -0.9, "gold drops": -0.95, "gold slides": -1.0, "gold tumbles": -1.1, "gold slumps": -1.1,
    "longest slump": -1.1, "gold extends slump": -1.1, "gold retreats": -0.8, "gold sinks": -1.0,
    "goldpreis fällt": -0.9, "gold unter druck": -0.9, "gold verliert": -0.85,
    "rate hike": -0.95, "rate hikes": -0.95, "zinserhöhung": -0.95, "hawkish": -0.85,
    "higher for longer": -0.85, "yields surge": -0.95, "yields rise": -0.8, "realzins": -0.6,
    "dollar surges": -0.95, "strong dollar": -0.85, "starker dollar": -0.85,
    "etf outflows": -0.9, "profit taking": -0.65, "gewinnmitnahmen": -0.65,
}


def analyze_gold_news(title: str, summary: str = "", feed_category: str = "") -> Dict:
    clean_title = _clean_text(title)
    clean_summary = _clean_text(summary)
    lang = detect_language(clean_title, clean_summary)
    combined = f"{clean_title}. {clean_summary}".strip()
    combined_lower = f" {combined.lower()} "

    # Channel classification
    best_key, best_hits = "gold_inflation_macro", 0
    for ck, cfg in GOLD_CHANNEL_RULES.items():
        hits = sum(1 for kw in cfg["keywords"] if kw in combined_lower)
        if hits > best_hits:
            best_hits = hits
            best_key = ck
    ch_cfg = GOLD_CHANNEL_RULES[best_key]

    matched_signals: List[str] = []
    score = 0.0

    def _score_gold_clause(clause: str, mult: float) -> float:
        pad = f" {clause.lower()} "
        s = 0.0
        for p, w in GOLD_BULLISH_PHRASES.items():
            if p in pad:
                s += w * mult
                matched_signals.append(f"+{p}")
        for p, w in GOLD_BEARISH_PHRASES.items():
            if p in pad:
                s += w * mult
                matched_signals.append(p)
        return s

    parts = CONTRAST_MARKERS.split(clean_title, maxsplit=1)
    if len(parts) == 2:
        score += _score_gold_clause(parts[0], 1.45)
        score += _score_gold_clause(parts[1], 0.55)
    else:
        score += _score_gold_clause(clean_title, 1.35)
    if clean_summary:
        score += _score_gold_clause(clean_summary, 0.80)

    normalized = int(round(100 * (score / (abs(score) + 1.05)))) if score != 0 else 0
    normalized = max(-98, min(98, normalized))

    if normalized >= 30:
        sentiment_label = "Bullish"
    elif normalized >= 10:
        sentiment_label = "Slightly Bullish"
    elif normalized <= -30:
        sentiment_label = "Bearish"
    elif normalized <= -10:
        sentiment_label = "Slightly Bearish"
    else:
        sentiment_label = "Neutral"

    abs_score = abs(normalized)
    hi_terms = ["fed", "fomc", "powell", "cpi", "nfp", "rate cut", "rate hike", "zinserhöhung", "zinssenkung", "dxy", "real yield", "record", "crash", "slump", "central bank"]
    hits = sum(1 for t in hi_terms if t in combined_lower)
    impact_level = "High" if (abs_score >= 28 or hits >= 2) else ("Medium" if abs_score >= 12 or hits >= 1 else "Low")

    lang_tag = "[DE] " if lang == "DE" else ""
    if best_key == "gold_fed_yields":
        note = f"{lang_tag}Direct Gold rates channel: Fed policy & US real yield expectations directly reprice non-yielding bullion."
    elif best_key == "gold_usd_dxy":
        note = f"{lang_tag}Direct Gold FX channel: US Dollar Index (DXY) direction inversely drives XAU/USD institutional flows."
    elif best_key == "gold_central_banks":
        note = f"{lang_tag}Direct physical/ETF flow: sovereign central-bank reserve demand & ETF positioning steer structural Gold trend."
    elif best_key == "gold_geopolitics":
        note = f"{lang_tag}Indirect safe-haven bid: geopolitical/tariff uncertainty triggers institutional defensive rotation into Gold."
    else:
        note = f"{lang_tag}Indirect macro/inflation signal affecting real-rate hedges and COMEX Gold positioning."

    return {
        "lang": lang,
        "sentiment_score": normalized,
        "sentiment_label": sentiment_label,
        "channel_key": best_key,
        "channel_label": ch_cfg["label"],
        "impact_type": ch_cfg["impact_type"],
        "impact_level": impact_level,
        "sectors": ["Precious Metals", "USD / Real Yields"],
        "transmission_note": note,
        "signals": list(dict.fromkeys(matched_signals))[:5],
    }


# ==============================================================================
# BITCOIN (BTC / BTC-USD) BILINGUAL FUNDAMENTAL SENTIMENT ENGINE
# ==============================================================================

BTC_CHANNEL_RULES = {
    "btc_etf_institutional": {
        "label": "Spot ETF & Institutional Flows",
        "impact_type": "direct",
        "keywords": [
            "etf", "blackrock", "ibit", "fidelity", "fbtc", "grayscale", "gbtc", "inflow", "outflow",
            "zuflüsse", "abflüsse", "microstrategy", "strategy", "corporate treasury", "sovereign wealth",
            "institutional", "institutionell", "custody", "spot bitcoin",
        ],
    },
    "btc_fed_liquidity": {
        "label": "Fed Liquidity, Macro & DXY",
        "impact_type": "direct",
        "keywords": [
            "fed", "fomc", "powell", "liquidity", "liquidität", "rate cut", "rate hike", "zinssenkung",
            "zinserhöhung", "cpi", "inflation", "pce", "dollar", "dxy", "treasury", "yield", "m2", "nasdaq",
        ],
    },
    "btc_regulation": {
        "label": "Regulation, SEC & MiCA Policy",
        "impact_type": "direct",
        "keywords": [
            "sec", "cftc", "mica", "bafin", "lawsuit", "klage", "approval", "zulassung", "ban", "verbot",
            "congress", "senate", "strategic bitcoin reserve", "executive order", "regulation", "regulierung",
            "tax", "steuer", "compliance",
        ],
    },
    "btc_onchain_miners": {
        "label": "On-Chain, Whales & Miners",
        "impact_type": "indirect",
        "keywords": [
            "whale", "wal", "miner", "mining", "hashrate", "halving", "exchange reserve", "börsenbestand",
            "liquidation", "liquidierung", "open interest", "funding rate", "short squeeze", "long squeeze",
            "dormant", "cold storage", "on-chain",
        ],
    },
    "btc_market_sentiment": {
        "label": "Crypto Market & Risk Sentiment",
        "impact_type": "indirect",
        "keywords": [
            "bitcoin", "btc", "crypto", "krypto", "ethereum", "eth", "altcoin", "stablecoin", "tether",
            "usdt", "coinbase", "binance", "bitcoinkurs", "kryptowährung", "hack", "exploit",
        ],
    },
}

BTC_BULLISH_PHRASES = {
    "bitcoin surges": 1.1, "bitcoin rallies": 1.0, "bitcoin jumps": 1.0, "bitcoin climbs": 0.9,
    "bitcoin rises": 0.85, "bitcoin breaks": 0.95, "bitcoin rebounds": 0.9, "btc surges": 1.1,
    "all-time high": 1.15, "record high": 1.1, "rekordhoch": 1.1, "bitcoin steigt": 0.9,
    "bitcoin legt zu": 0.85, "krypto-rally": 1.0, "etf inflows": 1.1, "net inflows": 1.0,
    "record inflows": 1.15, "blackrock buys": 1.0, "microstrategy buys": 0.9, "buys bitcoin": 0.9,
    "strategic reserve": 1.1, "short squeeze": 0.9, "whale accumulation": 0.95, "accumulation": 0.75,
    "rate cut": 0.9, "dovish": 0.8, "liquidity expansion": 0.9, "sec approves": 1.05, "adoption": 0.75,
}

BTC_BEARISH_PHRASES = {
    "bitcoin falls": -0.9, "bitcoin drops": -0.95, "bitcoin slides": -1.0, "bitcoin plunges": -1.15,
    "bitcoin crashes": -1.2, "bitcoin tumbles": -1.1, "bitcoin sinks": -1.0, "btc drops": -0.95,
    "bitcoin fällt": -0.9, "bitcoin verliert": -0.85, "krypto-crash": -1.15, "kurssturz": -1.1,
    "etf outflows": -1.05, "net outflows": -0.95, "massive liquidations": -1.0, "long squeeze": -0.85,
    "sec sues": -0.95, "lawsuit": -0.8, "crackdown": -0.9, "crypto ban": -1.05, "verbot": -0.95,
    "hack": -0.95, "exploit": -0.9, "bankruptcy": -1.0, "insolvenz": -1.0,
    "rate hike": -0.9, "hawkish": -0.85, "dollar surges": -0.85, "miner capitulation": -0.85,
    "sell-off": -0.9, "abverkauf": -0.9, "profit taking": -0.6, "gewinnmitnahmen": -0.6,
}


def analyze_btc_news(title: str, summary: str = "", feed_category: str = "") -> Dict:
    clean_title = _clean_text(title)
    clean_summary = _clean_text(summary)
    lang = detect_language(clean_title, clean_summary)
    combined = f"{clean_title}. {clean_summary}".strip()
    combined_lower = f" {combined.lower()} "

    best_key, best_hits = "btc_market_sentiment", 0
    for ck, cfg in BTC_CHANNEL_RULES.items():
        hits = sum(1 for kw in cfg["keywords"] if kw in combined_lower)
        if hits > best_hits:
            best_hits = hits
            best_key = ck
    ch_cfg = BTC_CHANNEL_RULES[best_key]

    matched_signals: List[str] = []
    score = 0.0

    def _score_btc_clause(clause: str, mult: float) -> float:
        pad = f" {clause.lower()} "
        s = 0.0
        for p, w in BTC_BULLISH_PHRASES.items():
            if p in pad:
                s += w * mult
                matched_signals.append(f"+{p}")
        for p, w in BTC_BEARISH_PHRASES.items():
            if p in pad:
                s += w * mult
                matched_signals.append(p)
        words = re.findall(r"[a-zäöüß]+", pad)
        for idx, w in enumerate(words):
            negated = bool(set(words[max(0, idx - 2):idx]) & NEGATIONS)
            if w in SINGLE_BULLISH_WORDS:
                val = SINGLE_BULLISH_WORDS[w] * mult * 0.65
                s += (-val * 0.6) if negated else val
            elif w in SINGLE_BEARISH_WORDS:
                val = SINGLE_BEARISH_WORDS[w] * mult * 0.65
                s += (-val * 0.6) if negated else val
        return s

    parts = CONTRAST_MARKERS.split(clean_title, maxsplit=1)
    if len(parts) == 2:
        score += _score_btc_clause(parts[0], 1.45)
        score += _score_btc_clause(parts[1], 0.55)
    else:
        score += _score_btc_clause(clean_title, 1.35)
    if clean_summary:
        score += _score_btc_clause(clean_summary, 0.80)

    normalized = int(round(100 * (score / (abs(score) + 1.15)))) if score != 0 else 0
    normalized = max(-98, min(98, normalized))

    if normalized >= 30:
        sentiment_label = "Bullish"
    elif normalized >= 10:
        sentiment_label = "Slightly Bullish"
    elif normalized <= -30:
        sentiment_label = "Bearish"
    elif normalized <= -10:
        sentiment_label = "Slightly Bearish"
    else:
        sentiment_label = "Neutral"

    abs_score = abs(normalized)
    hi_terms = ["etf", "blackrock", "sec", "fed", "fomc", "powell", "cpi", "liquidation", "hack", "halving", "record", "crash", "surge", "inflow", "outflow", "reserve"]
    hits = sum(1 for t in hi_terms if t in combined_lower)
    impact_level = "High" if (abs_score >= 28 or hits >= 2) else ("Medium" if abs_score >= 12 or hits >= 1 else "Low")

    lang_tag = "[DE] " if lang == "DE" else ""
    if best_key == "btc_etf_institutional":
        note = f"{lang_tag}Direct BTC ETF/institutional flow: Spot ETF creations/redemptions & treasury buys directly absorb or release BTC supply."
    elif best_key == "btc_fed_liquidity":
        note = f"{lang_tag}Direct BTC liquidity channel: Fed rate expectations, global M2 & DXY drive high-beta risk appetite for Bitcoin."
    elif best_key == "btc_regulation":
        note = f"{lang_tag}Direct regulatory catalyst: SEC/MiCA/sovereign policy shifts reprice institutional Bitcoin access."
    elif best_key == "btc_onchain_miners":
        note = f"{lang_tag}Indirect on-chain & derivatives flow: whale positioning, open interest & liquidation sweeps steer short-term BTC volatility."
    else:
        note = f"{lang_tag}Indirect crypto market sentiment signal influencing BTC spot/perp momentum."

    return {
        "lang": lang,
        "sentiment_score": normalized,
        "sentiment_label": sentiment_label,
        "channel_key": best_key,
        "channel_label": ch_cfg["label"],
        "impact_type": ch_cfg["impact_type"],
        "impact_level": impact_level,
        "sectors": ["Bitcoin Spot/Perps", "Crypto Liquidity"],
        "transmission_note": note,
        "signals": list(dict.fromkeys(matched_signals))[:5],
    }


# ==============================================================================
# 2. SMC / IPDA / v6.0 HIGH-WIN-RATE TRADE SIGNAL ENGINE
# ==============================================================================

# --- Pure-Stdlib Frankfurt CET/CEST Timezone Helper (Works on All OSes) ---

def _last_sunday(year: int, month: int) -> datetime:
    if month == 12:
        nxt = datetime(year + 1, 1, 1, tzinfo=timezone.utc)
    else:
        nxt = datetime(year, month + 1, 1, tzinfo=timezone.utc)
    d = nxt - timedelta(days=1)
    while d.weekday() != 6:
        d -= timedelta(days=1)
    return d


def to_frankfurt_dt(utc_ts: Optional[float] = None) -> Tuple[datetime, str]:
    dt_utc = datetime.fromtimestamp(utc_ts, tz=timezone.utc) if utc_ts is not None else datetime.now(tz=timezone.utc)
    dst_start = _last_sunday(dt_utc.year, 3).replace(hour=1, minute=0, second=0)
    dst_end = _last_sunday(dt_utc.year, 10).replace(hour=1, minute=0, second=0)
    if dst_start <= dt_utc < dst_end:
        return dt_utc + timedelta(hours=2), "CEST"
    return dt_utc + timedelta(hours=1), "CET"


def get_killzone_status(utc_ts: Optional[float] = None, instrument: str = "DAX") -> Dict:
    dt_de, tz_abbr = to_frankfurt_dt(utc_ts)
    hm = dt_de.hour * 60 + dt_de.minute
    weekday = dt_de.weekday()

    if instrument == "BTC":
        if 1 * 60 <= hm < 7 * 60:
            phase = "Asia Crypto Accumulation / Range"
            tag = "BTC ASIA KZ"
            guidance = "24/7 Crypto Asia session. Watch for stop-hunts of PDH/PDL or Asia Range highs/lows before London handoff."
        elif 8 * 60 <= hm < 12 * 60:
            phase = "London Institutional Crypto Killzone"
            tag = "BTC LONDON KZ"
            guidance = "European institutional desk open. High probability for Judas sweep and 15m FVG/OB displacement."
        elif 13 * 60 + 30 <= hm < 22 * 60:
            phase = "NY Spot ETF / US Equities Overlap KZ"
            tag = "BTC NY ETF KZ"
            guidance = "Peak Bitcoin Spot ETF & CME/Perp liquidity window. Watch SMT vs ETH-USD & DXY/S&P 500 correlation."
        else:
            phase = "24/7 Global Crypto Overnight Flow"
            tag = "BTC 24/7 ACTIVE"
            guidance = "Continuous global BTC liquidity. Execute strictly on confirmed 1H+15m sweeps and FVG/OTE confluences."
        return {
            "frankfurt_time": dt_de.strftime("%H:%M"),
            "frankfurt_date": dt_de.strftime("%Y-%m-%d"),
            "tz": tz_abbr,
            "phase": phase,
            "tag": tag,
            "is_killzone": True,
            "is_deadzone": False,
            "guidance": guidance,
        }

    if weekday >= 5:
        phase = "Weekend Market Closed"
        tag = "CLOSED"
        guidance = "Cash Xetra closed. Review IPDA 20/40/60D Dealing Ranges, Weekly Open, and next week's Catalyst Calendar."
        active = False
    elif hm < 8 * 60:
        phase = "Asian / Overnight Accumulation"
        tag = "ASIAN"
        guidance = "AMD Accumulation phase. Wait for Frankfurt/London Open to engineer a Judas sweep before entering."
        active = False
    elif 8 * 60 <= hm < 9 * 60:
        phase = "Frankfurt Pre-Xetra / Judas Swing"
        tag = "FRANKFURT PRE"
        guidance = "High-manipulation window. Watch for fake directional sweep above/below Weekly or Midnight Open before 09:00 Xetra."
        active = True
    elif 9 * 60 <= hm < 11 * 60 + 30:
        phase = "London / Xetra Open Killzone"
        tag = "LONDON KZ"
        guidance = "Primary AM expansion window (Ifo 10:00 / ZEW 11:00). Look for OTE / FVG / Breaker entry after Opening sweep."
        active = True
    elif 11 * 60 + 30 <= hm < 13 * 60 + 45:
        phase = "EU Midday Deadzone / OTE Pullback"
        tag = "LUNCH DEADZONE"
        guidance = "Lower institutional volume (11:30-13:45 CET); wait for 13:45 NY/Xetra overlap sweep into AM OTE/FVGs."
        active = False
    elif 13 * 60 + 45 <= hm < 17 * 60 + 30:
        phase = "NY Open / Xetra Close Overlap Killzone"
        tag = "NY OVERLAP KZ"
        guidance = "Peak cross-asset liquidity (ECB 14:15, US NFP/CPI 14:30, NY open 15:30). Watch SMT vs S&P 500 & SD targets."
        active = True
    else:
        phase = "Post-Xetra / Futures Drift"
        tag = "AFTER HOURS"
        guidance = "Xetra cash closed. Mark today's PDH/PDL, IFVGs, and 20D/60D IPDA levels for tomorrow's London Open."
        active = False

    return {
        "frankfurt_time": dt_de.strftime("%H:%M"),
        "frankfurt_date": dt_de.strftime("%Y-%m-%d"),
        "tz": tz_abbr,
        "phase": phase,
        "tag": tag,
        "is_killzone": active,
        "is_deadzone": not active,
        "guidance": guidance,
    }


def classify_event_killzone(time_str: str) -> str:
    m = None
    for part in (time_str or "").split(":"):
        if part.strip().isdigit():
            m = int(part.strip())
            break
    if m is None:
        return "Session Event"
    if 9 <= m < 12:
        return "London / Xetra Open KZ — Expect Judas sweep of ORH/ORL or PDH/PDL before displacement"
    if 13 <= m < 18:
        return "NY Overlap KZ — High-volatility news injection; watch SMT, IFVG & SD terminus targets"
    return "Off-Killzone Release"


# --- Swings, FVGs, Inverse FVGs, Order Blocks, Breaker Blocks ---

def _find_swings(candles: List[Dict], left: int = 3, right: int = 3) -> Tuple[List[Dict], List[Dict]]:
    swing_highs: List[Dict] = []
    swing_lows: List[Dict] = []
    n = len(candles)
    for i in range(left, n - right):
        hi = candles[i]["h"]
        lo = candles[i]["l"]
        if all(hi >= candles[j]["h"] for j in range(i - left, i + right + 1) if j != i):
            if not swing_highs or abs(i - swing_highs[-1]["idx"]) >= 3:
                swing_highs.append({"idx": i, "t": candles[i]["t"], "price": hi})
        if all(lo <= candles[j]["l"] for j in range(i - left, i + right + 1) if j != i):
            if not swing_lows or abs(i - swing_lows[-1]["idx"]) >= 3:
                swing_lows.append({"idx": i, "t": candles[i]["t"], "price": lo})
    return swing_highs, swing_lows


def _detect_fvgs_and_ifvgs(candles: List[Dict], min_rel: float = 0.0004) -> Tuple[List[Dict], List[Dict]]:
    active_fvgs: List[Dict] = []
    ifvgs: List[Dict] = []
    n = len(candles)

    for i in range(2, n):
        c0 = candles[i - 2]
        c1 = candles[i - 1]
        c2 = candles[i]

        # Original Bullish FVG
        if c2["l"] > c0["h"] and (c2["l"] - c0["h"]) >= max(2.0, c1["c"] * min_rel):
            bottom = round(c0["h"], 2)
            top = round(c2["l"], 2)
            ce = round((top + bottom) / 2.0, 2)
            # Check if invalidated by a close below bottom (becomes Bearish IFVG!)
            inv_idx = next((k for k in range(i + 1, n) if candles[k]["c"] < bottom), None)
            if inv_idx is None:
                touched = any(candles[k]["l"] < top for k in range(i + 1, n))
                active_fvgs.append({
                    "type": "bullish", "idx": i - 1, "t": c1["t"],
                    "top": top, "bottom": bottom, "ce": ce, "partially_filled": touched,
                })
            else:
                # Bearish IFVG remains valid as long as no subsequent close reclaims above top
                re_broken = any(candles[k]["c"] > top for k in range(inv_idx + 1, n))
                if not re_broken and inv_idx >= n - 40:
                    ifvgs.append({
                        "type": "bearish_ifvg", "idx": inv_idx, "t": candles[inv_idx]["t"],
                        "top": top, "bottom": bottom, "ce": ce,
                        "note": "Broken Bullish FVG flipped Bearish IFVG",
                    })

        # Original Bearish FVG
        elif c2["h"] < c0["l"] and (c0["l"] - c2["h"]) >= max(2.0, c1["c"] * min_rel):
            top = round(c0["l"], 2)
            bottom = round(c2["h"], 2)
            ce = round((top + bottom) / 2.0, 2)
            inv_idx = next((k for k in range(i + 1, n) if candles[k]["c"] > top), None)
            if inv_idx is None:
                touched = any(candles[k]["h"] > bottom for k in range(i + 1, n))
                active_fvgs.append({
                    "type": "bearish", "idx": i - 1, "t": c1["t"],
                    "top": top, "bottom": bottom, "ce": ce, "partially_filled": touched,
                })
            else:
                re_broken = any(candles[k]["c"] < bottom for k in range(inv_idx + 1, n))
                if not re_broken and inv_idx >= n - 40:
                    ifvgs.append({
                        "type": "bullish_ifvg", "idx": inv_idx, "t": candles[inv_idx]["t"],
                        "top": top, "bottom": bottom, "ce": ce,
                        "note": "Broken Bearish FVG flipped Bullish IFVG",
                    })

    return active_fvgs[-8:], ifvgs[-4:]


def _detect_structure_obs_and_breakers(
    candles: List[Dict],
    swing_highs: List[Dict],
    swing_lows: List[Dict],
    active_fvgs: List[Dict],
) -> Tuple[str, List[Dict], List[Dict], List[Dict]]:
    events: List[Dict] = []
    obs: List[Dict] = []
    breakers: List[Dict] = []
    trend = "Neutral"

    if not swing_highs or not swing_lows:
        return trend, events, obs, breakers

    n = len(candles)
    sh_ptr = sl_ptr = 0
    active_sh = active_sl = None
    broken_sh = set()
    broken_sl = set()

    for i, c in enumerate(candles):
        while sh_ptr < len(swing_highs) and swing_highs[sh_ptr]["idx"] <= i - 3:
            active_sh = swing_highs[sh_ptr]
            sh_ptr += 1
        while sl_ptr < len(swing_lows) and swing_lows[sl_ptr]["idx"] <= i - 3:
            active_sl = swing_lows[sl_ptr]
            sl_ptr += 1

        if active_sh and active_sh["idx"] not in broken_sh and c["c"] > active_sh["price"]:
            broken_sh.add(active_sh["idx"])
            ev_type = "CHoCH" if trend == "Bearish" else "BOS"
            trend = "Bullish"
            events.append({"idx": i, "t": c["t"], "type": ev_type, "dir": "bullish", "price": round(active_sh["price"], 2)})
            for j in range(i - 1, max(-1, i - 12), -1):
                if candles[j]["c"] < candles[j]["o"]:
                    ob_top, ob_bot = round(candles[j]["h"], 2), round(candles[j]["l"], 2)
                    break_idx = next((k for k in range(i + 1, n) if candles[k]["c"] < ob_bot), None)
                    if break_idx is None:
                        obs.append({"type": "bullish", "idx": j, "t": candles[j]["t"], "top": ob_top, "bottom": ob_bot})
                    else:
                        # Failed Bullish OB -> Bearish Breaker Block
                        reclaimed = any(candles[k]["c"] > ob_top for k in range(break_idx + 1, n))
                        if not reclaimed and break_idx >= n - 45:
                            unicorn = any(f["type"] == "bearish" and not (f["bottom"] > ob_top or f["top"] < ob_bot) for f in active_fvgs)
                            breakers.append({"type": "bearish_breaker", "idx": break_idx, "t": candles[break_idx]["t"], "top": ob_top, "bottom": ob_bot, "unicorn": unicorn})
                    break

        if active_sl and active_sl["idx"] not in broken_sl and c["c"] < active_sl["price"]:
            broken_sl.add(active_sl["idx"])
            ev_type = "CHoCH" if trend == "Bullish" else "BOS"
            trend = "Bearish"
            events.append({"idx": i, "t": c["t"], "type": ev_type, "dir": "bearish", "price": round(active_sl["price"], 2)})
            for j in range(i - 1, max(-1, i - 12), -1):
                if candles[j]["c"] > candles[j]["o"]:
                    ob_top, ob_bot = round(candles[j]["h"], 2), round(candles[j]["l"], 2)
                    break_idx = next((k for k in range(i + 1, n) if candles[k]["c"] > ob_top), None)
                    if break_idx is None:
                        obs.append({"type": "bearish", "idx": j, "t": candles[j]["t"], "top": ob_top, "bottom": ob_bot})
                    else:
                        # Failed Bearish OB -> Bullish Breaker Block
                        reclaimed = any(candles[k]["c"] < ob_bot for k in range(break_idx + 1, n))
                        if not reclaimed and break_idx >= n - 45:
                            unicorn = any(f["type"] == "bullish" and not (f["bottom"] > ob_top or f["top"] < ob_bot) for f in active_fvgs)
                            breakers.append({"type": "bullish_breaker", "idx": break_idx, "t": candles[break_idx]["t"], "top": ob_top, "bottom": ob_bot, "unicorn": unicorn})
                    break

    return trend, events[-8:], obs[-4:], breakers[-4:]


# --- IPDA 20/40/60-Day Lookbacks & Daily FVGs ---

def compute_ipda_lookbacks(candles_daily: List[Dict], current_price: float) -> Dict:
    if len(candles_daily) < 5:
        return {}

    def _rng(bars: List[Dict]) -> Dict:
        hi = round(max(b["h"] for b in bars), 2)
        lo = round(min(b["l"] for b in bars), 2)
        span = hi - lo
        pct = round(((current_price - lo) / span) * 100.0, 1) if span > 0 else 50.0
        zone = "Premium" if pct >= 62 else ("Discount" if pct <= 38 else "Equilibrium")
        return {"high": hi, "low": lo, "eq": round((hi + lo) / 2.0, 2), "pct": pct, "zone": zone}

    d20 = _rng(candles_daily[-20:])
    d40 = _rng(candles_daily[-40:]) if len(candles_daily) >= 25 else d20
    d60 = _rng(candles_daily[-60:]) if len(candles_daily) >= 45 else d40

    daily_fvgs, _ = _detect_fvgs_and_ifvgs(candles_daily[-45:], min_rel=0.001)

    return {
        "d20": d20,
        "d40": d40,
        "d60": d60,
        "daily_fvgs": daily_fvgs[-4:],
    }


# --- Power of 3 (AMD) & True Opens ---

def compute_power_of_three(
    candles_15m: List[Dict],
    candles_daily: List[Dict],
    overall_score: int,
    instrument: str = "DAX",
) -> Dict:
    if not candles_15m:
        return {}

    cur = round(candles_15m[-1]["c"], 2)
    last_day = to_frankfurt_dt(candles_15m[-1]["t"])[0].date()
    today_bars = [c for c in candles_15m if to_frankfurt_dt(c["t"])[0].date() == last_day]
    open_label = "COMEX/LDN Open" if instrument == "GOLD" else ("UTC Daily Open" if instrument == "BTC" else "Xetra Open")
    if instrument == "GOLD" and today_bars:
        ny_bars = [c for c in today_bars if to_frankfurt_dt(c["t"])[0].hour >= 14]
        ldn_bars = [c for c in today_bars if to_frankfurt_dt(c["t"])[0].hour >= 8]
        ref_bars = ny_bars or ldn_bars or today_bars
        cash_open = round(ref_bars[0]["o"], 2)
    elif instrument == "BTC" and today_bars:
        utc_midnight = [c for c in today_bars if to_frankfurt_dt(c["t"])[0].hour >= 1]
        cash_open = round((utc_midnight or today_bars)[0]["o"], 2)
    else:
        cash_open = round(today_bars[0]["o"], 2) if today_bars else round(candles_15m[-1]["o"], 2)
    day_high = round(max(c["h"] for c in today_bars), 2) if today_bars else cur
    day_low = round(min(c["l"] for c in today_bars), 2) if today_bars else cur

    # Monday Weekly Open & Monthly Open from daily candles
    now_dt, _ = to_frankfurt_dt()
    cur_week = now_dt.isocalendar()[:2]
    cur_month = (now_dt.year, now_dt.month)

    wk_bars = [c for c in candles_daily if to_frankfurt_dt(c["t"])[0].isocalendar()[:2] == cur_week]
    weekly_open = round(wk_bars[0]["o"], 2) if wk_bars else (round(candles_daily[-1]["o"], 2) if candles_daily else cash_open)

    mo_bars = [c for c in candles_daily if (to_frankfurt_dt(c["t"])[0].year, to_frankfurt_dt(c["t"])[0].month) == cur_month]
    monthly_open = round(mo_bars[0]["o"], 2) if mo_bars else weekly_open

    above_cash = cur >= cash_open
    above_week = cur >= weekly_open
    sweep_buf = max(cur * 0.0005, 1.5)
    swept_above_open = day_high > cash_open + sweep_buf
    swept_below_open = day_low < cash_open - sweep_buf

    if overall_score <= -10:
        if not above_cash and swept_above_open:
            amd_phase = "DISTRIBUTION SHORT"
            amd_tone = "bear"
            amd_note = f"Price manipulated above {open_label} ({cash_open}) to {day_high}, then displaced below open — textbook bearish AMD."
        elif above_cash:
            amd_phase = "MANIPULATION (JUDAS ABOVE OPEN)"
            amd_tone = "neut"
            amd_note = f"Price is trading above {open_label} ({cash_open}) against Bearish fundamentals — watch for bearish CHoCH/IFVG short back under open."
        else:
            amd_phase = "EXPANSION BELOW OPEN"
            amd_tone = "bear"
            amd_note = f"Price expanding below {open_label} ({cash_open}) and {'below' if not above_week else 'near'} Weekly Open ({weekly_open})."
    elif overall_score >= 10:
        if above_cash and swept_below_open:
            amd_phase = "DISTRIBUTION LONG"
            amd_tone = "bull"
            amd_note = f"Price manipulated below {open_label} ({cash_open}) to {day_low}, then reclaimed above open — textbook bullish AMD."
        elif not above_cash:
            amd_phase = "MANIPULATION (JUDAS BELOW OPEN)"
            amd_tone = "neut"
            amd_note = f"Price is trading below {open_label} ({cash_open}) against Bullish fundamentals — watch for bullish CHoCH/IFVG long back above open."
        else:
            amd_phase = "EXPANSION ABOVE OPEN"
            amd_tone = "bull"
            amd_note = f"Price expanding above {open_label} ({cash_open}) and {'above' if above_week else 'near'} Weekly Open ({weekly_open})."
    else:
        amd_phase = "ACCUMULATION / TWO-WAY"
        amd_tone = "neut"
        amd_note = f"Mixed macro bias around {open_label} ({cash_open}) and Weekly Open ({weekly_open}); wait for clean sweep + IFVG."

    return {
        "cash_open": cash_open,
        "weekly_open": weekly_open,
        "monthly_open": monthly_open,
        "open_label": open_label,
        "above_cash_open": above_cash,
        "above_weekly_open": above_week,
        "amd_phase": amd_phase,
        "amd_tone": amd_tone,
        "amd_note": amd_note,
    }


# --- OTE (61.8% - 78.6% / 70.5%) & Standard Deviation Projections ---

def compute_ote_and_sd(
    candles_15m: List[Dict],
    swing_highs: List[Dict],
    swing_lows: List[Dict],
    trend: str,
    fvgs: List[Dict],
) -> Tuple[Dict, Dict]:
    if not candles_15m or not swing_highs or not swing_lows:
        return {}, {}

    cur = round(candles_15m[-1]["c"], 2)
    sh = swing_highs[-1]
    sl = swing_lows[-1]

    # Use most recent leg direction (or trend)
    if trend == "Bearish" or (trend == "Neutral" and sh["idx"] < sl["idx"]):
        hi_p = sh["price"]
        lo_p = sl["price"]
        leg = max(1.0, hi_p - lo_p)
        ote_618 = round(lo_p + leg * 0.618, 2)
        ote_705 = round(lo_p + leg * 0.705, 2)
        ote_786 = round(lo_p + leg * 0.786, 2)
        in_ote = ote_618 <= cur <= ote_786
        fvg_confluence = any(f["type"] == "bearish" and not (f["bottom"] > ote_786 or f["top"] < ote_618) for f in fvgs)
        ote = {
            "direction": "Short Pullback OTE",
            "anchor_high": round(hi_p, 2), "anchor_low": round(lo_p, 2),
            "fib_618": ote_618, "fib_705": ote_705, "fib_786": ote_786,
            "in_ote": in_ote, "fvg_confluence": fvg_confluence,
        }
        # Standard deviation targets from the prior bullish manipulation leg (if prev swing low exists)
        manip_leg = max(15.0, abs(hi_p - swing_lows[-2]["price"]) if len(swing_lows) >= 2 else leg)
        sd = {
            "direction": "Bearish Expansion Targets",
            "anchor": round(hi_p, 2),
            "sd_15": round(hi_p - manip_leg * 1.5, 2),
            "sd_20": round(hi_p - manip_leg * 2.0, 2),
            "sd_25": round(hi_p - manip_leg * 2.5, 2),
        }
    else:
        hi_p = sh["price"]
        lo_p = sl["price"]
        leg = max(1.0, hi_p - lo_p)
        ote_618 = round(hi_p - leg * 0.618, 2)
        ote_705 = round(hi_p - leg * 0.705, 2)
        ote_786 = round(hi_p - leg * 0.786, 2)
        in_ote = ote_786 <= cur <= ote_618
        fvg_confluence = any(f["type"] == "bullish" and not (f["bottom"] > ote_618 or f["top"] < ote_786) for f in fvgs)
        ote = {
            "direction": "Long Pullback OTE",
            "anchor_high": round(hi_p, 2), "anchor_low": round(lo_p, 2),
            "fib_618": ote_618, "fib_705": ote_705, "fib_786": ote_786,
            "in_ote": in_ote, "fvg_confluence": fvg_confluence,
        }
        manip_leg = max(15.0, abs(swing_highs[-2]["price"] - lo_p) if len(swing_highs) >= 2 else leg)
        sd = {
            "direction": "Bullish Expansion Targets",
            "anchor": round(lo_p, 2),
            "sd_15": round(lo_p + manip_leg * 1.5, 2),
            "sd_20": round(lo_p + manip_leg * 2.0, 2),
            "sd_25": round(lo_p + manip_leg * 2.5, 2),
        }

    return ote, sd


def compute_intermarket_triad(macro_quotes: List[Dict], instrument: str = "DAX") -> Dict:
    by_sym = {q["symbol"]: q for q in (macro_quotes or [])}
    dax = by_sym.get("^GDAXI", {})
    gold = by_sym.get("GC=F", {})
    vix = by_sym.get("^VIX", {})
    eur = by_sym.get("EURUSD=X", {})
    dxy = by_sym.get("DX-Y.NYB", {})
    tnx = by_sym.get("^TNX", {})

    spx = by_sym.get("^GSPC", {})
    btc = by_sym.get("BTC-USD", {})

    dax_chg = dax.get("change_pct", 0.0)
    gold_chg = gold.get("change_pct", 0.0)
    vix_chg = vix.get("change_pct", 0.0)
    eur_chg = eur.get("change_pct", 0.0)
    dxy_chg = dxy.get("change_pct", 0.0)
    tnx_chg = tnx.get("change_pct", 0.0)
    spx_chg = spx.get("change_pct", 0.0)
    btc_chg = btc.get("change_pct", 0.0)

    if instrument == "BTC":
        if dxy_chg < -0.15 and (spx_chg > 0.15 or tnx_chg < -0.4):
            regime = "CRYPTO LIQUIDITY TAILWIND (RISK-ON)"
            tone = "bull"
            detail = f"DXY ({dxy_chg:+.2f}%) weakening while S&P 500 ({spx_chg:+.2f}%) / yields ({tnx_chg:+.2f}%) support high-beta BTC inflows ({btc_chg:+.2f}%)."
        elif dxy_chg > 0.2 and (vix_chg > 2.0 or tnx_chg > 0.6):
            regime = "LIQUIDITY TIGHTENING (DXY / VIX HEADWIND)"
            tone = "bear"
            detail = f"DXY ({dxy_chg:+.2f}%) & VIX ({vix_chg:+.2f}%) / 10Y ({tnx_chg:+.2f}%) rising — tightening global risk appetite for BTC ({btc_chg:+.2f}%)."
        elif vix_chg < -2.0 and spx_chg > 0.25:
            regime = "RISK-ON CRYPTO EXPANSION"
            tone = "bull"
            detail = f"VIX compressing ({vix_chg:+.2f}%) & equities bidding ({spx_chg:+.2f}%) supports BTC upside momentum."
        else:
            regime = "BALANCED CRYPTO MACRO"
            tone = "neut"
            detail = f"DXY ({dxy_chg:+.2f}%), S&P 500 ({spx_chg:+.2f}%), VIX ({vix_chg:+.2f}%), 10Y ({tnx_chg:+.2f}%) in neutral balance."
        return {
            "regime": regime, "tone": tone, "detail": detail,
            "eur_chg": dxy_chg, "fx_label": "DXY", "vix_chg": vix_chg, "tnx_chg": tnx_chg,
        }

    if instrument == "GOLD":
        if dxy_chg < -0.15 and tnx_chg < -0.5:
            regime = "GOLD TAILWIND (WEAK USD + LOWER YIELDS)"
            tone = "bull"
            detail = f"DXY ({dxy_chg:+.2f}%) & US 10Y ({tnx_chg:+.2f}%) falling together — classic institutional Gold tailwind."
        elif dxy_chg > 0.15 and tnx_chg > 0.5:
            regime = "GOLD HEADWIND (STRONG USD + RISING YIELDS)"
            tone = "bear"
            detail = f"DXY ({dxy_chg:+.2f}%) & US 10Y ({tnx_chg:+.2f}%) climbing together — pressures non-yielding Gold ({gold_chg:+.2f}%)."
        elif vix_chg > 2.5:
            regime = "SAFE-HAVEN VOLATILITY BID"
            tone = "bull"
            detail = f"VIX spiking ({vix_chg:+.2f}%) triggers defensive safe-haven demand; DXY ({dxy_chg:+.2f}%), 10Y ({tnx_chg:+.2f}%)."
        else:
            regime = "BALANCED GOLD INTERMARKET"
            tone = "neut"
            detail = f"DXY ({dxy_chg:+.2f}%), US 10Y ({tnx_chg:+.2f}%), VIX ({vix_chg:+.2f}%) showing orderly macro cross-flow."
        return {
            "regime": regime, "tone": tone, "detail": detail,
            "eur_chg": dxy_chg, "fx_label": "DXY", "vix_chg": vix_chg, "tnx_chg": tnx_chg,
        }

    if vix_chg > 2.0 and dax_chg < -0.2:
        regime = "RISK-OFF DE-LEVERAGING"
        tone = "bear"
        detail = f"VIX surging ({vix_chg:+.2f}%) while DAX weakens ({dax_chg:+.2f}%) — confirms institutional risk reduction."
    elif vix_chg > 1.5 and dax_chg >= 0:
        regime = "HIDDEN VOLATILITY WARNING"
        tone = "neut"
        detail = f"VIX climbing ({vix_chg:+.2f}%) even as DAX holds steady ({dax_chg:+.2f}%) — classic distribution warning."
    elif vix_chg < -2.0 and dax_chg > 0.2:
        regime = "RISK-ON EXPANSION"
        tone = "bull"
        detail = f"VIX compressing ({vix_chg:+.2f}%) alongside DAX strength ({dax_chg:+.2f}%) — supports trend continuation."
    else:
        regime = "BALANCED INTERMARKET"
        tone = "neut"
        detail = f"EUR/USD ({eur_chg:+.2f}%), VIX ({vix_chg:+.2f}%), US 10Y ({tnx_chg:+.2f}%) showing orderly cross-asset flow."

    return {
        "regime": regime,
        "tone": tone,
        "detail": detail,
        "eur_chg": eur_chg,
        "vix_chg": vix_chg,
        "tnx_chg": tnx_chg,
    }


def compute_liquidity_and_range(candles_15m: List[Dict], candles_daily: List[Dict], instrument: str = "DAX") -> Dict:
    if not candles_15m:
        return {}

    current_price = round(candles_15m[-1]["c"], 2)
    pdh = pdl = pwh = pwl = None
    if len(candles_daily) >= 2:
        last_d, _ = to_frankfurt_dt(candles_daily[-1]["t"])
        now_d, _ = to_frankfurt_dt()
        prev_day = candles_daily[-2] if last_d.date() == now_d.date() else candles_daily[-1]
        pdh = round(prev_day["h"], 2)
        pdl = round(prev_day["l"], 2)

        cur_week = now_d.isocalendar()[:2]
        prev_week_candles = [dc for dc in candles_daily if to_frankfurt_dt(dc["t"])[0].isocalendar()[:2] < cur_week]
        if prev_week_candles:
            last_wk = to_frankfurt_dt(prev_week_candles[-1]["t"])[0].isocalendar()[:2]
            wk_bars = [c for c in prev_week_candles if to_frankfurt_dt(c["t"])[0].isocalendar()[:2] == last_wk]
            if wk_bars:
                pwh = round(max(b["h"] for b in wk_bars), 2)
                pwl = round(min(b["l"] for b in wk_bars), 2)

    last_day_date = to_frankfurt_dt(candles_15m[-1]["t"])[0].date()
    today_bars = [c for c in candles_15m if to_frankfurt_dt(c["t"])[0].date() == last_day_date]
    orh = orl = None
    if today_bars:
        target_hr = 14 if instrument == "GOLD" else (15 if instrument == "BTC" else 9)
        opening_bars = [c for c in today_bars if to_frankfurt_dt(c["t"])[0].hour == target_hr] or [c for c in today_bars if to_frankfurt_dt(c["t"])[0].hour == 8] or today_bars[:4]
        orh = round(max(b["h"] for b in opening_bars), 2)
        orl = round(min(b["l"] for b in opening_bars), 2)

    range_high = round(max(c["h"] for c in candles_15m), 2)
    range_low = round(min(c["l"] for c in candles_15m), 2)
    eq_50 = round((range_high + range_low) / 2.0, 2)
    span = range_high - range_low
    range_pct = round(((current_price - range_low) / span) * 100.0, 1) if span > 0 else 50.0
    zone = "Premium" if range_pct >= 62.0 else ("Discount" if range_pct <= 38.0 else "Equilibrium")

    recent = candles_15m[-16:]
    sweeps: List[Dict] = []
    for name, lvl, side in [
        ("PDH", pdh, "BSL"), ("PDL", pdl, "SSL"),
        ("PWH", pwh, "BSL"), ("PWL", pwl, "SSL"),
        ("Frankfurt ORH", orh, "BSL"), ("Frankfurt ORL", orl, "SSL"),
    ]:
        if lvl is None:
            continue
        if side == "BSL" and any(c["h"] > lvl and c["c"] < lvl for c in recent):
            sweeps.append({"level": name, "price": lvl, "side": "BSL Swept (Bearish Raid)"})
        elif side == "SSL" and any(c["l"] < lvl and c["c"] > lvl for c in recent):
            sweeps.append({"level": name, "price": lvl, "side": "SSL Swept (Bullish Raid)"})

    return {
        "current_price": current_price,
        "pdh": pdh, "pdl": pdl, "pwh": pwh, "pwl": pwl, "orh": orh, "orl": orl,
        "dealing_range": {"high": range_high, "low": range_low, "equilibrium": eq_50, "position_pct": range_pct, "zone": zone},
        "sweeps": sweeps,
    }


def detect_smt_divergence(dax_candles: List[Dict], peer_candles: List[Dict], peer_name: str = "Euro Stoxx 50", base_name: str = "DAX 40") -> Dict:
    if len(dax_candles) < 25 or len(peer_candles) < 25:
        return {"status": "Unavailable", "type": "none", "peer": peer_name, "detail": "Insufficient aligned candles."}

    peer_by_t = {c["t"]: c for c in peer_candles}
    aligned_dax: List[Dict] = []
    aligned_peer: List[Dict] = []
    for dc in dax_candles:
        pc = peer_by_t.get(dc["t"])
        if pc is None:
            best = min(peer_candles, key=lambda x: abs(x["t"] - dc["t"]))
            if abs(best["t"] - dc["t"]) <= 600:
                pc = best
        if pc is not None:
            aligned_dax.append(dc)
            aligned_peer.append(pc)

    if len(aligned_dax) < 20:
        return {"status": "Unavailable", "type": "none", "peer": peer_name, "detail": "Timestamps not synchronized."}

    d_sh, d_sl = _find_swings(aligned_dax, left=3, right=3)
    p_sh, p_sl = _find_swings(aligned_peer, left=3, right=3)

    bearish_smt = bullish_smt = False
    detail = f"{base_name} and {peer_name} swings are moving symmetrically (no SMT divergence)."

    if len(d_sh) >= 2 and len(p_sh) >= 2:
        if (d_sh[-1]["price"] > d_sh[-2]["price"]) != (p_sh[-1]["price"] > p_sh[-2]["price"]) and abs(d_sh[-1]["idx"] - p_sh[-1]["idx"]) <= 4:
            bearish_smt = True
            leader = base_name if d_sh[-1]["price"] > d_sh[-2]["price"] else peer_name
            lagger = peer_name if leader == base_name else base_name
            detail = f"Bearish SMT: {leader} made a Higher High while {lagger} failed with a Lower High."

    if len(d_sl) >= 2 and len(p_sl) >= 2:
        if (d_sl[-1]["price"] < d_sl[-2]["price"]) != (p_sl[-1]["price"] < p_sl[-2]["price"]) and abs(d_sl[-1]["idx"] - p_sl[-1]["idx"]) <= 4:
            bullish_smt = True
            leader = base_name if d_sl[-1]["price"] < d_sl[-2]["price"] else peer_name
            lagger = peer_name if leader == base_name else base_name
            detail = f"Bullish SMT: {leader} made a Lower Low while {lagger} held a Higher Low."

    if bearish_smt and not bullish_smt:
        return {"status": "Bearish SMT", "type": "bearish", "peer": peer_name, "detail": detail}
    if bullish_smt and not bearish_smt:
        return {"status": "Bullish SMT", "type": "bullish", "peer": peer_name, "detail": detail}
    if bearish_smt and bullish_smt:
        return {"status": "Mixed SMT", "type": "neutral", "peer": peer_name, "detail": detail}
    return {"status": "No Divergence", "type": "none", "peer": peer_name, "detail": detail}


def build_smc_execution_matrix(
    overall_score: int,
    overall_label: str,
    liquidity: Dict,
    structure_trend: str,
    fvgs: List[Dict],
    ifvgs: List[Dict],
    breakers: List[Dict],
    ote: Dict,
    po3: Dict,
    smt_stoxx: Dict,
    smt_spx: Dict,
    killzone: Dict,
) -> Dict:
    if not liquidity:
        return {"verdict": "DATA PENDING", "tone": "neut", "summary": "Awaiting OHLC candle data.", "checklist": []}

    dr = liquidity.get("dealing_range", {})
    zone = dr.get("zone", "Equilibrium")
    pos_pct = dr.get("position_pct", 50.0)
    sweeps = liquidity.get("sweeps", [])
    bsl_swept = any("BSL" in s["side"] for s in sweeps)
    ssl_swept = any("SSL" in s["side"] for s in sweeps)
    fund_dir = "bullish" if overall_score >= 10 else ("bearish" if overall_score <= -10 else "neutral")
    unicorns = [b for b in breakers if b.get("unicorn")]

    if fund_dir == "bearish" and zone == "Premium":
        verdict, tone = "INSTITUTIONAL SHORT ALIGNMENT", "bear"
        next_dol = liquidity.get("pdl") or dr.get("low")
        summary = f"Bearish macro ({overall_score:+d}) aligns with Premium ({pos_pct}%). AMD: {po3.get('amd_phase', '')}. Target DOL: {next_dol}."
    elif fund_dir == "bullish" and zone == "Discount":
        verdict, tone = "INSTITUTIONAL LONG ALIGNMENT", "bull"
        next_dol = liquidity.get("pdh") or dr.get("high")
        summary = f"Bullish macro ({overall_score:+d}) aligns with Discount ({pos_pct}%). AMD: {po3.get('amd_phase', '')}. Target DOL: {next_dol}."
    elif fund_dir == "bearish" and zone == "Discount":
        verdict, tone = "RETAIL SHORT-TRAP WARNING", "neut"
        summary = (
            f"Fundamentals are bearish ({overall_score:+d}), BUT price is deep in Discount ({pos_pct}%). "
            f"Wait for retracement into OTE ({ote.get('fib_618')}–{ote.get('fib_786')}) or Bearish IFVG/Breaker before shorting."
        )
    elif fund_dir == "bullish" and zone == "Premium":
        verdict, tone = "RETAIL LONG-TRAP WARNING", "neut"
        summary = (
            f"Fundamentals are bullish ({overall_score:+d}), BUT price is extended in Premium ({pos_pct}%). "
            f"Wait for pullback into Discount/OTE ({ote.get('fib_618')}–{ote.get('fib_786')}) before longing."
        )
    else:
        verdict = f"{structure_trend.upper()} STRUCTURE · WAIT FOR SWEEP"
        tone = "bull" if structure_trend == "Bullish" and fund_dir == "bullish" else ("bear" if structure_trend == "Bearish" and fund_dir == "bearish" else "neut")
        summary = f"Macro is {overall_label} ({overall_score:+d}) at {pos_pct}% ({zone}). AMD: {po3.get('amd_phase', '--')}. Watch for PDH/PDL sweep + IFVG."

    checklist = [
        f"1. Killzone & AMD: {killzone['phase']} | {po3.get('amd_phase', '--')}",
        f"2. HTF Bias: {overall_label} ({overall_score:+d}) | 15m Structure: {structure_trend}",
        f"3. OTE Sweet Spot (70.5%): {ote.get('fib_705', '--')} ({'ACTIVE IN OTE' if ote.get('in_ote') else 'Outside OTE'}{', +FVG Confluence' if ote.get('fvg_confluence') else ''})",
        f"4. Sweeps (4h): {', '.join(s['level'] + ' ' + s['side'].split('(')[0].strip() for s in sweeps) if sweeps else 'None yet — watch PDH/PDL & ORH/ORL'}",
        f"5. IFVGs & Breakers: {len(ifvgs)} active IFVG(s) | {len(breakers)} Breaker(s){f' ({len(unicorns)} Unicorn!)' if unicorns else ''}",
        f"6. News Rule: Never chase spike candle; wait for sweep -> displacement + IFVG/Breaker.",
    ]
    return {"verdict": verdict, "tone": tone, "summary": summary, "checklist": checklist}


def _calc_atr_15m(candles: List[Dict], period: int = 14) -> float:
    if len(candles) < 2:
        return 30.0
    trs = []
    start = max(1, len(candles) - period)
    for i in range(start, len(candles)):
        h = candles[i]["h"]
        l = candles[i]["l"]
        pc = candles[i - 1]["c"]
        trs.append(max(h - l, abs(h - pc), abs(l - pc)))
    return round(sum(trs) / len(trs), 2) if trs else 30.0


# ==============================================================================
# v6.0 HIGH-WIN-RATE INSTITUTIONAL ENGINES
# ==============================================================================

def compute_adr_metrics(candles_daily: List[Dict], candles_15m: List[Dict]) -> Dict:
    if not candles_daily or len(candles_daily) < 5:
        return {"available": False}
    hist = candles_daily[:-1][-14:] if len(candles_daily) > 1 else candles_daily[-14:]
    ranges = [max(0.0, d["h"] - d["l"]) for d in hist]
    adr_14d = round(sum(ranges) / len(ranges), 2) if ranges else 250.0

    today_range = 0.0
    if candles_15m:
        latest_date, _ = to_frankfurt_dt(candles_15m[-1]["t"])
        today_bars = [c for c in candles_15m if to_frankfurt_dt(c["t"])[0].date() == latest_date.date()]
        if today_bars:
            today_range = round(max(c["h"] for c in today_bars) - min(c["l"] for c in today_bars), 2)
    if today_range <= 0 and candles_daily:
        today_range = round(candles_daily[-1]["h"] - candles_daily[-1]["l"], 2)

    consumed_pct = round((today_range / adr_14d) * 100.0, 1) if adr_14d > 0 else 0.0
    exhausted = consumed_pct >= 95.0
    warning = consumed_pct >= 80.0
    if exhausted:
        status = "EXHAUSTED (>=95% ADR) — NO BREAKOUT CHASING"
        tone = "bear"
    elif warning:
        status = "EXTENDED (80-94% ADR) — TIGHTEN TARGETS"
        tone = "neut"
    else:
        status = "ROOM TO EXPAND (<80% ADR)"
        tone = "bull"

    return {
        "available": True,
        "adr_14d": adr_14d,
        "today_range": today_range,
        "consumed_pct": consumed_pct,
        "exhausted": exhausted,
        "warning": warning,
        "status": status,
        "tone": tone,
    }


def check_news_blackout(catalysts: Optional[List[Dict]], utc_ts: Optional[float] = None) -> Dict:
    if not catalysts:
        return {"active": False, "upcoming_soon": False, "status": "CLEAR — NO BLACKOUT", "tone": "bull"}

    now_de, tz_abbr = to_frankfurt_dt(utc_ts)
    for cat in catalysts:
        if cat.get("importance") != "High":
            continue
        date_str = cat.get("date", "")
        time_str = cat.get("time", "")
        m = re.search(r"(\d{1,2}):(\d{2})", time_str)
        if not date_str or not m:
            continue
        try:
            hh, mm = int(m.group(1)), int(m.group(2))
            ev_dt = datetime.strptime(date_str, "%Y-%m-%d").replace(hour=hh, minute=mm, tzinfo=now_de.tzinfo)
            delta_mins = (ev_dt - now_de).total_seconds() / 60.0
            if -15.0 <= delta_mins <= 45.0:
                return {
                    "active": True,
                    "upcoming_soon": True,
                    "event": cat.get("event", "High-Impact Macro Event"),
                    "time": f"{date_str} {time_str}",
                    "mins_to_event": round(delta_mins, 1),
                    "status": f"NEWS BLACKOUT ({cat.get('event')[:32]} in {round(delta_mins)}m)",
                    "tone": "bear",
                }
            if 45.0 < delta_mins <= 120.0:
                return {
                    "active": False,
                    "upcoming_soon": True,
                    "event": cat.get("event", "High-Impact Macro Event"),
                    "time": f"{date_str} {time_str}",
                    "mins_to_event": round(delta_mins, 1),
                    "status": f"PRE-NEWS CAUTION ({cat.get('event')[:28]} in {round(delta_mins)}m)",
                    "tone": "neut",
                }
        except Exception:
            continue

    return {"active": False, "upcoming_soon": False, "status": "CLEAR — NO HIGH-IMPACT BLACKOUT", "tone": "bull"}


def analyze_dax_breadth(dax_constituents: Optional[List[Dict]]) -> Dict:
    if not dax_constituents:
        return {"available": False, "regime": "UNAVAILABLE", "tone": "neut", "bull_pct": 50.0, "bear_pct": 50.0}

    total = len(dax_constituents)
    advancers = sum(1 for s in dax_constituents if (s.get("change_pct") or 0) > 0.05)
    decliners = sum(1 for s in dax_constituents if (s.get("change_pct") or 0) < -0.05)
    flat = total - advancers - decliners
    bull_pct = round((advancers / total) * 100.0, 1) if total else 50.0
    bear_pct = round((decliners / total) * 100.0, 1) if total else 50.0

    heavy_syms = {"SAP.DE", "SIE.DE", "ALV.DE", "AIR.DE"}
    heavies = [s for s in dax_constituents if s.get("symbol") in heavy_syms]
    heavy_bull = sum(1 for s in heavies if (s.get("change_pct") or 0) > 0.05)
    heavy_bear = sum(1 for s in heavies if (s.get("change_pct") or 0) < -0.05)

    if bull_pct >= 60.0 and heavy_bull >= 2:
        regime, tone = "BROAD BULLISH PARTICIPATION", "bull"
    elif bear_pct >= 60.0 and heavy_bear >= 2:
        regime, tone = "BROAD BEARISH DISTRIBUTION", "bear"
    elif bull_pct < 45.0 and heavy_bull >= 2:
        regime, tone = "THIN BULLISH BREADTH (FAKEOUT RISK)", "neut"
    elif bear_pct < 45.0 and heavy_bear >= 2:
        regime, tone = "THIN BEARISH BREADTH (SQUEEZE RISK)", "neut"
    else:
        regime, tone = "MIXED SECTOR BREADTH", "neut"

    return {
        "available": True,
        "total": total,
        "advancers": advancers,
        "decliners": decliners,
        "flat": flat,
        "bull_pct": bull_pct,
        "bear_pct": bear_pct,
        "heavy_bull": heavy_bull,
        "heavy_bear": heavy_bear,
        "regime": regime,
        "tone": tone,
    }


def detect_htf_1h_context(candles_1h: Optional[List[Dict]], cur_price: float, daily_fvgs: List[Dict]) -> Dict:
    if not candles_1h or len(candles_1h) < 16:
        return {"available": False, "trend_1h": "Neutral", "fvgs_1h": [], "obs_1h": [], "bull_nested": False, "bear_nested": False}

    sh_1h, sl_1h = _find_swings(candles_1h, left=2, right=2)
    fvgs_1h, _ = _detect_fvgs_and_ifvgs(candles_1h)
    trend_1h, _, obs_1h, _ = _detect_structure_obs_and_breakers(candles_1h, sh_1h, sl_1h, fvgs_1h)

    tol = cur_price * 0.0015  # ~0.15% buffer around HTF POI
    bull_htf_pois = (
        [{"src": "1H FVG", **f} for f in fvgs_1h if f["type"] == "bullish"]
        + [{"src": "1H OB", **o} for o in obs_1h if o["type"] == "bullish"]
        + [{"src": "1D FVG", **df} for df in daily_fvgs if df["type"] == "bullish"]
    )
    bear_htf_pois = (
        [{"src": "1H FVG", **f} for f in fvgs_1h if f["type"] == "bearish"]
        + [{"src": "1H OB", **o} for o in obs_1h if o["type"] == "bearish"]
        + [{"src": "1D FVG", **df} for df in daily_fvgs if df["type"] == "bearish"]
    )

    bull_match = next((p["src"] for p in bull_htf_pois if (p["bottom"] - tol) <= cur_price <= (p["top"] + tol)), None)
    bear_match = next((p["src"] for p in bear_htf_pois if (p["bottom"] - tol) <= cur_price <= (p["top"] + tol)), None)

    return {
        "available": True,
        "trend_1h": trend_1h,
        "fvgs_1h": fvgs_1h[-4:],
        "obs_1h": obs_1h[-4:],
        "bull_nested": bull_match is not None,
        "bull_nest_src": bull_match,
        "bear_nested": bear_match is not None,
        "bear_nest_src": bear_match,
    }


def detect_eqh_eql_and_sweep_displacement(
    candles_15m: List[Dict],
    swing_highs: List[Dict],
    swing_lows: List[Dict],
    fvgs: List[Dict],
    ifvgs: List[Dict],
    liquidity: Dict,
    atr: float,
) -> Dict:
    cur = candles_15m[-1]["c"]
    cluster_tol = max(cur * 0.0005, atr * 0.45)

    # Equal Highs / Equal Lows clusters (retail stop pockets)
    eqh_levels: List[float] = []
    sh_recent = swing_highs[-8:]
    for i in range(len(sh_recent)):
        for j in range(i + 1, len(sh_recent)):
            if abs(sh_recent[i]["price"] - sh_recent[j]["price"]) <= cluster_tol:
                lvl = round(max(sh_recent[i]["price"], sh_recent[j]["price"]), 2)
                if lvl > cur:
                    eqh_levels.append(lvl)

    eql_levels: List[float] = []
    sl_recent = swing_lows[-8:]
    for i in range(len(sl_recent)):
        for j in range(i + 1, len(sl_recent)):
            if abs(sl_recent[i]["price"] - sl_recent[j]["price"]) <= cluster_tol:
                lvl = round(min(sl_recent[i]["price"], sl_recent[j]["price"]), 2)
                if lvl < cur:
                    eql_levels.append(lvl)

    eqh = min(eqh_levels) if eqh_levels else None
    eql = max(eql_levels) if eql_levels else None

    # 2-step Sweep -> Displacement confirmation in last 14 bars (~3.5h)
    recent = candles_15m[-14:]
    bear_sweep_disp = False
    bull_sweep_disp = False
    sweep_notes: List[str] = []

    high_refs = [p for p in [liquidity.get("pdh"), liquidity.get("orh"), liquidity.get("pwh")] if p is not None]
    if swing_highs:
        high_refs.extend([s["price"] for s in swing_highs[-4:]])
    low_refs = [p for p in [liquidity.get("pdl"), liquidity.get("orl"), liquidity.get("pwl")] if p is not None]
    if swing_lows:
        low_refs.extend([s["price"] for s in swing_lows[-4:]])

    for i in range(len(recent) - 1):
        bar = recent[i]
        # Bearish raid above ref followed by bearish displacement
        if any(bar["h"] > ref and bar["c"] < ref for ref in high_refs):
            for k in range(i, min(len(recent), i + 4)):
                dk = recent[k]
                if dk["c"] < dk["o"] and (dk["o"] - dk["c"]) >= atr * 1.1:
                    bear_sweep_disp = True
                    sweep_notes.append("BSL Sweep -> Bearish Displacement")
                    break
        # Bullish raid below ref followed by bullish displacement
        if any(bar["l"] < ref and bar["c"] > ref for ref in low_refs):
            for k in range(i, min(len(recent), i + 4)):
                dk = recent[k]
                if dk["c"] > dk["o"] and (dk["c"] - dk["o"]) >= atr * 1.1:
                    bull_sweep_disp = True
                    sweep_notes.append("SSL Sweep -> Bullish Displacement")
                    break

    if not bear_sweep_disp and any("BSL" in s["side"] for s in liquidity.get("sweeps", [])) and any(f["type"] == "bearish" for f in fvgs[-3:]):
        bear_sweep_disp = True
        sweep_notes.append("4h BSL Sweep + Bearish FVG")
    if not bull_sweep_disp and any("SSL" in s["side"] for s in liquidity.get("sweeps", [])) and any(f["type"] == "bullish" for f in fvgs[-3:]):
        bull_sweep_disp = True
        sweep_notes.append("4h SSL Sweep + Bullish FVG")

    # Candlestick Rejection Triggers on last 3 closed candles
    bear_candle_trig = False
    bull_candle_trig = False
    trig_note = ""
    if len(candles_15m) >= 3:
        for idx_off in (-1, -2):
            c = candles_15m[idx_off]
            prev = candles_15m[idx_off - 1]
            body = abs(c["c"] - c["o"])
            up_wick = c["h"] - max(c["o"], c["c"])
            dn_wick = min(c["o"], c["c"]) - c["l"]
            if c["c"] < c["o"] and (up_wick >= max(cur * 0.0003, body * 1.45) or (prev["c"] > prev["o"] and c["c"] < prev["o"])):
                bear_candle_trig = True
                trig_note = "Bearish Pin/Engulfing Rejection"
            if c["c"] > c["o"] and (dn_wick >= max(cur * 0.0003, body * 1.45) or (prev["c"] < prev["o"] and c["c"] > prev["o"])):
                bull_candle_trig = True
                trig_note = "Bullish Pin/Engulfing Rejection"

    return {
        "eqh": eqh,
        "eql": eql,
        "bear_sweep_disp": bear_sweep_disp,
        "bull_sweep_disp": bull_sweep_disp,
        "bear_candle_trig": bear_candle_trig,
        "bull_candle_trig": bull_candle_trig,
        "trig_note": trig_note,
        "sweep_notes": list(dict.fromkeys(sweep_notes)),
    }


def generate_smc_trade_signals(
    candles_15m: List[Dict],
    swing_highs: List[Dict],
    swing_lows: List[Dict],
    trend: str,
    fvgs: List[Dict],
    ifvgs: List[Dict],
    obs: List[Dict],
    breakers: List[Dict],
    liquidity: Dict,
    ipda: Dict,
    po3: Dict,
    ote: Dict,
    sd_targets: Dict,
    smt_stoxx: Dict,
    smt_spx: Dict,
    intermarket: Dict,
    killzone: Dict,
    overall_score: int,
    overall_label: str,
    htf_1h: Optional[Dict] = None,
    adr: Optional[Dict] = None,
    blackout: Optional[Dict] = None,
    breadth: Optional[Dict] = None,
    price_action: Optional[Dict] = None,
) -> Dict:
    if not candles_15m or not liquidity:
        return {"available": False}

    cur = liquidity["current_price"]
    atr = _calc_atr_15m(candles_15m, 14)
    sl_buf = round(max(cur * 0.0005, min(cur * 0.0022, atr * 0.45)), 2)

    htf_1h = htf_1h or {}
    adr = adr or {}
    blackout = blackout or {}
    breadth = breadth or {}
    price_action = price_action or {}

    dr = liquidity.get("dealing_range", {})
    zone = dr.get("zone", "Equilibrium")
    sweeps = liquidity.get("sweeps", [])
    bsl_swept = any("BSL" in s["side"] for s in sweeps)
    ssl_swept = any("SSL" in s["side"] for s in sweeps)
    smt_bear = smt_stoxx.get("type") == "bearish" or smt_spx.get("type") == "bearish"
    smt_bull = smt_stoxx.get("type") == "bullish" or smt_spx.get("type") == "bullish"

    short_reasons: List[str] = []
    long_reasons: List[str] = []
    short_pts = 0
    long_pts = 0

    # 1. Macro Fundamentals (up to 18)
    if overall_score <= -20:
        short_pts += 18
        short_reasons.append(f"Bearish Fundamentals ({overall_score:+d} {overall_label})")
    elif overall_score <= -8:
        short_pts += 12
        short_reasons.append(f"Mildly Bearish Fundamentals ({overall_score:+d})")
    elif overall_score >= 20:
        long_pts += 18
        long_reasons.append(f"Bullish Fundamentals ({overall_score:+d} {overall_label})")
    elif overall_score >= 8:
        long_pts += 12
        long_reasons.append(f"Mildly Bullish Fundamentals ({overall_score:+d})")

    # 2. 15m Structure + 1H HTF Structure & Nesting (up to 28)
    if trend == "Bearish":
        short_pts += 14
        short_reasons.append("15m Market Structure Bearish (BOS/CHoCH)")
    elif trend == "Bullish":
        long_pts += 14
        long_reasons.append("15m Market Structure Bullish (BOS/CHoCH)")

    if htf_1h.get("trend_1h") == "Bearish":
        short_pts += 12
        short_reasons.append("1H HTF Trend Aligned Bearish")
    elif htf_1h.get("trend_1h") == "Bullish":
        long_pts += 12
        long_reasons.append("1H HTF Trend Aligned Bullish")

    if htf_1h.get("bear_nested"):
        short_pts += 8
        short_reasons.append(f"Nested inside {htf_1h.get('bear_nest_src')}")
    if htf_1h.get("bull_nested"):
        long_pts += 8
        long_reasons.append(f"Nested inside {htf_1h.get('bull_nest_src')}")

    # 3. Sweep + Displacement Gate (up to 16)
    if price_action.get("bear_sweep_disp"):
        short_pts += 16
        short_reasons.append("Confirmed BSL Sweep + Bearish Displacement")
    elif bsl_swept:
        short_pts += 8
        short_reasons.append("Recent BSL Sweep (await displacement)")

    if price_action.get("bull_sweep_disp"):
        long_pts += 16
        long_reasons.append("Confirmed SSL Sweep + Bullish Displacement")
    elif ssl_swept:
        long_pts += 8
        long_reasons.append("Recent SSL Sweep (await displacement)")

    # 4. Candlestick Trigger inside POI (+8)
    if price_action.get("bear_candle_trig"):
        short_pts += 8
        short_reasons.append("15m Bearish Pin/Engulfing Trigger")
    if price_action.get("bull_candle_trig"):
        long_pts += 8
        long_reasons.append("15m Bullish Pin/Engulfing Trigger")

    # 5. Power of 3 Open, Intermarket, SMT, Breadth
    if po3 and not po3.get("above_cash_open", True):
        short_pts += 10
        short_reasons.append(f"Below {po3.get('open_label', 'Xetra Open')} ({po3.get('cash_open')})")
    elif po3 and po3.get("above_cash_open", False):
        long_pts += 10
        long_reasons.append(f"Above {po3.get('open_label', 'Xetra Open')} ({po3.get('cash_open')})")

    if smt_bear:
        short_pts += 8
        short_reasons.append("Bearish SMT Divergence")
    if smt_bull:
        long_pts += 8
        long_reasons.append("Bullish SMT Divergence")

    if intermarket.get("tone") == "bear":
        short_pts += 6
        short_reasons.append(f"Intermarket {intermarket.get('regime')}")
    elif intermarket.get("tone") == "bull":
        long_pts += 6
        long_reasons.append(f"Intermarket {intermarket.get('regime')}")

    if breadth.get("available"):
        if breadth.get("bear_pct", 0) >= 60.0:
            short_pts += 8
            short_reasons.append(f"DAX Breadth Bearish ({breadth['decliners']}/{breadth['total']} red)")
        elif breadth.get("bull_pct", 0) >= 60.0:
            long_pts += 8
            long_reasons.append(f"DAX Breadth Bullish ({breadth['advancers']}/{breadth['total']} green)")

    # 6. Premium/Discount & 15m Supply/Demand Zones
    bear_pois = (
        [f for f in fvgs if f["type"] == "bearish" and f["top"] > cur - atr * 0.5]
        + [iv for iv in ifvgs if iv["type"] == "bearish_ifvg" and iv["top"] > cur - atr * 0.5]
        + [b for b in breakers if b["type"] == "bearish_breaker" and b["top"] > cur - atr * 0.5]
        + [o for o in obs if o["type"] == "bearish" and o["top"] > cur - atr * 0.5]
    )
    bull_pois = (
        [f for f in fvgs if f["type"] == "bullish" and f["bottom"] < cur + atr * 0.5]
        + [iv for iv in ifvgs if iv["type"] == "bullish_ifvg" and iv["bottom"] < cur + atr * 0.5]
        + [b for b in breakers if b["type"] == "bullish_breaker" and b["bottom"] < cur + atr * 0.5]
        + [o for o in obs if o["type"] == "bullish" and o["bottom"] < cur + atr * 0.5]
    )

    if zone == "Premium":
        short_pts += 8
        short_reasons.append(f"Price in Premium ({dr.get('position_pct')}%)")
    elif zone == "Discount":
        long_pts += 8
        long_reasons.append(f"Price in Discount ({dr.get('position_pct')}%)")

    if bear_pois:
        short_pts += 6
        short_reasons.append("Bearish 15m FVG/IFVG/OB Supply")
    if bull_pois:
        long_pts += 6
        long_reasons.append("Bullish 15m FVG/IFVG/OB Demand")

    if killzone.get("is_killzone"):
        short_pts += 4
        long_pts += 4

    # Penalties for Thin Breadth Fakeout or Exhausted ADR
    if breadth.get("regime") == "THIN BULLISH BREADTH (FAKEOUT RISK)":
        long_pts = max(0, long_pts - 15)
        long_reasons.append("WARNING: Thin Bullish Breadth (Fakeout Risk)")
    elif breadth.get("regime") == "THIN BEARISH BREADTH (SQUEEZE RISK)":
        short_pts = max(0, short_pts - 15)
        short_reasons.append("WARNING: Thin Bearish Breadth (Squeeze Risk)")

    short_conf = min(98, short_pts)
    long_conf = min(98, long_pts)

    def _build_short_plan() -> Dict:
        candidates = sorted(bear_pois, key=lambda x: abs(((x["top"] + x["bottom"]) / 2.0) - cur))
        if candidates:
            poi = candidates[0]
            entry_low = round(poi["bottom"], 2)
            entry_high = round(poi["top"], 2)
            entry_mid = round((entry_low + entry_high) / 2.0, 2)
            entry_src = poi.get("note") or ("Bearish FVG CE" if "partially_filled" in poi else "Bearish OB/Breaker")
        elif ote and ote.get("direction", "").startswith("Short") and ote.get("fib_618"):
            entry_low = ote["fib_618"]
            entry_high = ote["fib_786"]
            entry_mid = ote["fib_705"]
            entry_src = "Short OTE (61.8% - 78.6%)"
        else:
            entry_low = round(cur, 2)
            entry_high = round(cur + atr * 0.5, 2)
            entry_mid = round(cur + atr * 0.2, 2)
            entry_src = "Market / Minor Retrace"

        in_zone = (entry_low - sl_buf * 0.45) <= cur <= (entry_high + sl_buf * 0.45)
        recent_sh = max([s["price"] for s in swing_highs[-3:] if s["price"] > entry_mid] or [entry_high + atr])
        raw_sl = max(entry_high + sl_buf, min(recent_sh + sl_buf, entry_mid + max(cur * 0.0018, atr * 2.2)))

        # Wick-Protected SL: if EQH or un-swept PDH sits just above raw_sl, shield SL beyond it
        eqh = price_action.get("eqh")
        shield_notes: List[str] = []
        for pool_name, pool_val in [("EQH", eqh), ("PDH", liquidity.get("pdh")), ("ORH", liquidity.get("orh"))]:
            if pool_val is not None and entry_mid < pool_val <= raw_sl + atr * 0.65:
                if pool_val + sl_buf * 0.8 > raw_sl:
                    raw_sl = pool_val + sl_buf * 0.8
                    shield_notes.append(f"SL shielded above {pool_name} ({pool_val})")

        sl = round(max(raw_sl, entry_mid + max(cur * 0.0012, atr * 0.75)), 2)
        risk = round(sl - entry_mid, 2)

        low_pools = sorted(
            set(
                p for p in [
                    liquidity.get("orl"), liquidity.get("pdl"), liquidity.get("pwl"),
                    dr.get("low"), (ipda.get("d20") or {}).get("low"),
                    (sd_targets or {}).get("sd_15") if (sd_targets or {}).get("direction", "").startswith("Bearish") else None,
                    (sd_targets or {}).get("sd_20") if (sd_targets or {}).get("direction", "").startswith("Bearish") else None,
                    (sd_targets or {}).get("sd_25") if (sd_targets or {}).get("direction", "").startswith("Bearish") else None,
                ]
                if p is not None and p < entry_mid - risk * 0.8
            ),
            reverse=True,
        )

        tp1 = round(low_pools[0], 2) if len(low_pools) >= 1 else round(entry_mid - risk * 1.4, 2)
        if tp1 > entry_mid - risk * 1.1:
            tp1 = round(entry_mid - risk * 1.3, 2)
        tp2_cand = next((p for p in low_pools if p <= min(entry_mid - risk * 2.0, tp1 - risk * 0.6)), None)
        tp2 = round(tp2_cand, 2) if tp2_cand is not None else round(min(entry_mid - risk * 2.3, tp1 - risk * 0.9), 2)
        tp3_cand = next((p for p in low_pools if p <= tp2 - risk * 0.8), None)
        tp3 = round(tp3_cand, 2) if tp3_cand is not None else round(min(entry_mid - risk * 3.4, tp2 - risk * 1.0), 2)

        rr1 = round((entry_mid - tp1) / risk, 2) if risk > 0 else 0
        rr2 = round((entry_mid - tp2) / risk, 2) if risk > 0 else 0
        rr3 = round((entry_mid - tp3) / risk, 2) if risk > 0 else 0

        # v6.0 Strict Win-Rate Gates
        has_trigger = price_action.get("bear_sweep_disp") or price_action.get("bear_candle_trig")
        htf_ok = (htf_1h.get("trend_1h") == "Bearish") or htf_1h.get("bear_nested") or not htf_1h.get("available")

        if blackout.get("active"):
            status, status_tone = "NEWS BLACKOUT — WAIT", "bear"
        elif killzone.get("is_deadzone"):
            status, status_tone = "SESSION DEADZONE — WAIT", "neut"
        elif adr.get("exhausted") and not htf_1h.get("bear_nested"):
            status, status_tone = "ADR EXHAUSTED — NO CHASE", "neut"
        elif short_conf >= 62 and in_zone and has_trigger and htf_ok:
            status, status_tone = "ACTIVE SELL SETUP", "bear"
        elif short_conf >= 48:
            if not in_zone and cur < entry_low:
                status = "PENDING SELL LIMIT (PULLBACK)"
            elif not has_trigger:
                status = "WATCH SELL (AWAIT SWEEP/REJECTION)"
            else:
                status = "WATCH SELL (HTF FILTER)"
            status_tone = "neut"
        else:
            status, status_tone = "LOW CONFLUENCE — WAIT", "neut"

        reasons_all = short_reasons + shield_notes
        return {
            "direction": "SHORT",
            "status": status,
            "status_tone": status_tone,
            "confidence": short_conf,
            "entry_source": entry_src,
            "entry_zone": f"{entry_low} – {entry_high}",
            "entry_low": entry_low,
            "entry_high": entry_high,
            "entry_price": entry_mid,
            "stop_loss": sl,
            "risk_pts": risk,
            "tp1": tp1, "rr1": rr1,
            "tp2": tp2, "rr2": rr2,
            "tp3": tp3, "rr3": rr3,
            "reasons": reasons_all or ["Counter-trend short idea only; await 1H/15m Bearish CHoCH."],
            "invalidation": f"15m close above {sl} invalidates bearish delivery. Move SL to BE ({entry_mid}) at TP1 ({tp1}).",
        }

    def _build_long_plan() -> Dict:
        candidates = sorted(bull_pois, key=lambda x: abs(((x["top"] + x["bottom"]) / 2.0) - cur))
        if candidates:
            poi = candidates[0]
            entry_low = round(poi["bottom"], 2)
            entry_high = round(poi["top"], 2)
            entry_mid = round((entry_low + entry_high) / 2.0, 2)
            entry_src = poi.get("note") or ("Bullish FVG CE" if "partially_filled" in poi else "Bullish OB/Breaker")
        elif ote and ote.get("direction", "").startswith("Long") and ote.get("fib_618"):
            entry_low = ote["fib_786"]
            entry_high = ote["fib_618"]
            entry_mid = ote["fib_705"]
            entry_src = "Long OTE (61.8% - 78.6%)"
        else:
            entry_low = round(cur - atr * 0.5, 2)
            entry_high = round(cur, 2)
            entry_mid = round(cur - atr * 0.2, 2)
            entry_src = "Market / Minor Pullback"

        in_zone = (entry_low - sl_buf * 0.45) <= cur <= (entry_high + sl_buf * 0.45)
        recent_sl = min([s["price"] for s in swing_lows[-3:] if s["price"] < entry_mid] or [entry_low - atr])
        raw_sl = min(entry_low - sl_buf, max(recent_sl - sl_buf, entry_mid - max(cur * 0.0018, atr * 2.2)))

        # Wick-Protected SL beyond EQL / PDL / ORL
        eql = price_action.get("eql")
        shield_notes: List[str] = []
        for pool_name, pool_val in [("EQL", eql), ("PDL", liquidity.get("pdl")), ("ORL", liquidity.get("orl"))]:
            if pool_val is not None and raw_sl - atr * 0.65 <= pool_val < entry_mid:
                if pool_val - sl_buf * 0.8 < raw_sl:
                    raw_sl = pool_val - sl_buf * 0.8
                    shield_notes.append(f"SL shielded below {pool_name} ({pool_val})")

        sl = round(min(raw_sl, entry_mid - max(cur * 0.0012, atr * 0.75)), 2)
        risk = round(entry_mid - sl, 2)

        high_pools = sorted(
            set(
                p for p in [
                    liquidity.get("orh"), dr.get("equilibrium"), liquidity.get("pdh"),
                    liquidity.get("pwh"), dr.get("high"), (ipda.get("d20") or {}).get("high"),
                    (sd_targets or {}).get("sd_15") if (sd_targets or {}).get("direction", "").startswith("Bullish") else None,
                    (sd_targets or {}).get("sd_20") if (sd_targets or {}).get("direction", "").startswith("Bullish") else None,
                    (sd_targets or {}).get("sd_25") if (sd_targets or {}).get("direction", "").startswith("Bullish") else None,
                ]
                if p is not None and p > entry_mid + risk * 0.8
            )
        )

        tp1 = round(high_pools[0], 2) if len(high_pools) >= 1 else round(entry_mid + risk * 1.4, 2)
        if tp1 < entry_mid + risk * 1.1:
            tp1 = round(entry_mid + risk * 1.3, 2)
        tp2_cand = next((p for p in high_pools if p >= max(entry_mid + risk * 2.0, tp1 + risk * 0.6)), None)
        tp2 = round(tp2_cand, 2) if tp2_cand is not None else round(max(entry_mid + risk * 2.3, tp1 + risk * 0.9), 2)
        tp3_cand = next((p for p in high_pools if p >= tp2 + risk * 0.8), None)
        tp3 = round(tp3_cand, 2) if tp3_cand is not None else round(max(entry_mid + risk * 3.4, tp2 + risk * 1.0), 2)

        rr1 = round((tp1 - entry_mid) / risk, 2) if risk > 0 else 0
        rr2 = round((tp2 - entry_mid) / risk, 2) if risk > 0 else 0
        rr3 = round((tp3 - entry_mid) / risk, 2) if risk > 0 else 0

        has_trigger = price_action.get("bull_sweep_disp") or price_action.get("bull_candle_trig")
        htf_ok = (htf_1h.get("trend_1h") == "Bullish") or htf_1h.get("bull_nested") or not htf_1h.get("available")

        if blackout.get("active"):
            status, status_tone = "NEWS BLACKOUT — WAIT", "bear"
        elif killzone.get("is_deadzone"):
            status, status_tone = "SESSION DEADZONE — WAIT", "neut"
        elif adr.get("exhausted") and not htf_1h.get("bull_nested"):
            status, status_tone = "ADR EXHAUSTED — NO CHASE", "neut"
        elif long_conf >= 62 and in_zone and has_trigger and htf_ok:
            status, status_tone = "ACTIVE BUY SETUP", "bull"
        elif long_conf >= 48:
            if not in_zone and cur > entry_high:
                status = "PENDING BUY LIMIT (PULLBACK)"
            elif not has_trigger:
                status = "WATCH BUY (AWAIT SWEEP/REJECTION)"
            else:
                status = "WATCH BUY (HTF FILTER)"
            status_tone = "neut"
        else:
            status, status_tone = "LOW CONFLUENCE — WAIT", "neut"

        reasons_all = long_reasons + shield_notes
        return {
            "direction": "LONG",
            "status": status,
            "status_tone": status_tone,
            "confidence": long_conf,
            "entry_source": entry_src,
            "entry_zone": f"{entry_low} – {entry_high}",
            "entry_low": entry_low,
            "entry_high": entry_high,
            "entry_price": entry_mid,
            "stop_loss": sl,
            "risk_pts": risk,
            "tp1": tp1, "rr1": rr1,
            "tp2": tp2, "rr2": rr2,
            "tp3": tp3, "rr3": rr3,
            "reasons": reasons_all or ["Counter-trend long idea only; await 1H/15m Bullish CHoCH."],
            "invalidation": f"15m close below {sl} invalidates bullish delivery. Move SL to BE ({entry_mid}) at TP1 ({tp1}).",
        }

    short_plan = _build_short_plan()
    long_plan = _build_long_plan()
    primary, alternative = (short_plan, long_plan) if short_conf >= long_conf else (long_plan, short_plan)

    return {
        "available": True,
        "atr_15m": atr,
        "gates": {
            "adr": adr,
            "blackout": blackout,
            "breadth": breadth,
            "htf_1h": htf_1h,
            "price_action": price_action,
        },
        "primary": primary,
        "alternative": alternative,
    }


def _simulate_outcome_with_be(future_bars: List[Dict], direction: str, entry: float, sl: float, tp1: float, tp2: float) -> Tuple[str, float]:
    """Simulate causal trade outcome with 'Move SL to Breakeven at TP1 (50% partial)' rule."""
    tp1_hit = False
    for bar in future_bars:
        if direction == "SHORT":
            if not tp1_hit:
                if bar["h"] >= sl:
                    return "SL LOSS", -1.0
                if bar["l"] <= tp2:
                    return "TP2 WIN", 2.0
                if bar["l"] <= tp1:
                    tp1_hit = True
            else:
                if bar["l"] <= tp2:
                    return "TP2 WIN", 1.75
                if bar["h"] >= entry:
                    return "TP1 BE WIN", 0.65
        else:
            if not tp1_hit:
                if bar["l"] <= sl:
                    return "SL LOSS", -1.0
                if bar["h"] >= tp2:
                    return "TP2 WIN", 2.0
                if bar["h"] >= tp1:
                    tp1_hit = True
            else:
                if bar["h"] >= tp2:
                    return "TP2 WIN", 1.75
                if bar["l"] <= entry:
                    return "TP1 BE WIN", 0.65
    return ("TP1 OPEN (BE)" if tp1_hit else "OPEN"), (0.5 if tp1_hit else 0.0)


def run_5d_walkforward_backtest(candles_15m: List[Dict]) -> Dict:
    """Strictly causal bar-by-bar walk-forward backtest on the real 5d/15m ^GDAXI bars."""
    if not candles_15m or len(candles_15m) < 55:
        return {"available": False, "trades": 0}

    trades: List[Dict] = []
    cooldown_until = 0
    n = len(candles_15m)

    for idx in range(40, n - 8):
        if idx < cooldown_until:
            continue
        kz = get_killzone_status(candles_15m[idx]["t"])
        if kz.get("is_deadzone"):
            continue

        window = candles_15m[: idx + 1]
        atr = _calc_atr_15m(window, 14)
        sh, sl_sw = _find_swings(window, left=2, right=2)
        fvgs, ifvgs = _detect_fvgs_and_ifvgs(window)
        trend, _, obs, breakers = _detect_structure_obs_and_breakers(window, sh, sl_sw, fvgs)
        cur = window[-1]["c"]
        prev = window[-2]

        body = abs(window[-1]["c"] - window[-1]["o"])
        up_wick = window[-1]["h"] - max(window[-1]["o"], window[-1]["c"])
        dn_wick = min(window[-1]["o"], window[-1]["c"]) - window[-1]["l"]

        direction = None
        entry = cur
        sl_px = cur
        setup_name = ""

        # Bearish Killzone FVG/OB + Pin/Engulfing
        if trend == "Bearish":
            bear_zones = [f for f in fvgs if f["type"] == "bearish"] + [o for o in obs if o["type"] == "bearish"]
            near_bear = [z for z in bear_zones if z["bottom"] - atr * 0.4 <= window[-1]["h"] <= z["top"] + atr * 0.5]
            bear_rej = (window[-1]["c"] < window[-1]["o"]) and (up_wick >= body * 1.2 or (prev["c"] > prev["o"] and window[-1]["c"] < prev["o"]))
            if near_bear and bear_rej:
                direction = "SHORT"
                z = near_bear[-1]
                sl_px = round(max(z["top"], window[-1]["h"]) + max(cur * 0.0005, atr * 0.45), 2)
                setup_name = "KZ Bearish POI + Rejection"

        # Bullish Killzone FVG/OB + Pin/Engulfing
        if direction is None and trend == "Bullish":
            bull_zones = [f for f in fvgs if f["type"] == "bullish"] + [o for o in obs if o["type"] == "bullish"]
            near_bull = [z for z in bull_zones if z["bottom"] - atr * 0.5 <= window[-1]["l"] <= z["top"] + atr * 0.4]
            bull_rej = (window[-1]["c"] > window[-1]["o"]) and (dn_wick >= body * 1.2 or (prev["c"] < prev["o"] and window[-1]["c"] > prev["o"]))
            if near_bull and bull_rej:
                direction = "LONG"
                z = near_bull[-1]
                sl_px = round(min(z["bottom"], window[-1]["l"]) - max(cur * 0.0005, atr * 0.45), 2)
                setup_name = "KZ Bullish POI + Rejection"

        if direction is None:
            continue

        risk = abs(entry - sl_px)
        if risk < max(cur * 0.0008, atr * 0.45) or risk > atr * 3.2:
            continue

        tp1 = round(entry - risk * 1.3 if direction == "SHORT" else entry + risk * 1.3, 2)
        tp2 = round(entry - risk * 2.2 if direction == "SHORT" else entry + risk * 2.2, 2)
        outcome, r_res = _simulate_outcome_with_be(candles_15m[idx + 1 : idx + 25], direction, entry, sl_px, tp1, tp2)
        if outcome == "OPEN":
            continue

        dt_de, tz = to_frankfurt_dt(window[-1]["t"])
        trades.append({
            "time": dt_de.strftime("%m-%d %H:%M ") + tz,
            "direction": direction,
            "setup": setup_name,
            "entry": round(entry, 2),
            "sl": sl_px,
            "tp1": tp1,
            "tp2": tp2,
            "outcome": outcome,
            "r": round(r_res, 2),
        })
        cooldown_until = idx + 6

    closed = [t for t in trades if t["outcome"] in ("TP2 WIN", "TP1 BE WIN", "SL LOSS", "TP1 OPEN (BE)")]
    wins = sum(1 for t in closed if t["r"] > 0)
    losses = sum(1 for t in closed if t["r"] < 0)
    gross_win = sum(t["r"] for t in closed if t["r"] > 0)
    gross_loss = abs(sum(t["r"] for t in closed if t["r"] < 0))
    win_rate = round((wins / len(closed)) * 100.0, 1) if closed else 0.0
    pf = round(gross_win / gross_loss, 2) if gross_loss > 0 else (9.99 if gross_win > 0 else 0.0)
    net_r = round(sum(t["r"] for t in closed), 2)

    return {
        "available": True,
        "trades_count": len(closed),
        "wins": wins,
        "losses": losses,
        "win_rate_pct": win_rate,
        "profit_factor": pf,
        "net_r": net_r,
        "recent_trades": trades[-8:][::-1],
    }


def update_and_grade_signal_ledger(
    ledger_path: Path,
    primary_sig: Optional[Dict],
    candles_15m: List[Dict],
) -> Dict:
    entries: List[Dict] = []
    if ledger_path.exists():
        try:
            entries = json.loads(ledger_path.read_text(encoding="utf-8"))
        except Exception:
            entries = []

    # Grade any open entries against newer 15m candles
    for item in entries:
        if item.get("status") in ("TP2 WIN", "TP1 BE WIN", "SL LOSS"):
            continue
        future = [c for c in candles_15m if c["t"] > item.get("created_ts", 0)]
        if future:
            out, r_val = _simulate_outcome_with_be(
                future, item["direction"], item["entry"], item["sl"], item["tp1"], item["tp2"]
            )
            item["status"] = out
            item["r"] = round(r_val, 2)

    # Log new high-confluence signal if >= 60% and not deadzone/blackout (deduped by 4h + direction)
    now_ts = int(time.time())
    if primary_sig and primary_sig.get("confidence", 0) >= 60 and "DEADZONE" not in primary_sig.get("status", "") and "BLACKOUT" not in primary_sig.get("status", ""):
        already_logged = any(
            abs(now_ts - e.get("created_ts", 0)) < 14400 and e.get("direction") == primary_sig["direction"]
            and abs(e.get("entry", 0) - primary_sig["entry_price"]) < max(primary_sig["entry_price"] * 0.0014, 5.0)
            for e in entries
        )
        if not already_logged:
            dt_de, tz = to_frankfurt_dt(now_ts)
            entries.append({
                "id": f"sig-{now_ts}",
                "created_ts": now_ts,
                "time": dt_de.strftime("%m-%d %H:%M ") + tz,
                "direction": primary_sig["direction"],
                "setup": primary_sig["entry_source"],
                "confidence": primary_sig["confidence"],
                "entry": primary_sig["entry_price"],
                "sl": primary_sig["stop_loss"],
                "tp1": primary_sig["tp1"],
                "tp2": primary_sig["tp2"],
                "status": "OPEN",
                "r": 0.0,
            })

    entries = entries[-60:]
    try:
        ledger_path.write_text(json.dumps(entries, indent=2), encoding="utf-8")
    except Exception:
        pass

    graded = [e for e in entries if e.get("status") in ("TP2 WIN", "TP1 BE WIN", "SL LOSS")]
    wins = sum(1 for e in graded if e.get("r", 0) > 0)
    win_rate = round((wins / len(graded)) * 100.0, 1) if graded else None
    net_r = round(sum(e.get("r", 0) for e in graded), 2)

    return {
        "total_logged": len(entries),
        "graded_count": len(graded),
        "wins": wins,
        "win_rate_pct": win_rate,
        "net_r": net_r,
        "entries": entries[-10:][::-1],
    }


def analyze_smc_suite(
    candles_15m: List[Dict],
    candles_daily: List[Dict],
    stoxx_15m: List[Dict],
    spx_15m: List[Dict],
    overall_score: int,
    overall_label: str,
    macro_quotes: Optional[List[Dict]] = None,
    candles_1h: Optional[List[Dict]] = None,
    dax_constituents: Optional[List[Dict]] = None,
    catalysts: Optional[List[Dict]] = None,
    ledger_path: Optional[Path] = None,
    instrument: str = "DAX",
) -> Dict:
    killzone = get_killzone_status(instrument=instrument)
    if not candles_15m:
        return {"killzone": killzone, "available": False}

    sh, sl = _find_swings(candles_15m, left=3, right=3)
    fvgs, ifvgs = _detect_fvgs_and_ifvgs(candles_15m)
    trend, events, obs, breakers = _detect_structure_obs_and_breakers(candles_15m, sh, sl, fvgs)
    liquidity = compute_liquidity_and_range(candles_15m, candles_daily, instrument=instrument)
    cur_price = liquidity.get("current_price", candles_15m[-1]["c"])
    ipda = compute_ipda_lookbacks(candles_daily, cur_price)
    po3 = compute_power_of_three(candles_15m, candles_daily, overall_score, instrument=instrument)
    ote, sd_targets = compute_ote_and_sd(candles_15m, sh, sl, trend, fvgs)
    intermarket = compute_intermarket_triad(macro_quotes or [], instrument=instrument)
    base_lbl = "Gold (GC=F)" if instrument == "GOLD" else ("Bitcoin (BTC-USD)" if instrument == "BTC" else "DAX 40")
    peer1_lbl = "Silver (SI=F)" if instrument == "GOLD" else ("Ethereum (ETH-USD)" if instrument == "BTC" else "Euro Stoxx 50")
    smt_stoxx = detect_smt_divergence(candles_15m, stoxx_15m, peer1_lbl, base_name=base_lbl)
    smt_spx = detect_smt_divergence(candles_15m, spx_15m, "S&P 500", base_name=base_lbl)

    atr = _calc_atr_15m(candles_15m, 14)
    adr = compute_adr_metrics(candles_daily, candles_15m)
    blackout = check_news_blackout(catalysts)
    breadth = analyze_dax_breadth(dax_constituents)
    htf_1h = detect_htf_1h_context(candles_1h, cur_price, ipda.get("daily_fvgs", []))
    price_action = detect_eqh_eql_and_sweep_displacement(candles_15m, sh, sl, fvgs, ifvgs, liquidity, atr)

    execution = build_smc_execution_matrix(
        overall_score, overall_label, liquidity, trend, fvgs, ifvgs, breakers, ote, po3, smt_stoxx, smt_spx, killzone
    )
    trade_signals = generate_smc_trade_signals(
        candles_15m, sh, sl, trend, fvgs, ifvgs, obs, breakers,
        liquidity, ipda, po3, ote, sd_targets, smt_stoxx, smt_spx,
        intermarket, killzone, overall_score, overall_label,
        htf_1h=htf_1h, adr=adr, blackout=blackout, breadth=breadth, price_action=price_action,
    )

    walkforward = run_5d_walkforward_backtest(candles_15m)
    l_path = ledger_path or (Path(__file__).resolve().parent / "signal_history.json")
    ledger = update_and_grade_signal_ledger(l_path, trade_signals.get("primary"), candles_15m)

    chart_candles = candles_15m[-90:]
    min_idx = candles_15m.index(chart_candles[0]) if chart_candles else 0

    return {
        "available": True,
        "instrument": instrument,
        "killzone": killzone,
        "structure_trend": trend,
        "structure_events": [e for e in events if e["idx"] >= min_idx],
        "fvgs": fvgs,
        "ifvgs": ifvgs,
        "order_blocks": obs,
        "breakers": breakers,
        "liquidity": liquidity,
        "ipda": ipda,
        "power_of_3": po3,
        "ote": ote,
        "sd_targets": sd_targets,
        "intermarket": intermarket,
        "smt": {"stoxx50": smt_stoxx, "sp500": smt_spx},
        "execution": execution,
        "signals": trade_signals,
        "backtest": walkforward,
        "ledger": ledger,
        "candles_15m": chart_candles,
    }

# ==============================================================================
# 3. LIVE BILINGUAL NEWS, 10 CROSS-ASSETS, 20 STOCKS, OHLC, CATALYSTS & HISTORY
# ==============================================================================

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9,de;q=0.8",
}
YAHOO_HEADERS = {"User-Agent": "Mozilla/5.0"}
HISTORY_FILE = Path(__file__).resolve().parent / "dax_history.json"
GOLD_HISTORY_FILE = Path(__file__).resolve().parent / "gold_history.json"
BTC_HISTORY_FILE = Path(__file__).resolve().parent / "btc_history.json"

NEWS_FEEDS = [
    {"id": "dax_direct", "name": "DAX 40 & Frankfurt Equities", "category": "dax_bluechips",
     "url": "https://news.google.com/rss/search?q=%22DAX%22+OR+%22DAX+40%22+Frankfurt+stocks&hl=en-US&gl=US&ceid=US:en"},
    {"id": "yahoo_gdaxi", "name": "Yahoo Finance DAX", "category": "dax_bluechips",
     "url": "https://feeds.finance.yahoo.com/rss/2.0/headline?s=%5EGDAXI&region=US&lang=en-US"},
    {"id": "german_macro", "name": "German Economy & Macro", "category": "german_macro",
     "url": "https://news.google.com/rss/search?q=Germany+economy+OR+Bundesbank+OR+Ifo+OR+ZEW+OR+German+PMI+OR+German+inflation+OR+Destatis&hl=en-US&gl=US&ceid=US:en"},
    {"id": "dw_business", "name": "DW Business Germany", "category": "german_macro",
     "url": "https://rss.dw.com/xml/rss-en-bus"},
    {"id": "ecb_official", "name": "ECB Official Press", "category": "ecb_rates",
     "url": "https://www.ecb.europa.eu/rss/press.html"},
    {"id": "ecb_eurozone", "name": "ECB & Eurozone Policy", "category": "ecb_rates",
     "url": "https://news.google.com/rss/search?q=ECB+interest+rates+OR+Lagarde+OR+Eurozone+inflation+OR+EUR+USD&hl=en-US&gl=US&ceid=US:en"},
    {"id": "dax_bluechips", "name": "DAX Heavyweights", "category": "dax_bluechips",
     "url": "https://news.google.com/rss/search?q=(SAP+OR+Siemens+OR+Allianz+OR+Airbus+OR+Volkswagen+OR+Mercedes+OR+BASF+OR+Deutsche+Bank+OR+Rheinmetall)+stock+OR+earnings&hl=en-US&gl=US&ceid=US:en"},
    {"id": "trade_tariffs", "name": "Global Trade & Tariffs", "category": "trade_tariffs",
     "url": "https://news.google.com/rss/search?q=(EU+OR+Germany+OR+China)+tariffs+OR+trade+war+OR+autos+exports&hl=en-US&gl=US&ceid=US:en"},
    {"id": "energy_europe", "name": "European Energy & Oil", "category": "energy_commodities",
     "url": "https://news.google.com/rss/search?q=European+natural+gas+TTF+OR+oil+price+OPEC+Germany+energy&hl=en-US&gl=US&ceid=US:en"},
    {"id": "cnbc_europe", "name": "CNBC Europe Markets", "category": "global_us",
     "url": "https://search.cnbc.com/rs/search/combinedcms/view.xml?partnerId=wrss01&id=19794221"},
    {"id": "global_spillover", "name": "US Fed & Global Macro", "category": "global_us",
     "url": "https://news.google.com/rss/search?q=(Federal+Reserve+OR+US+tariffs+OR+S%26P+500+OR+Wall+Street+OR+US+CPI)+markets+Europe&hl=en-US&gl=US&ceid=US:en"},
    {"id": "gnews_de_dax", "name": "Google News DE (DAX/EZB)", "category": "dax_bluechips",
     "url": "https://news.google.com/rss/search?q=DAX+OR+EZB+OR+Bundesbank+OR+Ifo+OR+Konjunktur&hl=de&gl=DE&ceid=DE:de"},
    {"id": "tagesschau_wirt", "name": "tagesschau Wirtschaft", "category": "german_macro",
     "url": "https://www.tagesschau.de/wirtschaft/index~rss2.xml"},
    {"id": "handelsblatt_de", "name": "Handelsblatt Wirtschaft", "category": "dax_bluechips",
     "url": "https://www.handelsblatt.com/contentexport/feed/wirtschaft"},
    {"id": "finanzen_de", "name": "finanzen.net News", "category": "dax_bluechips",
     "url": "https://www.finanzen.net/rss/news"},
]

GOLD_NEWS_FEEDS = [
    {"id": "gold_xau_en", "name": "Gold & Bullion (EN)", "category": "gold_fed_yields",
     "url": "https://news.google.com/rss/search?q=%22gold+price%22+OR+XAUUSD+OR+bullion+OR+%22Federal+Reserve%22+gold&hl=en-US&gl=US&ceid=US:en"},
    {"id": "gold_macro_en", "name": "Gold Rates, DXY & Central Banks", "category": "gold_central_banks",
     "url": "https://news.google.com/rss/search?q=(gold+price+DXY+OR+%22real+yields%22+gold+OR+central+bank+gold+reserves+OR+gold+ETF)&hl=en-US&gl=US&ceid=US:en"},
    {"id": "gold_de", "name": "Goldpreis & Edelmetalle (DE)", "category": "gold_inflation_macro",
     "url": "https://news.google.com/rss/search?q=Goldpreis+OR+%22Gold+Kurs%22+OR+Edelmetall+Fed+Zinsen&hl=de&gl=DE&ceid=DE:de"},
]


BTC_NEWS_FEEDS = [
    {"id": "btc_coindesk", "name": "CoinDesk Bitcoin", "category": "btc_market_sentiment",
     "url": "https://www.coindesk.com/arc/outboundfeeds/rss/"},
    {"id": "btc_cointelegraph", "name": "Cointelegraph", "category": "btc_market_sentiment",
     "url": "https://cointelegraph.com/rss"},
    {"id": "btc_echo_de", "name": "BTC-ECHO (DE)", "category": "btc_etf_institutional",
     "url": "https://www.btc-echo.de/feed/"},
    {"id": "btc_gnews_en", "name": "Bitcoin ETF & Macro (EN)", "category": "btc_etf_institutional",
     "url": "https://news.google.com/rss/search?q=Bitcoin+OR+BTC+ETF+OR+crypto+macro&hl=en-US&gl=US&ceid=US:en"},
    {"id": "btc_gnews_de", "name": "Bitcoin & Krypto Kurs (DE)", "category": "btc_fed_liquidity",
     "url": "https://news.google.com/rss/search?q=Bitcoin+OR+Krypto+Kurs&hl=de&gl=DE&ceid=DE:de"},
]

MARKET_SYMBOLS = [
    {"symbol": "^GDAXI", "name": "DAX 40", "role": "Primary Index", "unit": "pts"},
    {"symbol": "GC=F", "name": "Gold (GC=F)", "role": "Second Tracked Instrument", "unit": "$"},
    {"symbol": "BTC-USD", "name": "Bitcoin (BTC-USD)", "role": "Third Tracked Instrument", "unit": "$"},
    {"symbol": "ETH-USD", "name": "Ethereum (ETH-USD)", "role": "BTC SMT Peer", "unit": "$"},
    {"symbol": "EURUSD=X", "name": "EUR / USD", "role": "FX / Exporter Driver", "unit": ""},
    {"symbol": "DX-Y.NYB", "name": "US Dollar (DXY)", "role": "Gold Inverse Anchor", "unit": ""},
    {"symbol": "SI=F", "name": "Silver (SI=F)", "role": "Gold SMT Peer", "unit": "$"},
    {"symbol": "^STOXX50E", "name": "Euro Stoxx 50", "role": "Eurozone Peer", "unit": "pts"},
    {"symbol": "^GSPC", "name": "S&P 500", "role": "US Risk Spillover", "unit": "pts"},
    {"symbol": "TTF=F", "name": "EU Nat Gas (TTF)", "role": "Industrial Energy", "unit": "€"},
    {"symbol": "BZ=F", "name": "Brent Crude", "role": "Oil / Inflation", "unit": "$"},
    {"symbol": "^HSI", "name": "Hang Seng (China)", "role": "DAX Export Demand", "unit": "pts"},
    {"symbol": "^VIX", "name": "CBOE VIX", "role": "Global Volatility", "unit": ""},
    {"symbol": "^TNX", "name": "US 10Y Yield", "role": "Global Rate Anchor", "unit": "%"},
]

DAX_CONSTITUENTS = [
    {"symbol": "SAP.DE", "name": "SAP SE", "sector": "Tech & Semis"},
    {"symbol": "IFX.DE", "name": "Infineon", "sector": "Tech & Semis"},
    {"symbol": "SIE.DE", "name": "Siemens AG", "sector": "Industrials & Defense"},
    {"symbol": "AIR.DE", "name": "Airbus SE", "sector": "Industrials & Defense"},
    {"symbol": "RHM.DE", "name": "Rheinmetall", "sector": "Industrials & Defense"},
    {"symbol": "ALV.DE", "name": "Allianz SE", "sector": "Financials"},
    {"symbol": "MUV2.DE", "name": "Munich Re", "sector": "Financials"},
    {"symbol": "DBK.DE", "name": "Deutsche Bank", "sector": "Financials"},
    {"symbol": "CBK.DE", "name": "Commerzbank", "sector": "Financials"},
    {"symbol": "VOW3.DE", "name": "Volkswagen", "sector": "Autos"},
    {"symbol": "MBG.DE", "name": "Mercedes-Benz", "sector": "Autos"},
    {"symbol": "BMW.DE", "name": "BMW AG", "sector": "Autos"},
    {"symbol": "BAS.DE", "name": "BASF SE", "sector": "Chemicals & Energy"},
    {"symbol": "BAYN.DE", "name": "Bayer AG", "sector": "Chemicals & Energy"},
    {"symbol": "RWE.DE", "name": "RWE AG", "sector": "Chemicals & Energy"},
    {"symbol": "EOAN.DE", "name": "E.ON SE", "sector": "Chemicals & Energy"},
    {"symbol": "DTE.DE", "name": "Deutsche Telekom", "sector": "Consumer & Healthcare"},
    {"symbol": "ADS.DE", "name": "Adidas AG", "sector": "Consumer & Healthcare"},
    {"symbol": "MRK.DE", "name": "Merck KGaA", "sector": "Consumer & Healthcare"},
    {"symbol": "HEN3.DE", "name": "Henkel AG", "sector": "Consumer & Healthcare"},
]

CATALYST_SCHEDULE = [
    {"date": "2026-11-24", "time": "10:00 CET", "event": "Germany Ifo Business Climate Index (Nov)", "impact_type": "direct", "importance": "High", "query": "Germany Ifo Business Climate", "note": "Key domestic cyclical gauge for Siemens, BASF, and German industrials (prior: 90.2)."},
    {"date": "2026-11-26", "time": "13:30 CET", "event": "ECB Monetary Policy Meeting Accounts", "impact_type": "indirect", "importance": "Medium", "query": "ECB monetary policy accounts", "note": "Reveals Governing Council split on rate path and inflation persistence."},
    {"date": "2026-11-30", "time": "14:00 CET", "event": "Germany CPI Flash Inflation (Nov)", "impact_type": "direct", "importance": "High", "query": "Germany inflation CPI Destatis", "note": "Direct driver of Bund yields and ECB rate expectations."},
    {"date": "2026-12-01", "time": "11:00 CET", "event": "Eurozone HICP Flash Inflation & German PMI", "impact_type": "indirect", "importance": "High", "query": "Eurozone inflation HICP PMI", "note": "Sets tone for December ECB Governing Council rate decision."},
    {"date": "2026-12-04", "time": "14:30 CET", "event": "US Nonfarm Payrolls (Nov BLS Jobs Report)", "impact_type": "indirect", "importance": "High", "query": "US nonfarm payrolls jobs report", "note": "Major global risk-appetite & US Treasury yield catalyst affecting DAX afternoon trade."},
    {"date": "2026-12-09", "time": "20:00 CET", "event": "US Federal Reserve FOMC Rate Decision & Dot Plot", "impact_type": "indirect", "importance": "High", "query": "FOMC Federal Reserve rate decision", "note": "Drives EUR/USD, global equity multiples, and Wall Street spillover."},
    {"date": "2026-12-15", "time": "11:00 CET", "event": "Germany ZEW Economic Sentiment (Dec)", "impact_type": "direct", "importance": "High", "query": "Germany ZEW economic sentiment", "note": "Institutional analyst expectations gauge (Nov beat at 35.6)."},
    {"date": "2026-12-17", "time": "10:00 CET", "event": "Germany Ifo Business Climate Index (Dec)", "impact_type": "direct", "importance": "High", "query": "Germany Ifo Business Climate", "note": "Year-end corporate sentiment check for DAX manufacturing & services."},
    {"date": "2026-12-17", "time": "14:15 CET", "event": "ECB Governing Council Rate Decision & Macro Projections", "impact_type": "indirect", "importance": "High", "query": "ECB interest rate decision Lagarde", "note": "Primary Eurozone monetary policy catalyst + new ECB staff GDP/CPI forecasts."},
    {"date": "2027-01-14", "time": "13:30 CET", "event": "ECB Monetary Policy Accounts Release", "impact_type": "indirect", "importance": "Medium", "query": "ECB monetary policy accounts", "note": "Minutes from the December 17 ECB policy meeting."},
    {"date": "2027-01-27", "time": "20:00 CET", "event": "US FOMC Rate Decision", "impact_type": "indirect", "importance": "High", "query": "FOMC rate decision", "note": "First 2027 Fed policy decision."},
    {"date": "2027-02-04", "time": "14:15 CET", "event": "ECB Governing Council Rate Decision", "impact_type": "indirect", "importance": "High", "query": "ECB Governing Council rate decision", "note": "First 2027 ECB rate-setting decision."},
]


class _ParagraphExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.in_p = False
        self.skip_depth = 0
        self.buf: List[str] = []
        self.paragraphs: List[str] = []

    def handle_starttag(self, tag, attrs):
        t = tag.lower()
        if t in ("script", "style", "nav", "footer", "header", "aside"):
            self.skip_depth += 1
        elif t == "p" and self.skip_depth == 0:
            self.in_p = True
            self.buf = []

    def handle_endtag(self, tag):
        t = tag.lower()
        if t in ("script", "style", "nav", "footer", "header", "aside") and self.skip_depth > 0:
            self.skip_depth -= 1
        elif t == "p" and self.in_p:
            self.in_p = False
            txt = re.sub(r"\s+", " ", "".join(self.buf)).strip()
            if len(txt) > 55 and not any(s in txt.lower() for s in ["cookie", "subscribe", "sign in", "javascript", "all rights reserved"]):
                self.paragraphs.append(txt)

    def handle_data(self, data):
        if self.in_p and self.skip_depth == 0:
            self.buf.append(data)


def _http_get(url: str, headers: Dict[str, str], timeout: int = 10) -> Tuple[int, str, bytes]:
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.status, resp.geturl(), resp.read()


def get_upcoming_catalysts() -> List[Dict]:
    today_dt = datetime.now(tz=timezone.utc).date()
    out = []
    for item in CATALYST_SCHEDULE:
        ev_date = datetime.strptime(item["date"], "%Y-%m-%d").date()
        delta = (ev_date - today_dt).days
        if delta >= -1:
            out.append({
                **item,
                "days_away": delta,
                "killzone_note": classify_event_killzone(item.get("time", "")),
            })
    return out[:8]


def _load_history(history_path: Path = HISTORY_FILE) -> List[Dict]:
    try:
        if history_path.exists():
            data = json.loads(history_path.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return data[-500:]
    except Exception:
        pass
    return []


def _record_history_point(overall_score: int, direct_score: int, indirect_score: int, dax_price: Optional[float], history_path: Path = HISTORY_FILE) -> List[Dict]:
    history = _load_history(history_path)
    now_ts = int(time.time())
    bucket_ts = (now_ts // 300) * 300
    point = {
        "ts": now_ts, "bucket": bucket_ts,
        "iso": datetime.fromtimestamp(now_ts, tz=timezone.utc).isoformat(),
        "overall_score": overall_score, "direct_score": direct_score,
        "indirect_score": indirect_score, "dax_price": dax_price,
    }
    if history and history[-1].get("bucket") == bucket_ts:
        history[-1] = point
    else:
        history.append(point)
    history = history[-500:]
    try:
        history_path.write_text(json.dumps(history, indent=2), encoding="utf-8")
    except Exception:
        pass
    return history


def _parse_pub_date(date_str: Optional[str]) -> Tuple[float, str]:
    if not date_str:
        now = time.time()
        return now, datetime.fromtimestamp(now, tz=timezone.utc).isoformat()
    date_str = date_str.strip()
    try:
        dt = email.utils.parsedate_to_datetime(date_str)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.timestamp(), dt.astimezone(timezone.utc).isoformat()
    except Exception:
        pass
    try:
        dt = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.timestamp(), dt.astimezone(timezone.utc).isoformat()
    except Exception:
        now = time.time()
        return now, datetime.fromtimestamp(now, tz=timezone.utc).isoformat()


def _clean_html_summary(raw: str) -> str:
    text = _clean_text(raw)
    if len(text) > 340:
        text = text[:337].rsplit(" ", 1)[0] + "..."
    return text


def _split_google_source(title: str, default_source: str) -> Tuple[str, str]:
    if " - " in title:
        parts = title.rsplit(" - ", 1)
        if len(parts[1]) <= 45 and len(parts[0]) > 15:
            return parts[0].strip(), parts[1].strip()
    return title.strip(), default_source


def _fetch_rss(feed_cfg: Dict, limit: int = 15, instrument: str = "DAX") -> List[Dict]:
    articles: List[Dict] = []
    try:
        status, _, raw_bytes = _http_get(feed_cfg["url"], HEADERS, timeout=10)
        if status != 200:
            return []
        root = ET.fromstring(raw_bytes)
    except Exception:
        return []

    items = root.findall(".//item") or root.findall(".//{http://purl.org/rss/1.0/}item") or root.findall(".//{http://www.w3.org/2005/Atom}entry")

    for item in items[:limit]:
        def find_text(*tags):
            for t in tags:
                el = item.find(t)
                if el is not None and el.text:
                    return el.text.strip()
            return ""

        raw_title = find_text("title", "{http://purl.org/rss/1.0/}title", "{http://www.w3.org/2005/Atom}title")
        if not raw_title:
            continue
        link = find_text("link", "{http://purl.org/rss/1.0/}link")
        if not link:
            link_el = item.find("{http://www.w3.org/2005/Atom}link")
            if link_el is not None:
                link = link_el.attrib.get("href", "")

        pub_raw = find_text("pubDate", "{http://purl.org/dc/elements/1.1/}date", "{http://www.w3.org/2005/Atom}updated", "{http://www.w3.org/2005/Atom}published")
        ts, iso_dt = _parse_pub_date(pub_raw)
        desc_raw = find_text("description", "{http://purl.org/rss/1.0/}description", "{http://www.w3.org/2005/Atom}summary")
        summary = _clean_html_summary(desc_raw)

        source_el = item.find("source")
        explicit_source = source_el.text.strip() if (source_el is not None and source_el.text) else ""
        clean_title, parsed_source = _split_google_source(raw_title, feed_cfg["name"])
        source = explicit_source or parsed_source

        if summary and clean_title[:35].lower() in summary.lower() and len(summary) < len(clean_title) + 45:
            summary = ""

        if instrument == "DAX" and feed_cfg["id"] in ("cnbc_europe", "yahoo_gdaxi", "dw_business", "tagesschau_wirt", "handelsblatt_de", "finanzen_de"):
            if not is_relevant_to_dax(clean_title, summary):
                continue

        if instrument == "GOLD":
            analysis = analyze_gold_news(clean_title, summary, feed_cfg["category"])
        elif instrument == "BTC":
            analysis = analyze_btc_news(clean_title, summary, feed_cfg["category"])
        else:
            analysis = analyze_dax_news(clean_title, summary, feed_cfg["category"])
        article_id = hashlib.md5(f"{clean_title.lower()}|{link}".encode("utf-8")).hexdigest()[:12]
        articles.append({
            "id": article_id, "title": clean_title, "summary": summary,
            "url": link, "source": source, "feed_name": feed_cfg["name"],
            "published_ts": ts, "published_at": iso_dt, **analysis,
        })
    return articles


def _fetch_yahoo_quote(item: Dict, include_series: bool = False) -> Optional[Dict]:
    sym = item["symbol"]
    rng = "5d" if include_series else "2d"
    interval = "1h" if include_series else "1d"
    url = f"https://query2.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(sym)}?range={rng}&interval={interval}"
    try:
        status, _, raw = _http_get(url, YAHOO_HEADERS, timeout=8)
        if status != 200:
            return None
        data = json.loads(raw.decode("utf-8"))
        res = data["chart"]["result"][0]
        meta = res["meta"]
        price = meta.get("regularMarketPrice")
        prev = meta.get("chartPreviousClose") or meta.get("previousClose")
        if price is None:
            return None
        change = (price - prev) if prev else 0.0
        change_pct = ((change / prev) * 100.0) if prev else 0.0
        out = {
            **item,
            "price": round(float(price), 4 if sym == "EURUSD=X" else 2),
            "prev_close": round(float(prev), 4 if sym == "EURUSD=X" else 2) if prev else None,
            "change": round(float(change), 4 if sym == "EURUSD=X" else 2),
            "change_pct": round(float(change_pct), 2),
            "market_state": meta.get("marketState", ""),
        }
        if include_series:
            timestamps = res.get("timestamp") or []
            closes = (res.get("indicators", {}).get("quote") or [{}])[0].get("close") or []
            out["series"] = [{"t": t, "v": round(float(c), 2)} for t, c in zip(timestamps, closes) if c is not None]
        return out
    except Exception:
        return None


def _fetch_yahoo_ohlc(symbol: str, rng: str, interval: str) -> List[Dict]:
    url = f"https://query2.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(symbol)}?range={rng}&interval={interval}"
    try:
        status, _, raw = _http_get(url, YAHOO_HEADERS, timeout=8)
        if status != 200:
            return []
        data = json.loads(raw.decode("utf-8"))
        res = data["chart"]["result"][0]
        ts = res.get("timestamp") or []
        q = (res.get("indicators", {}).get("quote") or [{}])[0]
        candles = []
        for t, o, h, l, c in zip(ts, q.get("open") or [], q.get("high") or [], q.get("low") or [], q.get("close") or []):
            if None not in (o, h, l, c):
                candles.append({"t": int(t), "o": round(float(o), 2), "h": round(float(h), 2), "l": round(float(l), 2), "c": round(float(c), 2)})
        return candles
    except Exception:
        return []


def _deduplicate_articles(articles: List[Dict]) -> List[Dict]:
    seen_keys = set()
    unique: List[Dict] = []
    for art in sorted(articles, key=lambda x: x["published_ts"], reverse=True):
        norm = re.sub(r"[^a-z0-9äöüß]", "", art["title"].lower())[:48]
        if not norm or norm in seen_keys:
            continue
        seen_keys.add(norm)
        unique.append(art)
    return unique


def _compute_sector_heatmap(articles: List[Dict], constituents: List[Dict]) -> List[Dict]:
    sectors_order = [
        "Tech & Semis", "Industrials & Defense", "Financials",
        "Autos", "Chemicals & Energy", "Consumer & Healthcare",
    ]
    heatmap = []
    for sec in sectors_order:
        stocks = [c for c in constituents if c.get("sector") == sec]
        avg_chg = round(sum(s["change_pct"] for s in stocks) / len(stocks), 2) if stocks else 0.0
        sec_arts = [a for a in articles if sec in (a.get("sectors") or [])]
        avg_sent = int(round(sum(a["sentiment_score"] for a in sec_arts) / len(sec_arts))) if sec_arts else 0
        heatmap.append({
            "sector": sec, "avg_change_pct": avg_chg,
            "avg_sentiment": avg_sent, "news_count": len(sec_arts), "stocks": stocks,
        })
    return heatmap


def _compute_dashboard_analytics(articles: List[Dict], channels_cfg: Optional[Dict] = None, asset_name: str = "DAX 40") -> Dict:
    channels_cfg = channels_cfg or CHANNEL_RULES
    if not articles:
        return {
            "overall_score": 0, "overall_label": "Neutral", "total_articles": 0,
            "bullish_count": 0, "neutral_count": 0, "bearish_count": 0,
            "direct_score": 0, "direct_count": 0, "indirect_score": 0, "indirect_count": 0,
            "en_count": 0, "de_count": 0, "channels": [],
            "briefing": {"headline": "Awaiting live fundamental feed data.", "bullish_drivers": [], "bearish_drivers": []},
        }

    now = time.time()
    weighted_sum = weight_total = 0.0
    bullish_count = neutral_count = bearish_count = en_count = de_count = 0
    direct_scores: List[float] = []
    indirect_scores: List[float] = []
    channel_buckets: Dict[str, List[Dict]] = {k: [] for k in channels_cfg.keys()}

    for art in articles:
        sc = art["sentiment_score"]
        if sc >= 12:
            bullish_count += 1
        elif sc <= -12:
            bearish_count += 1
        else:
            neutral_count += 1
        if art.get("lang") == "DE":
            de_count += 1
        else:
            en_count += 1
        (direct_scores if art["impact_type"] == "direct" else indirect_scores).append(sc)
        if art["channel_key"] in channel_buckets:
            channel_buckets[art["channel_key"]].append(art)

        age_hours = max(0.0, (now - art["published_ts"]) / 3600.0)
        recency_w = 1.0 / (1.0 + age_hours / 36.0)
        impact_w = {"High": 1.6, "Medium": 1.15, "Low": 0.75}.get(art["impact_level"], 1.0)
        direct_w = 1.25 if art["impact_type"] == "direct" else 1.0
        w = recency_w * impact_w * direct_w
        weighted_sum += sc * w
        weight_total += w

    overall_score = int(round(weighted_sum / weight_total)) if weight_total > 0 else 0
    if overall_score >= 25:
        overall_label = "Bullish"
    elif overall_score >= 8:
        overall_label = "Slightly Bullish"
    elif overall_score <= -25:
        overall_label = "Bearish"
    elif overall_score <= -8:
        overall_label = "Slightly Bearish"
    else:
        overall_label = "Neutral"

    direct_score = int(round(sum(direct_scores) / len(direct_scores))) if direct_scores else 0
    indirect_score = int(round(sum(indirect_scores) / len(indirect_scores))) if indirect_scores else 0

    channels_summary = []
    for k, cfg in channels_cfg.items():
        items = channel_buckets[k]
        avg = int(round(sum(x["sentiment_score"] for x in items) / len(items))) if items else 0
        channels_summary.append({
            "key": k, "label": cfg["label"], "impact_type": cfg["impact_type"],
            "count": len(items), "avg_score": avg,
        })

    top_bullish = sorted(
        [a for a in articles if a["sentiment_score"] >= 12],
        key=lambda x: x["sentiment_score"] * (1.3 if x["impact_type"] == "direct" else 1.0),
        reverse=True,
    )[:3]
    top_bearish = sorted(
        [a for a in articles if a["sentiment_score"] <= -12],
        key=lambda x: abs(x["sentiment_score"]) * (1.3 if x["impact_type"] == "direct" else 1.0),
        reverse=True,
    )[:3]

    if overall_score >= 12:
        stance_line = f"{asset_name} fundamental sentiment is {overall_label.lower()} ({overall_score:+d}), supported by {bullish_count} positive vs. {bearish_count} negative catalysts across EN & DE feeds."
    elif overall_score <= -12:
        stance_line = f"{asset_name} fundamental sentiment leans {overall_label.lower()} ({overall_score:+d}), with {bearish_count} headwinds outweighing {bullish_count} positive catalysts across tracked EN & DE feeds."
    else:
        stance_line = f"{asset_name} fundamental sentiment is balanced/mixed ({overall_score:+d}), with {bullish_count} bullish and {bearish_count} bearish signals competing across German and global macro drivers."

    return {
        "overall_score": overall_score, "overall_label": overall_label,
        "total_articles": len(articles), "bullish_count": bullish_count,
        "neutral_count": neutral_count, "bearish_count": bearish_count,
        "direct_score": direct_score, "direct_count": len(direct_scores),
        "indirect_score": indirect_score, "indirect_count": len(indirect_scores),
        "en_count": en_count, "de_count": de_count,
        "channels": channels_summary,
        "briefing": {
            "headline": stance_line,
            "bullish_drivers": [{"title": a["title"], "source": a["source"], "score": a["sentiment_score"], "lang": a.get("lang", "EN")} for a in top_bullish],
            "bearish_drivers": [{"title": a["title"], "source": a["source"], "score": a["sentiment_score"], "lang": a.get("lang", "EN")} for a in top_bearish],
        },
    }


def fetch_full_dashboard() -> Dict:
    raw_articles: List[Dict] = []
    raw_gold_articles: List[Dict] = []
    raw_btc_articles: List[Dict] = []
    macro_quotes_map: Dict[str, Dict] = {}
    stock_quotes_map: Dict[str, Dict] = {}

    with ThreadPoolExecutor(max_workers=20) as pool:
        feed_futs = [pool.submit(_fetch_rss, f, 15, "DAX") for f in NEWS_FEEDS]
        gold_futs = [pool.submit(_fetch_rss, f, 18, "GOLD") for f in GOLD_NEWS_FEEDS]
        btc_futs = [pool.submit(_fetch_rss, f, 15, "BTC") for f in BTC_NEWS_FEEDS]
        for fut in as_completed(feed_futs):
            raw_articles.extend(fut.result())
        for fut in as_completed(gold_futs):
            raw_gold_articles.extend(fut.result())
        for fut in as_completed(btc_futs):
            raw_btc_articles.extend(fut.result())

    with ThreadPoolExecutor(max_workers=3) as ypool:
        mfuts = {ypool.submit(_fetch_yahoo_quote, sym, sym["symbol"] in ("^GDAXI", "GC=F", "BTC-USD")): sym["symbol"] for sym in MARKET_SYMBOLS}
        sfuts = {ypool.submit(_fetch_yahoo_quote, st, False): st["symbol"] for st in DAX_CONSTITUENTS}
        f_dax15 = ypool.submit(_fetch_yahoo_ohlc, "^GDAXI", "5d", "15m")
        f_dax1h = ypool.submit(_fetch_yahoo_ohlc, "^GDAXI", "1mo", "1h")
        f_dax1d = ypool.submit(_fetch_yahoo_ohlc, "^GDAXI", "6mo", "1d")
        f_stx15 = ypool.submit(_fetch_yahoo_ohlc, "^STOXX50E", "5d", "15m")
        f_spx15 = ypool.submit(_fetch_yahoo_ohlc, "^GSPC", "5d", "15m")
        f_gld15 = ypool.submit(_fetch_yahoo_ohlc, "GC=F", "5d", "15m")
        f_gld1h = ypool.submit(_fetch_yahoo_ohlc, "GC=F", "1mo", "1h")
        f_gld1d = ypool.submit(_fetch_yahoo_ohlc, "GC=F", "6mo", "1d")
        f_slv15 = ypool.submit(_fetch_yahoo_ohlc, "SI=F", "5d", "15m")
        f_btc15 = ypool.submit(_fetch_yahoo_ohlc, "BTC-USD", "5d", "15m")
        f_btc1h = ypool.submit(_fetch_yahoo_ohlc, "BTC-USD", "1mo", "1h")
        f_btc1d = ypool.submit(_fetch_yahoo_ohlc, "BTC-USD", "6mo", "1d")
        f_eth15 = ypool.submit(_fetch_yahoo_ohlc, "ETH-USD", "5d", "15m")

        for fut in as_completed(mfuts):
            res = fut.result()
            if res:
                macro_quotes_map[mfuts[fut]] = res
        for fut in as_completed(sfuts):
            res = fut.result()
            if res:
                stock_quotes_map[sfuts[fut]] = res

        dax_15m = f_dax15.result()
        dax_1h = f_dax1h.result()
        dax_1d = f_dax1d.result()
        stoxx_15m = f_stx15.result()
        spx_15m = f_spx15.result()
        gold_15m = f_gld15.result()
        gold_1h = f_gld1h.result()
        gold_1d = f_gld1d.result()
        silver_15m = f_slv15.result()
        btc_15m = f_btc15.result()
        btc_1h = f_btc1h.result()
        btc_1d = f_btc1d.result()
        eth_15m = f_eth15.result()

    articles = _deduplicate_articles(raw_articles)[:160]
    analytics = _compute_dashboard_analytics(articles, channels_cfg=CHANNEL_RULES, asset_name="DAX 40")
    gold_articles = _deduplicate_articles(raw_gold_articles)[:80]
    gold_analytics = _compute_dashboard_analytics(gold_articles, channels_cfg=GOLD_CHANNEL_RULES, asset_name="Gold (XAU)")
    btc_articles = _deduplicate_articles(raw_btc_articles)[:80]
    btc_analytics = _compute_dashboard_analytics(btc_articles, channels_cfg=BTC_CHANNEL_RULES, asset_name="Bitcoin (BTC-USD)")

    macro_quotes = [macro_quotes_map[s["symbol"]] for s in MARKET_SYMBOLS if s["symbol"] in macro_quotes_map]
    stock_quotes = [stock_quotes_map[s["symbol"]] for s in DAX_CONSTITUENTS if s["symbol"] in stock_quotes_map]
    dax_q = next((m for m in macro_quotes if m["symbol"] == "^GDAXI"), None)
    dax_price = dax_q["price"] if dax_q else None
    gold_q = next((m for m in macro_quotes if m["symbol"] == "GC=F"), None)
    gold_price = gold_q["price"] if gold_q else None
    btc_q = next((m for m in macro_quotes if m["symbol"] == "BTC-USD"), None)
    btc_price = btc_q["price"] if btc_q else None

    history = _record_history_point(analytics["overall_score"], analytics["direct_score"], analytics["indirect_score"], dax_price, HISTORY_FILE)
    gold_history = _record_history_point(gold_analytics["overall_score"], gold_analytics["direct_score"], gold_analytics["indirect_score"], gold_price, GOLD_HISTORY_FILE)
    btc_history = _record_history_point(btc_analytics["overall_score"], btc_analytics["direct_score"], btc_analytics["indirect_score"], btc_price, BTC_HISTORY_FILE)
    sector_heatmap = _compute_sector_heatmap(articles, stock_quotes)
    catalysts = get_upcoming_catalysts()

    smc_data = analyze_smc_suite(
        dax_15m, dax_1d, stoxx_15m, spx_15m,
        analytics["overall_score"], analytics["overall_label"],
        macro_quotes=macro_quotes, candles_1h=dax_1h,
        dax_constituents=stock_quotes, catalysts=catalysts,
        ledger_path=Path(__file__).resolve().parent / "signal_history.json",
        instrument="DAX",
    )
    gold_smc = analyze_smc_suite(
        gold_15m, gold_1d, silver_15m, spx_15m,
        gold_analytics["overall_score"], gold_analytics["overall_label"],
        macro_quotes=macro_quotes, candles_1h=gold_1h,
        dax_constituents=None, catalysts=catalysts,
        ledger_path=Path(__file__).resolve().parent / "gold_signal_history.json",
        instrument="GOLD",
    )
    btc_smc = analyze_smc_suite(
        btc_15m, btc_1d, eth_15m, spx_15m,
        btc_analytics["overall_score"], btc_analytics["overall_label"],
        macro_quotes=macro_quotes, candles_1h=btc_1h,
        dax_constituents=None, catalysts=catalysts,
        ledger_path=Path(__file__).resolve().parent / "btc_signal_history.json",
        instrument="BTC",
    )

    return {
        "updated_at": datetime.now(tz=timezone.utc).isoformat(),
        "updated_ts": time.time(),
        "analytics": analytics,
        "macro_quotes": macro_quotes,
        "dax_constituents": stock_quotes,
        "sector_heatmap": sector_heatmap,
        "catalysts": catalysts,
        "history": history,
        "smc": smc_data,
        "articles": articles,
        "gold": {
            "analytics": gold_analytics,
            "smc": gold_smc,
            "articles": gold_articles,
            "history": gold_history,
        },
        "btc": {
            "analytics": btc_analytics,
            "smc": btc_smc,
            "articles": btc_articles,
            "history": btc_history,
        },
    }


def search_internet_for_dax(query: str, instrument: str = "DAX") -> Dict:
    clean_q = query.strip()
    if instrument == "BTC":
        encoded_en = urllib.parse.quote(f"{clean_q} (Bitcoin OR BTC OR crypto ETF OR Fed OR SEC OR liquidity)")
        encoded_de = urllib.parse.quote(f"{clean_q} (Bitcoin OR BTC OR Krypto OR ETF OR Zinsen)")
        search_feeds = [
            {"id": "live_btc_en", "name": f"Bitcoin Web Search EN: {clean_q}", "category": "btc_etf_institutional",
             "url": f"https://news.google.com/rss/search?q={encoded_en}&hl=en-US&gl=US&ceid=US:en"},
            {"id": "live_btc_de", "name": f"Bitcoin Web Search DE: {clean_q}", "category": "btc_fed_liquidity",
             "url": f"https://news.google.com/rss/search?q={encoded_de}&hl=de&gl=DE&ceid=DE:de"},
        ]
        raw_items: List[Dict] = []
        with ThreadPoolExecutor(max_workers=2) as pool:
            for fut in as_completed([pool.submit(_fetch_rss, f, 16, "BTC") for f in search_feeds]):
                raw_items.extend(fut.result())
        articles = _deduplicate_articles(raw_items)[:50]
        return {
            "query": clean_q,
            "instrument": "BTC",
            "searched_at": datetime.now(tz=timezone.utc).isoformat(),
            "analytics": _compute_dashboard_analytics(articles, channels_cfg=BTC_CHANNEL_RULES, asset_name="Bitcoin (BTC-USD)"),
            "articles": articles,
        }

    if instrument == "GOLD":
        encoded_en = urllib.parse.quote(f"{clean_q} (gold price OR XAUUSD OR bullion OR Fed OR yields OR DXY)")
        encoded_de = urllib.parse.quote(f"{clean_q} (Goldpreis OR Gold OR Edelmetall OR Fed OR Zinsen)")
        search_feeds = [
            {"id": "live_gold_en", "name": f"Gold Web Search EN: {clean_q}", "category": "gold_fed_yields",
             "url": f"https://news.google.com/rss/search?q={encoded_en}&hl=en-US&gl=US&ceid=US:en"},
            {"id": "live_gold_de", "name": f"Gold Web Search DE: {clean_q}", "category": "gold_inflation_macro",
             "url": f"https://news.google.com/rss/search?q={encoded_de}&hl=de&gl=DE&ceid=DE:de"},
        ]
        raw_items: List[Dict] = []
        with ThreadPoolExecutor(max_workers=2) as pool:
            for fut in as_completed([pool.submit(_fetch_rss, f, 16, "GOLD") for f in search_feeds]):
                raw_items.extend(fut.result())
        articles = _deduplicate_articles(raw_items)[:50]
        return {
            "query": clean_q,
            "instrument": "GOLD",
            "searched_at": datetime.now(tz=timezone.utc).isoformat(),
            "analytics": _compute_dashboard_analytics(articles, channels_cfg=GOLD_CHANNEL_RULES, asset_name="Gold (XAU)"),
            "articles": articles,
        }

    encoded_en = urllib.parse.quote(f"{clean_q} (DAX OR Germany OR ECB OR Eurozone OR markets OR economy)")
    encoded_de = urllib.parse.quote(f"{clean_q} (DAX OR Deutschland OR EZB OR Wirtschaft OR Börse)")
    encoded_exact = urllib.parse.quote(f"{clean_q} finance OR economy OR stocks")
    search_feeds = [
        {"id": "live_search_en", "name": f"Web Search EN: {clean_q}", "category": "dax_bluechips",
         "url": f"https://news.google.com/rss/search?q={encoded_en}&hl=en-US&gl=US&ceid=US:en"},
        {"id": "live_search_de", "name": f"Web Search DE: {clean_q}", "category": "dax_bluechips",
         "url": f"https://news.google.com/rss/search?q={encoded_de}&hl=de&gl=DE&ceid=DE:de"},
        {"id": "live_search_broad", "name": f"Web Search: {clean_q}", "category": "global_us",
         "url": f"https://news.google.com/rss/search?q={encoded_exact}&hl=en-US&gl=US&ceid=US:en"},
    ]
    raw_items = []
    with ThreadPoolExecutor(max_workers=3) as pool:
        for fut in as_completed([pool.submit(_fetch_rss, f, 16, "DAX") for f in search_feeds]):
            raw_items.extend(fut.result())

    raw = _deduplicate_articles(raw_items)
    relevant = [a for a in raw if is_relevant_to_dax(a["title"], a.get("summary", ""))]
    articles = (relevant if len(relevant) >= 3 else raw)[:50]
    return {
        "query": clean_q,
        "instrument": "DAX",
        "searched_at": datetime.now(tz=timezone.utc).isoformat(),
        "analytics": _compute_dashboard_analytics(articles, channels_cfg=CHANNEL_RULES, asset_name="DAX 40"),
        "articles": articles,
    }


def fetch_article_deep_read(url: str, fallback_title: str = "", fallback_summary: str = "") -> Dict:
    paragraphs: List[str] = []
    final_url = url
    fetched_ok = False
    if url and url.startswith("http"):
        try:
            status, final_url, raw = _http_get(url, HEADERS, timeout=10)
            if status == 200:
                parser = _ParagraphExtractor()
                parser.feed(raw.decode("utf-8", errors="ignore"))
                paragraphs = parser.paragraphs
                if paragraphs:
                    fetched_ok = True
        except Exception:
            pass
    excerpt_text = " ".join(paragraphs[:8]) if paragraphs else fallback_summary
    return {
        "url": final_url, "fetched_ok": fetched_ok, "paragraphs": paragraphs[:8],
        "deep_analysis": analyze_dax_news(fallback_title, excerpt_text),
    }


def run_ai_fundamental_thesis(title: str, text: str, api_url: str, api_key: str, model: str) -> Dict:
    endpoint = api_url.strip().rstrip("/")
    if not endpoint.endswith("/chat/completions"):
        endpoint = f"{endpoint}/chat/completions" if endpoint.endswith("/v1") else f"{endpoint}/v1/chat/completions"
    headers = {"Content-Type": "application/json"}
    if api_key.strip():
        headers["Authorization"] = f"Bearer {api_key.strip()}"
    prompt = (
        "You are an institutional German equities & DAX 40 SMC/macro analyst. "
        "Given the headline and text below (in English or German), provide a concise 4-bullet fundamental brief in English:\n"
        "1. HTF Sentiment & Conviction (Bullish / Bearish / Neutral)\n"
        "2. Direct vs Indirect Transmission to DAX 40\n"
        "3. Affected DAX Sectors / Constituents\n"
        "4. Key Liquidity/News Risk to Watch\n\n"
        f"Headline: {title}\n\nText: {text[:2400]}"
    )
    payload = json.dumps({
        "model": model.strip() or "gpt-4o-mini",
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.2,
        "max_tokens": 350,
    }).encode("utf-8")
    try:
        req = urllib.request.Request(endpoint, data=payload, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=25) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return {"ok": True, "thesis": data["choices"][0]["message"]["content"]}
    except Exception as e:
        return {"ok": False, "error": str(e)}

# ==============================================================================
# 4. EMBEDDED PWA & DESKTOP WEB UI
# ==============================================================================

ICON_SVG = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128">
  <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#0284c7"/><stop offset="100%" stop-color="#10b981"/></linearGradient></defs>
  <rect width="128" height="128" rx="26" fill="#080d16"/>
  <rect x="10" y="10" width="108" height="108" rx="20" fill="url(#g)" opacity="0.18" stroke="url(#g)" stroke-width="4"/>
  <text x="64" y="58" text-anchor="middle" font-family="Arial,sans-serif" font-weight="800" font-size="32" fill="#e2e8f0">DAX</text>
  <text x="64" y="88" text-anchor="middle" font-family="Arial,sans-serif" font-weight="700" font-size="18" fill="#10b981">v6.0</text>
</svg>"""

MANIFEST_JSON = json.dumps({
    "name": "DAX 40 Fundamental Sentinel v6.0 High-Win-Rate",
    "short_name": "DAX SMC",
    "description": "Live Bilingual EN/DE DAX 40 SMC Liquidity, FVG, SMT & Macro Workstation",
    "start_url": "/",
    "display": "standalone",
    "background_color": "#080d16",
    "theme_color": "#0f1726",
    "icons": [{"src": "/icon.svg", "sizes": "any", "type": "image/svg+xml"}],
})

INDEX_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="theme-color" content="#0f1726" />
  <title>DAX 40 Fundamental Sentinel v6.0 — High-Win-Rate SMC Signals &amp; Backtest</title>
  <link rel="manifest" href="manifest.json" />
  <link rel="icon" href="icon.svg" type="image/svg+xml" />
  <link rel="stylesheet" href="static/styles.css" />
</head>
<body>
  <div class="app-shell">
    <!-- Top Header -->
    <header class="topbar">
      <div class="brand">
        <div class="brand-badge" id="brandBadge">DAX · GOLD · BTC</div>
        <div>
          <h1>Multi-Asset Sentinel <span class="ver-tag">v6.0 WIN-RATE</span></h1>
          <p class="subtitle">DAX 40, Gold (GC=F) &amp; Bitcoin (BTC-USD) — 1H+15m SMC Nesting, ADR/News Gates, Real-Time Bot &amp; Ledger</p>
        </div>
      </div>

      <form id="liveSearchForm" class="search-bar">
        <input
          id="liveSearchInput"
          type="text"
          placeholder="Search live web (EN + DE) for any DAX catalyst (e.g. EZB, Ifo, SAP, tariffs)..."
          autocomplete="off"
        />
        <button type="submit" id="searchBtn" class="btn btn-primary">Search Web</button>
        <button type="button" id="clearSearchBtn" class="btn btn-ghost hidden">Back to Live Feed</button>
      </form>

      <div class="header-actions">
        <div class="status-pill" id="scanStatus">
          <span class="pulse-dot"></span>
          <span id="lastUpdatedText">Scanning internet...</span>
        </div>

        <button id="alertsToggleBtn" class="btn btn-xs btn-ghost" title="Enable desktop alerts for High-Impact news &amp; sentiment flips">
          Alerts: OFF
        </button>

        <button id="exportMdBtn" class="btn btn-xs btn-ghost" title="Download Markdown Executive Briefing">Export .MD</button>
        <button id="exportCsvBtn" class="btn btn-xs btn-ghost" title="Download News &amp; Sentiment CSV">CSV</button>
        <button id="aiSettingsBtn" class="btn btn-xs btn-ghost" title="Configure optional AI Deep-Dive (OpenAI / Ollama)">AI Config</button>

        <label class="auto-toggle" title="Automatically scan live feeds every 3 minutes">
          <input type="checkbox" id="autoRefreshToggle" checked />
          <span>Auto 3m</span>
        </label>
        <button id="refreshBtn" class="btn btn-secondary">
          <span id="refreshIcon">&#x21bb;</span> Scan Now
        </button>
        <button id="quitDesktopBtn" class="btn btn-ghost btn-xs" title="Stop local desktop server">Quit</button>
      </div>
    </header>

    <!-- Dual-Instrument Switcher Bar (DAX 40 | GOLD GC=F) -->
    <section class="inst-switcher" id="instrumentSwitcher">
      <button type="button" class="inst-tab active" data-inst="DAX">
        <div class="inst-tab-top">
          <strong>DAX 40 (GER40)</strong>
          <span class="badge badge-outline mono" id="instDaxPrice">--</span>
        </div>
        <div class="inst-tab-sub">
          <span id="instDaxSent">Sentiment: --</span>
          <span id="instDaxSig">Signal: --</span>
        </div>
      </button>
      <button type="button" class="inst-tab" data-inst="GOLD">
        <div class="inst-tab-top">
          <strong>GOLD (GC=F / XAU)</strong>
          <span class="badge badge-outline mono" id="instGoldPrice">--</span>
        </div>
        <div class="inst-tab-sub">
          <span id="instGoldSent">Sentiment: --</span>
          <span id="instGoldSig">Signal: --</span>
        </div>
      </button>
      <button type="button" class="inst-tab" data-inst="BTC">
        <div class="inst-tab-top">
          <strong>BITCOIN (BTC-USD)</strong>
          <span class="badge badge-outline mono" id="instBtcPrice">--</span>
        </div>
        <div class="inst-tab-sub">
          <span id="instBtcSent">Sentiment: --</span>
          <span id="instBtcSig">Signal: --</span>
        </div>
      </button>
    </section>

    <!-- Live Frankfurt SMC Killzone Bar -->
    <section id="killzoneBar" class="killzone-bar">
      <div class="kz-left">
        <span class="badge badge-outline mono" id="kzClock">--:-- CET</span>
        <span class="badge" id="kzTag">KILLZONE</span>
        <strong id="kzPhase">Detecting Frankfurt session...</strong>
      </div>
      <div class="kz-right muted-xs" id="kzGuidance">Loading institutional session guidance...</div>
    </section>

    <!-- Search Banner -->
    <div id="searchBanner" class="search-banner hidden">
      <div>
        <span class="badge badge-accent">LIVE BILINGUAL WEB SEARCH</span>
        <span id="searchBannerText"></span>
      </div>
      <button id="bannerClearBtn" class="btn btn-xs btn-ghost">Return to Full DAX Monitor</button>
    </div>

    <!-- 10-Card Macro Cross-Asset Ticker Strip -->
    <section class="ticker-strip" id="macroTickerStrip">
      <div class="ticker-skeleton">Loading live DAX 40 &amp; 10 global macro cross-asset quotes...</div>
    </section>

    <!-- Top Analytics Bento Grid -->
    <section class="bento-grid">
      <!-- Card 1: Overall Sentiment Gauge -->
      <div class="card sentiment-card">
        <div class="card-header">
          <div>
            <h2 id="sentimentHeading">DAX Fundamental Sentiment</h2>
            <span class="muted-xs" id="langMixLbl">EN &amp; DE Sources</span>
          </div>
          <span class="badge" id="overallBadge">--</span>
        </div>
        <div class="gauge-wrap">
          <svg id="sentimentGauge" viewBox="0 0 240 135" class="gauge-svg" aria-label="DAX Sentiment Gauge">
            <defs>
              <linearGradient id="gaugeGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#ef4444" />
                <stop offset="50%" stop-color="#f59e0b" />
                <stop offset="100%" stop-color="#10b981" />
              </linearGradient>
            </defs>
            <path d="M 25 115 A 95 95 0 0 1 215 115" fill="none" stroke="#1e293b" stroke-width="16" stroke-linecap="round" />
            <path d="M 25 115 A 95 95 0 0 1 215 115" fill="none" stroke="url(#gaugeGrad)" stroke-width="16" stroke-linecap="round" opacity="0.85" />
            <line id="gaugeNeedle" x1="120" y1="115" x2="120" y2="34" stroke="#f8fafc" stroke-width="3" stroke-linecap="round" />
            <circle cx="120" cy="115" r="6" fill="#f8fafc" />
            <text x="20" y="132" class="gauge-tick">-100</text>
            <text x="115" y="16" class="gauge-tick">0</text>
            <text x="196" y="132" class="gauge-tick">+100</text>
          </svg>
          <div class="gauge-score-readout">
            <span id="overallScoreNum" class="score-big">0</span>
            <span class="score-sub">HTF Narrative &amp; Catalyst Score</span>
          </div>
        </div>

        <div class="distribution-bar-wrap">
          <div class="distribution-labels">
            <span class="text-bull" id="bullCountLbl">0 Bullish</span>
            <span class="text-neut" id="neutCountLbl">0 Neutral</span>
            <span class="text-bear" id="bearCountLbl">0 Bearish</span>
          </div>
          <div class="distribution-bar">
            <div id="barBull" class="bar-seg seg-bull" style="width:33%"></div>
            <div id="barNeut" class="bar-seg seg-neut" style="width:34%"></div>
            <div id="barBear" class="bar-seg seg-bear" style="width:33%"></div>
          </div>
        </div>

        <div class="split-grid">
          <div class="split-box">
            <span class="split-title" id="directSplitTitle">Direct DAX / DE</span>
            <strong id="directScoreVal" class="mono">0</strong>
            <small id="directCountVal">0 items</small>
          </div>
          <div class="split-box">
            <span class="split-title" id="indirectSplitTitle">Indirect Global / ECB</span>
            <strong id="indirectScoreVal" class="mono">0</strong>
            <small id="indirectCountVal">0 items</small>
          </div>
        </div>
      </div>

      <!-- Card 2: SMC 15m Candlestick Chart / 5D Price / Divergence / Sector Heatmap -->
      <div class="card chart-card">
        <div class="card-header">
          <div>
            <h2 id="chartTitleHeading">DAX 40 Structure &amp; Liquidity</h2>
            <div class="view-switch" id="chartViewTabs">
              <button class="vtab active" data-view="smc">15m SMC Candles</button>
              <button class="vtab" data-view="price">5D Line</button>
              <button class="vtab" data-view="divergence">Sentiment vs Price</button>
              <button class="vtab" data-view="heatmap">Sector Heatmap (20)</button>
            </div>
          </div>
          <div class="dax-price-head" id="daxPriceHead">
            <span class="mono price-big">--</span>
            <span class="mono change-pill">--</span>
          </div>
        </div>

        <!-- View 0: 15m SMC OHLC Chart with FVGs, OBs, PDH/PDL, BOS/CHoCH -->
        <div id="viewSmc">
          <div class="chart-wrap">
            <svg id="smcCandleChart" viewBox="0 0 600 205" preserveAspectRatio="none" class="price-svg" style="height:205px;"></svg>
            <div class="chart-axis-labels">
              <span>
                <span style="color:#10b981;">&#9632; Bull FVG</span> &nbsp;
                <span style="color:#ef4444;">&#9632; Bear FVG</span> &nbsp;
                <span style="color:#eab308;">-- Cash Open</span> &nbsp;
                <span style="color:#f59e0b;">-- PDH/PDL</span> &nbsp;
                <span style="color:#a855f7;">&#9632; OTE</span>
              </span>
              <span id="smcStructureLbl">15m Structure: --</span>
            </div>
          </div>
          <div class="constituents-strip" id="constituentsStripSmc"></div>
        </div>

        <!-- View A: 5D Price Line + Constituents -->
        <div id="viewPrice" class="hidden">
          <div class="chart-wrap">
            <svg id="daxPriceChart" viewBox="0 0 520 155" preserveAspectRatio="none" class="price-svg"></svg>
            <div class="chart-axis-labels">
              <span id="chartMinLbl">Low: --</span>
              <span id="chartRangeLbl">5D Hourly (^GDAXI)</span>
              <span id="chartMaxLbl">High: --</span>
            </div>
          </div>
          <div class="constituents-strip" id="constituentsStrip"></div>
        </div>

        <!-- View B: Sentiment vs Price Divergence -->
        <div id="viewDivergence" class="hidden">
          <div class="chart-wrap">
            <svg id="divergenceChart" viewBox="0 0 520 185" preserveAspectRatio="none" class="price-svg" style="height:185px;"></svg>
            <div class="chart-axis-labels">
              <span id="divLegendLeft"><span style="color:#38bdf8;">&#9644; DAX Price</span> &nbsp; <span style="color:#10b981;">&#9644; Fundamental Sentiment (-100..+100)</span></span>
              <span id="divPointsLbl">0 tracked scans</span>
            </div>
          </div>
          <div id="divergenceNote" class="transmission-box" style="margin-top:10px;">
            <strong>Divergence Tracker:</strong> Persistent history is recorded every scan in <code>dax_history.json</code>.
          </div>
        </div>

        <!-- View C: 20-Stock Sector Heatmap -->
        <div id="viewHeatmap" class="hidden">
          <div id="sectorHeatmapGrid" class="heatmap-grid"></div>
        </div>
      </div>

      <!-- Card 3: 6 Fundamental Transmission Channels & Briefing -->
      <div class="card drivers-card">
        <div class="card-header">
          <h2>Fundamental Transmission Channels</h2>
          <span class="muted-xs">Direct &amp; Indirect Drivers</span>
        </div>
        <div id="channelsList" class="channels-list"></div>
        <div class="briefing-box" id="briefingBox">
          <div class="briefing-title">Live Fundamental Briefing</div>
          <p id="briefingHeadline" class="briefing-headline">Analyzing latest catalysts...</p>
          <div class="briefing-cols">
            <div>
              <div class="mini-head text-bull">Top Bullish Catalysts</div>
              <ul id="topBullList" class="driver-ul"></ul>
            </div>
            <div>
              <div class="mini-head text-bear">Top Bearish Risks</div>
              <ul id="topBearList" class="driver-ul"></ul>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Trade Signals & Risk Sizer Row (v5.0) -->
    <section class="signals-section" id="signalsSection">
      <div class="signals-header">
        <div>
          <h2 id="signalsHeading">SMC + Fundamental Trade Signals (GER40)</h2>
          <span class="muted-xs">Confluence-scored Entry Zones, Structural Stop Loss &amp; Liquidity-Pool Take Profits &middot; <em>Decision-support only, not financial advice</em></span>
        </div>
        <div class="sizer-bar">
          <label class="sizer-field"><span id="sizerAcctLbl">Account (€)</span>
            <input id="acctBalanceInput" type="number" min="100" step="100" value="10000" />
          </label>
          <label class="sizer-field">Risk %
            <input id="riskPctInput" type="number" min="0.1" max="10" step="0.1" value="1.0" />
          </label>
          <label class="sizer-field"><span id="sizerPtLbl">€/pt per 1.0 lot</span>
            <input id="ptValInput" type="number" min="0.1" step="0.5" value="1.0" />
          </label>
          <div class="sizer-out" id="sizerOutput">Risk: €100 | Lots: --</div>
        </div>
      </div>

      <!-- v6.0 Win-Rate Gates Strip -->
      <div class="gates-strip" id="winrateGatesStrip">
        <div class="gate-pill muted-xs">Loading 1H HTF, ADR, News Blackout, Breadth &amp; Sweep gates...</div>
      </div>

      <div class="signals-grid" id="signalsGrid">
        <div class="card muted-xs">Calculating SMC + Fundamental trade setups...</div>
      </div>
    </section>

    <!-- v6.0 Walk-Forward Backtest & Live Signal Ledger -->
    <section class="perf-grid" id="performanceSection">
      <div class="card">
        <div class="card-header">
          <div>
            <h2>5-Day Walk-Forward 15m Backtest</h2>
            <span class="muted-xs" id="btSubLbl">Causal bar-by-bar ^GDAXI simulation with Move-SL-to-BE at TP1</span>
          </div>
          <span class="badge" id="btSummaryBadge">--</span>
        </div>
        <div class="perf-kpis" id="btKpis"></div>
        <div class="ledger-table-wrap">
          <table class="ledger-table">
            <thead>
              <tr><th>Time</th><th>Dir</th><th>Setup</th><th>Entry</th><th>SL</th><th>TP1/TP2</th><th>Result</th></tr>
            </thead>
            <tbody id="btTableBody"></tbody>
          </table>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <div>
            <h2>Live Signal Ledger &amp; Auto-Grader</h2>
            <span class="muted-xs">Persisted setups (<code>signal_history.json</code>) graded against subsequent 15m candles</span>
          </div>
          <span class="badge" id="ledgerSummaryBadge">--</span>
        </div>
        <div class="perf-kpis" id="ledgerKpis"></div>
        <div class="ledger-table-wrap">
          <table class="ledger-table">
            <thead>
              <tr><th>Logged</th><th>Dir</th><th>Conf</th><th>Entry</th><th>SL</th><th>TP1 / TP2</th><th>Status</th></tr>
            </thead>
            <tbody id="ledgerTableBody"></tbody>
          </table>
        </div>
      </div>
    </section>

    <!-- Real-Time SMC Execution Bot & Exness MT5 Bridge -->
    <section class="bot-section" id="botSection">
      <div class="bot-header">
        <div>
          <div class="badge-cluster" style="margin-bottom:4px;">
            <h2 style="margin:0;font-size:14px;text-transform:uppercase;letter-spacing:0.04em;">Real-Time SMC Execution Bot (Exness MT5 + Paper)</h2>
            <span class="badge" id="botStatusBadge">PAUSED</span>
            <span class="badge badge-outline" id="mt5ConnBadge">MT5 OFFLINE</span>
          </div>
          <span class="muted-xs">Auto-executes DAX (<code>DE30m</code>), Gold (<code>XAUUSDm</code>) &amp; Bitcoin (<code>BTCUSDm</code>) with TP1 50% Partial + Auto-BE, Spread Cap &amp; Daily DD Circuit Breaker.</span>
        </div>
        <div class="bot-actions">
          <button type="button" id="botToggleBtn" class="btn btn-primary">Start Bot</button>
          <button type="button" id="botRunNowBtn" class="btn btn-secondary">Evaluate Now</button>
          <button type="button" id="botKillBtn" class="btn btn-xs btn-kill">KILL SWITCH</button>
          <a class="btn btn-xs btn-ghost" href="api/bot/download/ea" download="Exness_SMC_Bridge.mq5">Download MT5 EA (.mq5)</a>
          <a class="btn btn-xs btn-ghost" href="api/bot/download/worker" download="exness_mt5_worker.py">Download Python MT5 Worker</a>
        </div>
      </div>

      <div class="bot-config-bar" id="botConfigBar">
        <label class="sizer-field">Mode
          <select id="botModeSelect" class="select-ctrl">
            <option value="PAPER">PAPER (Sim)</option>
            <option value="MT5_BRIDGE">EXNESS MT5 BRIDGE</option>
          </select>
        </label>
        <label class="sizer-field">Balance ($)
          <input id="botBalInput" type="number" min="100" step="100" value="10000" />
        </label>
        <label class="sizer-field">Risk %
          <input id="botRiskInput" type="number" min="0.1" max="5" step="0.05" value="0.75" />
        </label>
        <label class="sizer-field">Min Conf %
          <input id="botConfInput" type="number" min="45" max="95" step="1" value="65" />
        </label>
        <label class="sizer-field">Daily Max DD %
          <input id="botDdInput" type="number" min="0.5" max="10" step="0.5" value="2.5" />
        </label>
        <label class="sizer-field">DAX Sym
          <input id="botDaxSymInput" type="text" value="DE30m" style="width:76px;" />
        </label>
        <label class="sizer-field">Gold Sym
          <input id="botGoldSymInput" type="text" value="XAUUSDm" style="width:84px;" />
        </label>
        <label class="sizer-field">BTC Sym
          <input id="botBtcSymInput" type="text" value="BTCUSDm" style="width:84px;" />
        </label>
        <label class="auto-toggle"><input id="botTradeDaxChk" type="checkbox" checked /><span>DAX</span></label>
        <label class="auto-toggle"><input id="botTradeGoldChk" type="checkbox" checked /><span>GOLD</span></label>
        <label class="auto-toggle"><input id="botTradeBtcChk" type="checkbox" checked /><span>BTC</span></label>
        <button type="button" id="botSaveCfgBtn" class="btn btn-xs btn-secondary">Apply Rules</button>
      </div>

      <div class="bot-kpis" id="botKpis"></div>

      <div class="bot-tables-grid">
        <div class="card" style="background:var(--surface-2);">
          <div class="card-header">
            <h2>Active Positions &amp; Pending Limit Orders</h2>
            <span class="muted-xs">Auto-managed every 20s</span>
          </div>
          <div class="ledger-table-wrap">
            <table class="ledger-table">
              <thead>
                <tr><th>Inst</th><th>Type</th><th>Entry</th><th>SL</th><th>TP1 / TP2</th><th>Lots</th><th>Live PnL</th><th>State</th><th></th></tr>
              </thead>
              <tbody id="botActiveBody"></tbody>
            </table>
          </div>
        </div>

        <div class="card" style="background:var(--surface-2);">
          <div class="card-header">
            <h2>Bot Audit Log &amp; Closed Trades</h2>
            <span class="muted-xs" id="botClosedStat">0 closed</span>
          </div>
          <ul id="botDecisionLog" class="bot-log-ul"></ul>
          <div class="ledger-table-wrap" style="margin-top:8px;">
            <table class="ledger-table">
              <thead>
                <tr><th>Closed</th><th>Inst</th><th>Dir</th><th>Entry → Exit</th><th>Reason</th><th>PnL ($)</th></tr>
              </thead>
              <tbody id="botClosedBody"></tbody>
            </table>
          </div>
        </div>
      </div>
    </section>

    <!-- SMC Institutional Execution Matrix Row -->
    <section class="smc-grid" id="smcGrid">
      <!-- Panel A: Institutional Alignment & News Checklist -->
      <div class="card">
        <div class="card-header">
          <h2>SMC Execution Bias &amp; Trap Detector</h2>
          <span class="badge" id="smcVerdictBadge">--</span>
        </div>
        <p id="smcVerdictSummary" class="briefing-headline" style="margin-bottom:10px;">Calculating fundamental vs. price zone alignment...</p>
        <ul id="smcChecklist" class="smc-checklist"></ul>
      </div>

      <!-- Panel B: Dealing Range & Liquidity Pools (DOL) -->
      <div class="card">
        <div class="card-header">
          <h2>Dealing Range &amp; Draws on Liquidity (DOL)</h2>
          <span class="badge badge-outline" id="dealingZoneBadge">--</span>
        </div>
        <div class="range-meter-wrap">
          <div class="range-labels">
            <span class="text-bull">Discount (&lt;38%)</span>
            <span class="muted-xs">50% EQ</span>
            <span class="text-bear">Premium (&gt;62%)</span>
          </div>
          <div class="range-bar">
            <div class="range-eq-mark"></div>
            <div id="rangePointer" class="range-pointer" style="left:50%"></div>
          </div>
          <div class="range-bounds mono">
            <span id="drLowLbl">Low: --</span>
            <span id="drEqLbl">EQ: --</span>
            <span id="drHighLbl">High: --</span>
          </div>
        </div>
        <div class="liq-grid" id="liquidityGrid"></div>
        <div id="sweepsBox" class="sweeps-box"></div>
      </div>

      <!-- Panel C: SMT Divergence & Active 15m FVGs / Order Blocks -->
      <div class="card">
        <div class="card-header">
          <h2>SMT Divergence &amp; Active 15m Imbalances</h2>
          <span class="muted-xs" id="smtPeersLbl">DAX vs STOXX50E &amp; S&amp;P 500</span>
        </div>
        <div id="smtCards" class="smt-cards"></div>
        <div class="imbalance-cols">
          <div>
            <div class="mini-head" style="color:var(--accent);">Unmitigated 15m FVGs (CE)</div>
            <ul id="fvgList" class="driver-ul mono"></ul>
          </div>
          <div>
            <div class="mini-head" style="color:#c4b5fd;">Active 15m Order Blocks</div>
            <ul id="obList" class="driver-ul mono"></ul>
          </div>
        </div>
      </div>
    </section>

    <!-- v4.0 Advanced IPDA, Power of 3 (AMD), OTE, Breakers, IFVGs & Intermarket Triad -->
    <section class="smc-grid" id="advancedSmcGrid">
      <!-- Panel D: Power of 3 (AMD) & Intermarket Triad -->
      <div class="card">
        <div class="card-header">
          <h2>Power of 3 (AMD) &amp; True Opens</h2>
          <span class="badge" id="amdPhaseBadge">--</span>
        </div>
        <div class="liq-grid" id="opensGrid"></div>
        <div id="amdNoteBox" class="transmission-box" style="margin-top:8px;">
          <strong>AMD Delivery:</strong> Calculating manipulation vs. distribution relative to Xetra Open...
        </div>
        <div class="intermarket-box" id="intermarketBox" style="margin-top:8px;">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:3px;">
            <strong style="font-size:11px;text-transform:uppercase;color:#cbd5e1;">Intermarket Triad (EUR/USD · VIX · US10Y)</strong>
            <span class="badge" id="triadBadge">--</span>
          </div>
          <div class="muted-xs" id="triadDetail">Loading cross-asset regime...</div>
        </div>
      </div>

      <!-- Panel E: IPDA 20/40/60-Day Lookbacks & Daily FVGs -->
      <div class="card">
        <div class="card-header">
          <h2>IPDA Lookback Ranges (20 / 40 / 60D)</h2>
          <span class="muted-xs">HTF External Liquidity &amp; Daily FVGs</span>
        </div>
        <div id="ipdaGrid" class="ipda-grid"></div>
        <div style="margin-top:8px;">
          <div class="mini-head" style="color:#38bdf8;">Daily (1D) Unmitigated HTF FVGs</div>
          <ul id="dailyFvgList" class="driver-ul mono"></ul>
        </div>
      </div>

      <!-- Panel F: OTE (61.8-78.6%), SD Projections, Breakers & Inverse FVGs -->
      <div class="card">
        <div class="card-header">
          <h2>OTE, SD Targets, Breakers &amp; IFVGs</h2>
          <span class="badge badge-outline" id="oteStatusBadge">--</span>
        </div>
        <div class="liq-grid" id="oteSdGrid"></div>
        <div class="imbalance-cols" style="margin-top:8px;">
          <div>
            <div class="mini-head" style="color:#fde047;">Inverse FVGs (IFVG Flips)</div>
            <ul id="ifvgList" class="driver-ul mono"></ul>
          </div>
          <div>
            <div class="mini-head" style="color:#f472b6;">Breaker Blocks (Unicorn)</div>
            <ul id="breakerList" class="driver-ul mono"></ul>
          </div>
        </div>
      </div>
    </section>

    <!-- Upcoming Fundamental Catalyst Calendar -->
    <section class="calendar-section">
      <div class="calendar-head">
        <h2>Upcoming Fundamental Catalyst Calendar &amp; Killzone Overlay</h2>
        <span class="muted-xs">Click <strong>Scan Prep</strong> on any event to search live consensus &amp; previews</span>
      </div>
      <div id="catalystStrip" class="catalyst-strip"></div>
    </section>

    <!-- News Filter Controls -->
    <section class="controls-bar">
      <div class="tab-group" id="channelTabs">
        <button class="tab active" data-channel="all">All News</button>
        <button class="tab" data-channel="direct">Direct Impact</button>
        <button class="tab" data-channel="indirect">Indirect Impact</button>
        <button class="tab" data-channel="dax_bluechips">DAX Blue Chips</button>
        <button class="tab" data-channel="german_macro">German Macro</button>
        <button class="tab" data-channel="ecb_rates">ECB &amp; Rates</button>
        <button class="tab" data-channel="trade_tariffs">Trade &amp; Tariffs</button>
        <button class="tab" data-channel="energy_commodities">Energy</button>
        <button class="tab" data-channel="global_us">US &amp; Global</button>
      </div>

      <div class="filter-right">
        <input id="localFilterInput" type="text" class="local-filter" placeholder="Filter headlines..." />
        <select id="langFilter" class="select-ctrl">
          <option value="all">EN + DE Sources</option>
          <option value="EN">English (EN)</option>
          <option value="DE">German (DE)</option>
        </select>
        <select id="sentimentFilter" class="select-ctrl">
          <option value="all">All Sentiments</option>
          <option value="bullish">Bullish Only</option>
          <option value="bearish">Bearish Only</option>
          <option value="neutral">Neutral Only</option>
        </select>
        <select id="impactFilter" class="select-ctrl">
          <option value="all">All Impact Levels</option>
          <option value="High">High Impact Only</option>
          <option value="MediumPlus">Medium &amp; High</option>
        </select>
      </div>
    </section>

    <!-- News Feed Grid -->
    <section class="feed-meta-row">
      <span id="feedCountText" class="muted-xs">Loading fundamental news...</span>
    </section>
    <main id="newsFeed" class="news-grid"></main>
  </div>

  <!-- Deep Read & AI Fundamental Breakdown Modal -->
  <div id="deepModal" class="modal-backdrop hidden" role="dialog" aria-modal="true">
    <div class="modal-panel">
      <div class="modal-header">
        <div>
          <span id="modalImpactBadge" class="badge"></span>
          <span id="modalChannelBadge" class="badge badge-outline"></span>
        </div>
        <button id="closeModalBtn" class="btn btn-xs btn-ghost">&times; Close</button>
      </div>
      <h3 id="modalTitle" class="modal-title"></h3>
      <div id="modalMeta" class="modal-meta"></div>
      <div id="modalTransmission" class="transmission-box"></div>
      <div id="aiThesisBox" class="ai-box hidden"></div>
      <div id="modalBody" class="modal-body">
        <div class="loading-spinner">Fetching full article from the internet &amp; running deep DAX sentiment analysis...</div>
      </div>
      <div class="modal-footer" style="justify-content:space-between;">
        <button id="runAiThesisBtn" class="btn btn-secondary">Generate AI Fundamental Thesis</button>
        <a id="modalExternalLink" href="#" target="_blank" rel="noopener noreferrer" class="btn btn-primary">
          Open Original Source &nearr;
        </a>
      </div>
    </div>
  </div>

  <!-- AI Config Modal -->
  <div id="aiConfigModal" class="modal-backdrop hidden" role="dialog" aria-modal="true">
    <div class="modal-panel" style="max-width:500px;">
      <div class="modal-header">
        <h3 style="margin:0; font-size:16px;">Optional AI Deep-Dive Configuration</h3>
        <button id="closeAiConfigBtn" class="btn btn-xs btn-ghost">&times; Close</button>
      </div>
      <p class="muted-xs" style="margin:0;">
        Stored only in your browser's localStorage. Works with OpenAI, Groq, Together, or local Ollama (e.g. <code>http://localhost:11434/v1</code>).
      </p>
      <label class="cfg-label">API Base URL
        <input id="cfgApiUrl" type="text" class="cfg-input" placeholder="https://api.openai.com/v1" />
      </label>
      <label class="cfg-label">API Key (leave blank for local Ollama)
        <input id="cfgApiKey" type="password" class="cfg-input" placeholder="sk-..." />
      </label>
      <label class="cfg-label">Model Name
        <input id="cfgModel" type="text" class="cfg-input" placeholder="gpt-4o-mini or llama3.1" />
      </label>
      <div class="modal-footer">
        <button id="saveAiConfigBtn" class="btn btn-primary">Save Settings</button>
      </div>
    </div>
  </div>

  <script src="static/app.js"></script>
</body>
</html>
"""

STYLES_CSS = r""":root {
  --bg: #080d16;
  --surface: #0f1726;
  --surface-2: #152033;
  --border: #1e2d45;
  --border-bright: #2b4063;
  --text: #e2e8f0;
  --text-muted: #8b9bb4;
  --accent: #38bdf8;
  --accent-dim: rgba(56, 189, 248, 0.14);
  --bull: #10b981;
  --bull-bg: rgba(16, 185, 129, 0.14);
  --bear: #ef4444;
  --bear-bg: rgba(239, 68, 68, 0.14);
  --neut: #f59e0b;
  --neut-bg: rgba(245, 158, 11, 0.14);
  --mono: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
  --sans: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
}

* { box-sizing: border-box; }

body {
  margin: 0;
  background: var(--bg);
  color: var(--text);
  font-family: var(--sans);
  font-size: 14px;
  line-height: 1.45;
  -webkit-font-smoothing: antialiased;
}

.app-shell {
  max-width: 1560px;
  margin: 0 auto;
  padding: 16px 20px 48px;
}

.mono { font-family: var(--mono); font-variant-numeric: tabular-nums; }
.muted-xs { font-size: 12px; color: var(--text-muted); }
.hidden { display: none !important; }

.text-bull { color: var(--bull); }
.text-bear { color: var(--bear); }
.text-neut { color: var(--neut); }

/* Header */
.topbar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding-bottom: 14px;
  border-bottom: 1px solid var(--border);
}

.brand { display: flex; align-items: center; gap: 12px; }
.brand-badge {
  background: linear-gradient(135deg, #0284c7, #10b981);
  color: #fff;
  font-weight: 800;
  font-size: 13px;
  letter-spacing: 0.06em;
  padding: 8px 10px;
  border-radius: 8px;
}
.brand h1 { margin: 0; font-size: 18px; font-weight: 700; letter-spacing: -0.01em; }
.ver-tag {
  font-size: 11px;
  background: var(--accent-dim);
  color: var(--accent);
  padding: 2px 6px;
  border-radius: 5px;
  vertical-align: middle;
}
.subtitle { margin: 2px 0 0; font-size: 12px; color: var(--text-muted); }

.search-bar {
  display: flex;
  align-items: center;
  gap: 8px;
  flex: 1 1 340px;
  max-width: 520px;
}
.search-bar input {
  flex: 1;
  background: var(--surface);
  border: 1px solid var(--border-bright);
  color: var(--text);
  padding: 9px 12px;
  border-radius: 8px;
  font-size: 13px;
  outline: none;
}
.search-bar input:focus { border-color: var(--accent); box-shadow: 0 0 0 2px var(--accent-dim); }

.header-actions { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; }
.status-pill {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  background: var(--surface);
  border: 1px solid var(--border);
  padding: 6px 10px;
  border-radius: 999px;
  font-size: 12px;
  color: var(--text-muted);
}
.pulse-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--bull); box-shadow: 0 0 8px var(--bull); }
.auto-toggle { display: inline-flex; align-items: center; gap: 5px; font-size: 12px; color: var(--text-muted); cursor: pointer; }

.btn {
  border: 1px solid transparent;
  border-radius: 8px;
  padding: 8px 13px;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.15s ease;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.btn-primary { background: #0284c7; color: #fff; }
.btn-primary:hover { background: #0369a1; }
.btn-secondary { background: var(--surface-2); border-color: var(--border-bright); color: var(--text); }
.btn-secondary:hover { border-color: var(--accent); color: #fff; }
.btn-ghost { background: transparent; border-color: var(--border); color: var(--text-muted); }
.btn-ghost:hover { color: var(--text); border-color: var(--border-bright); }
.btn-active-alert { background: var(--bull-bg); border-color: rgba(16, 185, 129, 0.5); color: var(--bull); }
.btn-xs { padding: 5px 9px; font-size: 12px; }

.spinning { display: inline-block; animation: spin 0.9s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

/* Search Banner */
.search-banner {
  margin-top: 12px;
  padding: 10px 14px;
  border-radius: 8px;
  background: var(--accent-dim);
  border: 1px solid rgba(56, 189, 248, 0.35);
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

/* 10-Card Ticker Strip */
.ticker-strip {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(144px, 1fr));
  gap: 8px;
  margin-top: 14px;
}
.ticker-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 9px 11px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 6px;
}
.ticker-left .ticker-name { font-weight: 700; font-size: 12.5px; }
.ticker-left .ticker-role { font-size: 10.5px; color: var(--text-muted); }
.ticker-right { text-align: right; }
.ticker-price { font-family: var(--mono); font-weight: 700; font-size: 13px; }
.ticker-chg { font-family: var(--mono); font-size: 11.5px; font-weight: 600; }

/* Bento Grid */
.bento-grid {
  display: grid;
  grid-template-columns: 315px 1fr 410px;
  gap: 14px;
  margin-top: 14px;
}
@media (max-width: 1240px) {
  .bento-grid { grid-template-columns: 1fr 1fr; }
  .drivers-card { grid-column: 1 / -1; }
}
@media (max-width: 820px) {
  .bento-grid { grid-template-columns: 1fr; }
}

.card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 14px 16px;
}
.card-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 10px;
}
.card-header h2 {
  margin: 0;
  font-size: 13.5px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  color: #cbd5e1;
}

/* View Switch inside Chart Card */
.view-switch { display: flex; gap: 5px; margin-top: 6px; flex-wrap: wrap; }
.vtab {
  background: var(--surface-2);
  border: 1px solid var(--border);
  color: var(--text-muted);
  padding: 3px 8px;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 600;
  cursor: pointer;
}
.vtab.active { background: var(--accent-dim); border-color: rgba(56, 189, 248, 0.45); color: var(--accent); }

/* Badges */
.badge {
  display: inline-flex;
  align-items: center;
  padding: 3px 8px;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.02em;
}
.badge-bull { background: var(--bull-bg); color: var(--bull); border: 1px solid rgba(16, 185, 129, 0.35); }
.badge-bear { background: var(--bear-bg); color: var(--bear); border: 1px solid rgba(239, 68, 68, 0.35); }
.badge-neut { background: var(--neut-bg); color: var(--neut); border: 1px solid rgba(245, 158, 11, 0.35); }
.badge-accent { background: var(--accent-dim); color: var(--accent); border: 1px solid rgba(56, 189, 248, 0.35); }
.badge-direct { background: rgba(139, 92, 246, 0.16); color: #c4b5fd; border: 1px solid rgba(139, 92, 246, 0.35); }
.badge-indirect { background: rgba(56, 189, 248, 0.12); color: #7dd3fc; border: 1px solid rgba(56, 189, 248, 0.3); }
.badge-de { background: rgba(250, 204, 21, 0.14); color: #fde047; border: 1px solid rgba(250, 204, 21, 0.35); }
.badge-outline { background: transparent; color: var(--text-muted); border: 1px solid var(--border-bright); }

/* Gauge */
.gauge-wrap { position: relative; display: flex; flex-direction: column; align-items: center; }
.gauge-svg { width: 215px; height: 118px; }
.gauge-tick { fill: var(--text-muted); font-size: 10px; font-family: var(--mono); }
.gauge-score-readout { text-align: center; margin-top: -6px; }
.score-big { font-family: var(--mono); font-size: 28px; font-weight: 800; display: block; }
.score-sub { font-size: 11px; color: var(--text-muted); }

.distribution-bar-wrap { margin-top: 10px; }
.distribution-labels { display: flex; justify-content: space-between; font-size: 11px; font-weight: 600; margin-bottom: 5px; }
.distribution-bar { display: flex; height: 8px; border-radius: 999px; overflow: hidden; background: var(--surface-2); }
.bar-seg { transition: width 0.4s ease; }
.seg-bull { background: var(--bull); }
.seg-neut { background: var(--neut); }
.seg-bear { background: var(--bear); }

.split-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 10px; }
.split-box {
  background: var(--surface-2);
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 8px 10px;
  display: flex;
  flex-direction: column;
}
.split-title { font-size: 11px; color: var(--text-muted); }
.split-box strong { font-size: 17px; margin: 2px 0; }
.split-box small { font-size: 11px; color: var(--text-muted); }

/* Chart & Constituents */
.dax-price-head { text-align: right; }
.price-big { font-size: 20px; font-weight: 800; display: block; }
.change-pill { font-size: 12px; font-weight: 700; }

.chart-wrap {
  background: #0b1220;
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 8px 10px 6px;
}
.price-svg { width: 100%; height: 145px; display: block; }
.chart-axis-labels {
  display: flex;
  justify-content: space-between;
  font-family: var(--mono);
  font-size: 11px;
  color: var(--text-muted);
  margin-top: 4px;
}

.constituents-strip {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(105px, 1fr));
  gap: 6px;
  margin-top: 10px;
  max-height: 126px;
  overflow-y: auto;
}
.const-chip {
  background: var(--surface-2);
  border: 1px solid var(--border);
  border-radius: 7px;
  padding: 5px 7px;
  font-size: 11px;
}
.const-top { display: flex; justify-content: space-between; font-weight: 700; }
.const-bot { display: flex; justify-content: space-between; color: var(--text-muted); margin-top: 2px; font-family: var(--mono); font-size: 10.5px; }

/* Sector Heatmap */
.heatmap-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(185px, 1fr));
  gap: 8px;
}
.heat-tile {
  background: var(--surface-2);
  border: 1px solid var(--border);
  border-radius: 9px;
  padding: 9px 10px;
}
.heat-head { display: flex; justify-content: space-between; align-items: center; font-size: 12px; font-weight: 700; margin-bottom: 4px; }
.heat-meta { font-size: 11px; color: var(--text-muted); margin-bottom: 6px; }
.heat-stocks { display: flex; flex-wrap: wrap; gap: 4px; }
.heat-stock-pill {
  font-family: var(--mono);
  font-size: 10.5px;
  padding: 2px 5px;
  border-radius: 4px;
  background: #0b1220;
  border: 1px solid var(--border);
}

/* Channels & Briefing */
.channels-list { display: flex; flex-direction: column; gap: 7px; }
.channel-row { display: grid; grid-template-columns: 1fr 84px 42px; align-items: center; gap: 8px; font-size: 12px; }
.channel-name-wrap { display: flex; align-items: center; gap: 6px; overflow: hidden; }
.channel-name { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-weight: 600; }
.channel-tag {
  font-size: 9px;
  text-transform: uppercase;
  padding: 1px 4px;
  border-radius: 4px;
  background: var(--surface-2);
  color: var(--text-muted);
  border: 1px solid var(--border);
}
.channel-bar-bg { height: 7px; background: var(--surface-2); border-radius: 999px; overflow: hidden; }
.channel-bar-fill { height: 100%; border-radius: 999px; transition: width 0.35s ease; }
.channel-score { text-align: right; font-family: var(--mono); font-weight: 700; font-size: 12px; }

.briefing-box { margin-top: 12px; padding-top: 10px; border-top: 1px solid var(--border); }
.briefing-title { font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; color: var(--accent); font-weight: 700; }
.briefing-headline { margin: 4px 0 8px; font-size: 12.5px; color: #cbd5e1; }
.briefing-cols { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
.mini-head { font-size: 11px; font-weight: 700; margin-bottom: 4px; }
.driver-ul { margin: 0; padding-left: 14px; font-size: 11.5px; color: var(--text-muted); }
.driver-ul li { margin-bottom: 3px; }

/* Upcoming Catalyst Calendar */
.calendar-section {
  margin-top: 14px;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 12px 16px;
}
.calendar-head { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; margin-bottom: 10px; }
.calendar-head h2 { margin: 0; font-size: 13.5px; text-transform: uppercase; letter-spacing: 0.04em; color: #cbd5e1; }
.catalyst-strip {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(265px, 1fr));
  gap: 8px;
}
.catalyst-card {
  background: var(--surface-2);
  border: 1px solid var(--border);
  border-radius: 9px;
  padding: 9px 11px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  gap: 6px;
}
.cat-top { display: flex; justify-content: space-between; align-items: center; gap: 6px; font-size: 11px; }
.cat-title { font-weight: 700; font-size: 12.5px; color: #f1f5f9; }
.cat-note { font-size: 11px; color: var(--text-muted); }
.cat-bot { display: flex; justify-content: space-between; align-items: center; margin-top: 2px; }

/* Filter Controls */
.controls-bar {
  margin-top: 14px;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 10px 12px;
}
.tab-group { display: flex; flex-wrap: wrap; gap: 5px; }
.tab {
  background: transparent;
  border: 1px solid transparent;
  color: var(--text-muted);
  padding: 6px 9px;
  border-radius: 7px;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
}
.tab:hover { color: var(--text); background: var(--surface-2); }
.tab.active { background: var(--accent-dim); color: var(--accent); border-color: rgba(56, 189, 248, 0.35); }

.filter-right { display: flex; flex-wrap: wrap; gap: 7px; }
.local-filter, .select-ctrl {
  background: var(--surface-2);
  border: 1px solid var(--border-bright);
  color: var(--text);
  padding: 6px 9px;
  border-radius: 7px;
  font-size: 12px;
  outline: none;
}

.feed-meta-row { margin: 12px 0 8px; }

/* News Feed Grid */
.news-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(430px, 1fr)); gap: 12px; }
@media (max-width: 520px) { .news-grid { grid-template-columns: 1fr; } }

.news-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 11px;
  padding: 14px 16px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  gap: 10px;
  transition: border-color 0.15s ease;
}
.news-card:hover { border-color: var(--border-bright); }
.news-top-badges { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 6px; }
.badge-cluster { display: flex; flex-wrap: wrap; gap: 5px; align-items: center; }

.news-title { margin: 0; font-size: 15px; font-weight: 700; line-height: 1.35; }
.news-title a { color: #f1f5f9; text-decoration: none; }
.news-title a:hover { color: var(--accent); text-decoration: underline; }
.news-summary { margin: 0; font-size: 12.5px; color: var(--text-muted); }

.transmission-box {
  background: #0b1322;
  border-left: 3px solid var(--accent);
  padding: 8px 10px;
  border-radius: 0 7px 7px 0;
  font-size: 12px;
  color: #cbd5e1;
}
.transmission-box strong { color: var(--accent); font-size: 11px; text-transform: uppercase; letter-spacing: 0.04em; }

.sector-tags { display: flex; flex-wrap: wrap; gap: 5px; }
.sector-pill {
  font-size: 11px;
  padding: 2px 7px;
  border-radius: 5px;
  background: var(--surface-2);
  color: var(--text-muted);
  border: 1px solid var(--border);
}

.news-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding-top: 8px;
  border-top: 1px solid var(--border);
  font-size: 12px;
  color: var(--text-muted);
}
.news-actions { display: flex; gap: 6px; }

/* Modals & AI Box */
.modal-backdrop {
  position: fixed;
  inset: 0;
  background: rgba(2, 6, 14, 0.78);
  backdrop-filter: blur(4px);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 18px;
  z-index: 100;
}
.modal-panel {
  width: 100%;
  max-width: 740px;
  max-height: 86vh;
  overflow-y: auto;
  background: var(--surface);
  border: 1px solid var(--border-bright);
  border-radius: 14px;
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.modal-header { display: flex; justify-content: space-between; align-items: center; }
.modal-title { margin: 0; font-size: 18px; line-height: 1.35; }
.modal-meta { font-size: 12px; color: var(--text-muted); }
.modal-body p { margin: 0 0 10px; color: #cbd5e1; font-size: 13.5px; line-height: 1.55; }
.modal-footer { display: flex; justify-content: flex-end; gap: 8px; padding-top: 8px; border-top: 1px solid var(--border); }
.loading-spinner { color: var(--accent); font-size: 13px; padding: 12px 0; }

.ai-box {
  background: rgba(16, 185, 129, 0.08);
  border: 1px solid rgba(16, 185, 129, 0.35);
  border-radius: 9px;
  padding: 12px;
  font-size: 13px;
  white-space: pre-wrap;
  color: #e2e8f0;
}
.cfg-label { display: flex; flex-direction: column; gap: 5px; font-size: 12px; color: var(--text-muted); }
.cfg-input {
  background: var(--surface-2);
  border: 1px solid var(--border-bright);
  color: var(--text);
  padding: 8px 10px;
  border-radius: 7px;
  font-size: 13px;
}

/* SMC Killzone Bar & Institutional Execution Grid */
.killzone-bar {
  margin-top: 12px;
  background: linear-gradient(90deg, rgba(15, 23, 38, 0.95), rgba(21, 32, 51, 0.95));
  border: 1px solid var(--border-bright);
  border-radius: 10px;
  padding: 9px 14px;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}
.kz-left { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; font-size: 13px; }

.smc-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 14px;
  margin-top: 14px;
}
@media (max-width: 1180px) { .smc-grid { grid-template-columns: 1fr; } }

.smc-checklist {
  margin: 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 12px;
  color: #cbd5e1;
}
.smc-checklist li {
  background: var(--surface-2);
  border: 1px solid var(--border);
  border-radius: 6px;
  padding: 5px 8px;
}

.range-meter-wrap { margin-bottom: 10px; }
.range-labels, .range-bounds { display: flex; justify-content: space-between; font-size: 11px; margin-bottom: 4px; }
.range-bounds { margin-top: 4px; color: var(--text-muted); }
.range-bar {
  position: relative;
  height: 10px;
  border-radius: 999px;
  background: linear-gradient(90deg, rgba(16,185,129,0.5) 0%, rgba(245,158,11,0.35) 50%, rgba(239,68,68,0.5) 100%);
  border: 1px solid var(--border-bright);
}
.range-eq-mark {
  position: absolute;
  left: 50%;
  top: -2px;
  bottom: -2px;
  width: 2px;
  background: #38bdf8;
}
.range-pointer {
  position: absolute;
  top: -4px;
  width: 10px;
  height: 16px;
  margin-left: -5px;
  border-radius: 3px;
  background: #f8fafc;
  box-shadow: 0 0 8px rgba(255,255,255,0.6);
}

.liq-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 6px;
}
.liq-box {
  background: var(--surface-2);
  border: 1px solid var(--border);
  border-radius: 7px;
  padding: 6px 8px;
  font-size: 11px;
}
.liq-box span { display: block; color: var(--text-muted); font-size: 10px; }
.liq-box strong { font-family: var(--mono); font-size: 12px; }

.sweeps-box {
  margin-top: 8px;
  font-size: 11.5px;
  color: #cbd5e1;
  background: #0b1322;
  border: 1px solid var(--border);
  border-radius: 7px;
  padding: 6px 9px;
}

.smt-cards { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 10px; }
.smt-card {
  background: var(--surface-2);
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 8px 10px;
  font-size: 11.5px;
}
.smt-head { display: flex; justify-content: space-between; align-items: center; font-weight: 700; margin-bottom: 4px; }
.imbalance-cols { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.cat-kz { font-size: 10.5px; color: #c4b5fd; background: rgba(139, 92, 246, 0.12); padding: 3px 6px; border-radius: 5px; border: 1px solid rgba(139, 92, 246, 0.25); }

.intermarket-box {
  background: var(--surface-2);
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 8px 10px;
}

.ipda-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 7px;
}
.ipda-card {
  background: var(--surface-2);
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 7px 9px;
  font-size: 11px;
}
.ipda-card .ipda-title { font-weight: 700; color: #cbd5e1; display: flex; justify-content: space-between; margin-bottom: 3px; }
.ipda-card .ipda-nums { font-family: var(--mono); font-size: 11px; color: var(--text-muted); }

/* Trade Signals & Risk Sizer (v5.0) */
.signals-section {
  margin-top: 14px;
  background: var(--surface);
  border: 1px solid var(--border-bright);
  border-radius: 12px;
  padding: 14px 16px;
}
.signals-header {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
}
.signals-header h2 { margin: 0; font-size: 14px; text-transform: uppercase; letter-spacing: 0.04em; color: #f8fafc; }
.sizer-bar { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; }
.sizer-field { display: flex; align-items: center; gap: 5px; font-size: 11.5px; color: var(--text-muted); }
.sizer-field input {
  width: 78px;
  background: var(--surface-2);
  border: 1px solid var(--border-bright);
  color: var(--text);
  padding: 4px 7px;
  border-radius: 6px;
  font-family: var(--mono);
  font-size: 12px;
}
.sizer-out {
  background: var(--accent-dim);
  border: 1px solid rgba(56, 189, 248, 0.35);
  color: var(--accent);
  padding: 5px 10px;
  border-radius: 7px;
  font-family: var(--mono);
  font-size: 12px;
  font-weight: 700;
}

.signals-grid {
  display: grid;
  grid-template-columns: 1.2fr 1fr;
  gap: 12px;
}
@media (max-width: 980px) { .signals-grid { grid-template-columns: 1fr; } }

.signal-card {
  background: var(--surface-2);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 12px 14px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.signal-card.signal-primary-short { border-color: rgba(239, 68, 68, 0.45); }
.signal-card.signal-primary-long { border-color: rgba(16, 185, 129, 0.45); }

.signal-top { display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 8px; }
.signal-levels {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 6px;
}
@media (max-width: 640px) { .signal-levels { grid-template-columns: repeat(2, 1fr); } }
.lvl-box {
  background: #0b1322;
  border: 1px solid var(--border);
  border-radius: 7px;
  padding: 6px 8px;
}
.lvl-box span { display: block; font-size: 10px; color: var(--text-muted); text-transform: uppercase; }
.lvl-box strong { font-family: var(--mono); font-size: 12.5px; display: block; margin-top: 2px; }
.lvl-box small { font-family: var(--mono); font-size: 10.5px; color: var(--text-muted); }

.signal-reasons { margin: 0; padding-left: 16px; font-size: 11.5px; color: #cbd5e1; }
.signal-reasons li { margin-bottom: 2px; }

/* v6.0 Win-Rate Gates Strip & Walk-Forward / Ledger Panels */
.gates-strip {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 8px;
  margin-bottom: 12px;
}
@media (max-width: 1100px) { .gates-strip { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 600px) { .gates-strip { grid-template-columns: 1fr; } }

.gate-pill {
  background: #0b1322;
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 7px 10px;
  font-size: 11px;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.gate-pill .gate-lbl { font-size: 10px; text-transform: uppercase; color: var(--text-muted); letter-spacing: 0.04em; }
.gate-pill .gate-val { font-weight: 700; font-size: 11.5px; }
.gate-pill.gate-bull { border-color: rgba(16, 185, 129, 0.4); }
.gate-pill.gate-bear { border-color: rgba(239, 68, 68, 0.4); }
.gate-pill.gate-neut { border-color: rgba(245, 158, 11, 0.35); }

.perf-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 14px;
  margin-top: 14px;
}
@media (max-width: 1024px) { .perf-grid { grid-template-columns: 1fr; } }

.perf-kpis {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 8px;
  margin-bottom: 10px;
}
.ledger-table-wrap { overflow-x: auto; }
.ledger-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 11.5px;
  font-family: var(--mono);
}
.ledger-table th {
  text-align: left;
  color: var(--text-muted);
  font-size: 10px;
  text-transform: uppercase;
  padding: 5px 6px;
  border-bottom: 1px solid var(--border);
}
.ledger-table td {
  padding: 5px 6px;
  border-bottom: 1px solid rgba(30, 45, 69, 0.5);
  color: #cbd5e1;
}

/* Dual-Instrument Switcher Bar (DAX 40 | GOLD GC=F) */
.inst-switcher {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
  margin-top: 12px;
}
@media (max-width: 720px) { .inst-switcher { grid-template-columns: 1fr; } }

.inst-tab {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 10px 14px;
  color: var(--text);
  cursor: pointer;
  text-align: left;
  transition: border-color 0.15s ease, background 0.15s ease;
}
.inst-tab:hover { border-color: var(--border-bright); }
.inst-tab.active {
  background: linear-gradient(135deg, rgba(56, 189, 248, 0.12), rgba(16, 185, 129, 0.08));
  border-color: var(--accent);
}
.inst-tab[data-inst="GOLD"].active {
  background: linear-gradient(135deg, rgba(245, 158, 11, 0.15), rgba(234, 179, 8, 0.06));
  border-color: #f59e0b;
}
.inst-tab-top {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 13.5px;
  margin-bottom: 4px;
}
.inst-tab-sub {
  display: flex;
  justify-content: space-between;
  gap: 10px;
  font-size: 11.5px;
  color: var(--text-muted);
  font-family: var(--mono);
}

/* Real-Time SMC Execution Bot Panel */
.bot-section {
  margin-top: 14px;
  background: var(--surface);
  border: 1px solid var(--border-bright);
  border-radius: 12px;
  padding: 14px 16px;
}
.bot-header {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  margin-bottom: 10px;
}
.bot-actions { display: flex; flex-wrap: wrap; align-items: center; gap: 7px; }
.btn-kill {
  background: rgba(239, 68, 68, 0.22);
  border: 1px solid rgba(239, 68, 68, 0.65);
  color: #fca5a5;
  font-weight: 700;
}
.btn-kill:hover { background: rgba(239, 68, 68, 0.4); color: #fff; }

.bot-config-bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 10px;
  background: #0b1322;
  border: 1px solid var(--border);
  border-radius: 9px;
  padding: 8px 10px;
  margin-bottom: 10px;
}
.bot-kpis {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 8px;
  margin-bottom: 10px;
}
@media (max-width: 900px) { .bot-kpis { grid-template-columns: repeat(2, 1fr); } }

.bot-tables-grid {
  display: grid;
  grid-template-columns: 1.1fr 1fr;
  gap: 12px;
}
@media (max-width: 1024px) { .bot-tables-grid { grid-template-columns: 1fr; } }

.bot-log-ul {
  list-style: none;
  margin: 0;
  padding: 0;
  max-height: 155px;
  overflow-y: auto;
  font-family: var(--mono);
  font-size: 11px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.bot-log-ul li {
  background: #0b1322;
  border: 1px solid var(--border);
  border-radius: 6px;
  padding: 4px 8px;
  color: #cbd5e1;
}



"""

APP_JS = r"""const state = {
  dashboard: null,
  activeInstrument: "DAX",
  activeArticles: [],
  activeAnalytics: null,
  isSearchMode: false,
  searchQuery: "",
  channelFilter: "all",
  langFilter: "all",
  sentimentFilter: "all",
  impactFilter: "all",
  localTextFilter: "",
  autoRefreshTimer: null,
  alertsEnabled: false,
  seenIds: new Set(),
  lastRegime: null,
  currentModalArticle: null,
  currentModalText: "",
};

const els = {
  instrumentSwitcher: document.getElementById("instrumentSwitcher"),
  instDaxPrice: document.getElementById("instDaxPrice"),
  instDaxSent: document.getElementById("instDaxSent"),
  instDaxSig: document.getElementById("instDaxSig"),
  instGoldPrice: document.getElementById("instGoldPrice"),
  instGoldSent: document.getElementById("instGoldSent"),
  instGoldSig: document.getElementById("instGoldSig"),
  instBtcPrice: document.getElementById("instBtcPrice"),
  instBtcSent: document.getElementById("instBtcSent"),
  instBtcSig: document.getElementById("instBtcSig"),
  sentimentHeading: document.getElementById("sentimentHeading"),
  chartTitleHeading: document.getElementById("chartTitleHeading"),
  chartRangeLbl: document.getElementById("chartRangeLbl"),
  directSplitTitle: document.getElementById("directSplitTitle"),
  indirectSplitTitle: document.getElementById("indirectSplitTitle"),
  signalsHeading: document.getElementById("signalsHeading"),
  sizerAcctLbl: document.getElementById("sizerAcctLbl"),
  sizerPtLbl: document.getElementById("sizerPtLbl"),
  btSubLbl: document.getElementById("btSubLbl"),
  smtPeersLbl: document.getElementById("smtPeersLbl"),
  kzClock: document.getElementById("kzClock"),
  kzTag: document.getElementById("kzTag"),
  kzPhase: document.getElementById("kzPhase"),
  kzGuidance: document.getElementById("kzGuidance"),
  macroTickerStrip: document.getElementById("macroTickerStrip"),
  overallBadge: document.getElementById("overallBadge"),
  overallScoreNum: document.getElementById("overallScoreNum"),
  langMixLbl: document.getElementById("langMixLbl"),
  gaugeNeedle: document.getElementById("gaugeNeedle"),
  bullCountLbl: document.getElementById("bullCountLbl"),
  neutCountLbl: document.getElementById("neutCountLbl"),
  bearCountLbl: document.getElementById("bearCountLbl"),
  barBull: document.getElementById("barBull"),
  barNeut: document.getElementById("barNeut"),
  barBear: document.getElementById("barBear"),
  directScoreVal: document.getElementById("directScoreVal"),
  directCountVal: document.getElementById("directCountVal"),
  indirectScoreVal: document.getElementById("indirectScoreVal"),
  indirectCountVal: document.getElementById("indirectCountVal"),
  daxPriceHead: document.getElementById("daxPriceHead"),
  smcCandleChart: document.getElementById("smcCandleChart"),
  smcStructureLbl: document.getElementById("smcStructureLbl"),
  constituentsStripSmc: document.getElementById("constituentsStripSmc"),
  daxPriceChart: document.getElementById("daxPriceChart"),
  divergenceChart: document.getElementById("divergenceChart"),
  divPointsLbl: document.getElementById("divPointsLbl"),
  divergenceNote: document.getElementById("divergenceNote"),
  sectorHeatmapGrid: document.getElementById("sectorHeatmapGrid"),
  chartViewTabs: document.getElementById("chartViewTabs"),
  viewSmc: document.getElementById("viewSmc"),
  viewPrice: document.getElementById("viewPrice"),
  viewDivergence: document.getElementById("viewDivergence"),
  viewHeatmap: document.getElementById("viewHeatmap"),
  chartMinLbl: document.getElementById("chartMinLbl"),
  chartMaxLbl: document.getElementById("chartMaxLbl"),
  constituentsStrip: document.getElementById("constituentsStrip"),
  channelsList: document.getElementById("channelsList"),
  briefingHeadline: document.getElementById("briefingHeadline"),
  topBullList: document.getElementById("topBullList"),
  topBearList: document.getElementById("topBearList"),
  smcVerdictBadge: document.getElementById("smcVerdictBadge"),
  smcVerdictSummary: document.getElementById("smcVerdictSummary"),
  smcChecklist: document.getElementById("smcChecklist"),
  dealingZoneBadge: document.getElementById("dealingZoneBadge"),
  rangePointer: document.getElementById("rangePointer"),
  drLowLbl: document.getElementById("drLowLbl"),
  drEqLbl: document.getElementById("drEqLbl"),
  drHighLbl: document.getElementById("drHighLbl"),
  liquidityGrid: document.getElementById("liquidityGrid"),
  sweepsBox: document.getElementById("sweepsBox"),
  smtCards: document.getElementById("smtCards"),
  fvgList: document.getElementById("fvgList"),
  obList: document.getElementById("obList"),
  amdPhaseBadge: document.getElementById("amdPhaseBadge"),
  opensGrid: document.getElementById("opensGrid"),
  amdNoteBox: document.getElementById("amdNoteBox"),
  triadBadge: document.getElementById("triadBadge"),
  triadDetail: document.getElementById("triadDetail"),
  ipdaGrid: document.getElementById("ipdaGrid"),
  dailyFvgList: document.getElementById("dailyFvgList"),
  oteStatusBadge: document.getElementById("oteStatusBadge"),
  oteSdGrid: document.getElementById("oteSdGrid"),
  ifvgList: document.getElementById("ifvgList"),
  breakerList: document.getElementById("breakerList"),
  signalsGrid: document.getElementById("signalsGrid"),
  winrateGatesStrip: document.getElementById("winrateGatesStrip"),
  btSummaryBadge: document.getElementById("btSummaryBadge"),
  btKpis: document.getElementById("btKpis"),
  btTableBody: document.getElementById("btTableBody"),
  ledgerSummaryBadge: document.getElementById("ledgerSummaryBadge"),
  ledgerKpis: document.getElementById("ledgerKpis"),
  ledgerTableBody: document.getElementById("ledgerTableBody"),
  botStatusBadge: document.getElementById("botStatusBadge"),
  mt5ConnBadge: document.getElementById("mt5ConnBadge"),
  botToggleBtn: document.getElementById("botToggleBtn"),
  botRunNowBtn: document.getElementById("botRunNowBtn"),
  botKillBtn: document.getElementById("botKillBtn"),
  botModeSelect: document.getElementById("botModeSelect"),
  botBalInput: document.getElementById("botBalInput"),
  botRiskInput: document.getElementById("botRiskInput"),
  botConfInput: document.getElementById("botConfInput"),
  botDdInput: document.getElementById("botDdInput"),
  botDaxSymInput: document.getElementById("botDaxSymInput"),
  botGoldSymInput: document.getElementById("botGoldSymInput"),
  botBtcSymInput: document.getElementById("botBtcSymInput"),
  botTradeDaxChk: document.getElementById("botTradeDaxChk"),
  botTradeGoldChk: document.getElementById("botTradeGoldChk"),
  botTradeBtcChk: document.getElementById("botTradeBtcChk"),
  botSaveCfgBtn: document.getElementById("botSaveCfgBtn"),
  botKpis: document.getElementById("botKpis"),
  botActiveBody: document.getElementById("botActiveBody"),
  botDecisionLog: document.getElementById("botDecisionLog"),
  botClosedBody: document.getElementById("botClosedBody"),
  botClosedStat: document.getElementById("botClosedStat"),
  acctBalanceInput: document.getElementById("acctBalanceInput"),
  riskPctInput: document.getElementById("riskPctInput"),
  ptValInput: document.getElementById("ptValInput"),
  sizerOutput: document.getElementById("sizerOutput"),
  catalystStrip: document.getElementById("catalystStrip"),
  newsFeed: document.getElementById("newsFeed"),
  feedCountText: document.getElementById("feedCountText"),
  lastUpdatedText: document.getElementById("lastUpdatedText"),
  refreshBtn: document.getElementById("refreshBtn"),
  refreshIcon: document.getElementById("refreshIcon"),
  autoRefreshToggle: document.getElementById("autoRefreshToggle"),
  alertsToggleBtn: document.getElementById("alertsToggleBtn"),
  exportMdBtn: document.getElementById("exportMdBtn"),
  exportCsvBtn: document.getElementById("exportCsvBtn"),
  aiSettingsBtn: document.getElementById("aiSettingsBtn"),
  liveSearchForm: document.getElementById("liveSearchForm"),
  liveSearchInput: document.getElementById("liveSearchInput"),
  clearSearchBtn: document.getElementById("clearSearchBtn"),
  searchBanner: document.getElementById("searchBanner"),
  searchBannerText: document.getElementById("searchBannerText"),
  bannerClearBtn: document.getElementById("bannerClearBtn"),
  channelTabs: document.getElementById("channelTabs"),
  localFilterInput: document.getElementById("localFilterInput"),
  langFilter: document.getElementById("langFilter"),
  sentimentFilter: document.getElementById("sentimentFilter"),
  impactFilter: document.getElementById("impactFilter"),
  deepModal: document.getElementById("deepModal"),
  closeModalBtn: document.getElementById("closeModalBtn"),
  modalTitle: document.getElementById("modalTitle"),
  modalMeta: document.getElementById("modalMeta"),
  modalImpactBadge: document.getElementById("modalImpactBadge"),
  modalChannelBadge: document.getElementById("modalChannelBadge"),
  modalTransmission: document.getElementById("modalTransmission"),
  aiThesisBox: document.getElementById("aiThesisBox"),
  modalBody: document.getElementById("modalBody"),
  runAiThesisBtn: document.getElementById("runAiThesisBtn"),
  modalExternalLink: document.getElementById("modalExternalLink"),
  aiConfigModal: document.getElementById("aiConfigModal"),
  closeAiConfigBtn: document.getElementById("closeAiConfigBtn"),
  saveAiConfigBtn: document.getElementById("saveAiConfigBtn"),
  cfgApiUrl: document.getElementById("cfgApiUrl"),
  cfgApiKey: document.getElementById("cfgApiKey"),
  cfgModel: document.getElementById("cfgModel"),
};

function esc(str) {
  return String(str || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function fmtSigned(n) {
  const num = Number(n || 0);
  return num > 0 ? `+${num}` : `${num}`;
}

function sentimentClass(score) {
  if (score >= 12) return "bull";
  if (score <= -12) return "bear";
  return "neut";
}

function timeAgo(ts) {
  const diffSec = Math.max(0, Math.floor(Date.now() / 1000 - ts));
  if (diffSec < 60) return "just now";
  const mins = Math.floor(diffSec / 60);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

function playAlertChime() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(740, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(980, ctx.currentTime + 0.14);
    gain.gain.setValueAtTime(0.08, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.28);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.3);
  } catch (e) {}
}

function checkAndFireAlerts(data) {
  const arts = data.articles || [];
  const overallLabel = data.analytics?.overall_label || "Neutral";

  if (state.seenIds.size === 0) {
    arts.forEach((a) => state.seenIds.add(a.id));
    state.lastRegime = overallLabel;
    return;
  }

  const highImpactNew = arts.filter(
    (a) => !state.seenIds.has(a.id) && a.impact_level === "High" && Math.abs(a.sentiment_score) >= 40
  );
  arts.forEach((a) => state.seenIds.add(a.id));

  const regimeFlipped = state.lastRegime && state.lastRegime !== overallLabel;
  state.lastRegime = overallLabel;

  if (!state.alertsEnabled) return;

  if (highImpactNew.length > 0) {
    const top = highImpactNew[0];
    playAlertChime();
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification(`DAX High-Impact (${fmtSigned(top.sentiment_score)} ${top.sentiment_label})`, {
        body: top.title,
      });
    }
  } else if (regimeFlipped) {
    playAlertChime();
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification(`DAX Sentiment Regime Shift -> ${overallLabel}`, {
        body: data.analytics?.briefing?.headline || "",
      });
    }
  }
}

function renderTickers(quotes) {
  if (!quotes || !quotes.length) {
    els.macroTickerStrip.innerHTML = `<div class="muted-xs">Market quotes temporarily unavailable.</div>`;
    return;
  }
  els.macroTickerStrip.innerHTML = quotes
    .map((q) => {
      const up = q.change_pct >= 0;
      const cls = up ? "text-bull" : "text-bear";
      const arrow = up ? "▲" : "▼";
      const priceTxt =
        q.unit === "$" || q.unit === "€"
          ? `${q.unit}${q.price.toLocaleString()}`
          : q.unit === "%"
          ? `${q.price}%`
          : q.price.toLocaleString();
      return `
        <div class="ticker-card">
          <div class="ticker-left">
            <div class="ticker-name">${esc(q.name)}</div>
            <div class="ticker-role">${esc(q.role)}</div>
          </div>
          <div class="ticker-right">
            <div class="ticker-price">${priceTxt}</div>
            <div class="ticker-chg ${cls}">${arrow} ${fmtSigned(q.change_pct.toFixed(2))}%</div>
          </div>
        </div>
      `;
    })
    .join("");
}

function renderConstituentChips(targetEl, constituents) {
  if (!targetEl || !constituents || !constituents.length) return;
  targetEl.innerHTML = constituents
    .map((c) => {
      const up = c.change_pct >= 0;
      const cls = up ? "text-bull" : "text-bear";
      return `
        <div class="const-chip">
          <div class="const-top">
            <span>${esc(c.symbol.replace(".DE", ""))}</span>
            <span class="${cls} mono">${fmtSigned(c.change_pct.toFixed(2))}%</span>
          </div>
          <div class="const-bot">
            <span>€${c.price.toFixed(2)}</span>
            <span>${esc(c.sector.split(" ")[0])}</span>
          </div>
        </div>
      `;
    })
    .join("");
}

function renderSmcCandleChart(smc) {
  if (!smc || !smc.available || !smc.candles_15m || !smc.candles_15m.length) {
    els.smcCandleChart.innerHTML = `<text x="300" y="102" text-anchor="middle" fill="#8b9bb4" font-size="13">Loading 15m SMC OHLC candles...</text>`;
    return;
  }

  const candles = smc.candles_15m;
  const liq = smc.liquidity || {};
  const dr = liq.dealing_range || {};
  const fvgs = smc.fvgs || [];
  const obs = smc.order_blocks || [];
  const events = smc.structure_events || [];

  const lows = candles.map((c) => c.l);
  const highs = candles.map((c) => c.h);
  let minP = Math.min(...lows);
  let maxP = Math.max(...highs);
  if (liq.pdh && liq.pdh < maxP * 1.03) maxP = Math.max(maxP, liq.pdh);
  if (liq.pdl && liq.pdl > minP * 0.97) minP = Math.min(minP, liq.pdl);
  const span = maxP - minP || 1;
  minP -= span * 0.05;
  maxP += span * 0.05;
  const fullSpan = maxP - minP;

  const W = 600;
  const H = 205;
  const padR = 54;
  const chartW = W - padR;
  const yOf = (p) => H - 10 - ((p - minP) / fullSpan) * (H - 20);
  const stepX = chartW / candles.length;
  const candleW = Math.max(2.2, Math.min(6, stepX * 0.65));

  const timeToX = (t) => {
    const idx = candles.findIndex((c) => c.t >= t);
    const i = idx === -1 ? candles.length - 1 : idx;
    return i * stepX + stepX / 2;
  };

  let svg = "";

  // 0. OTE Retracement Band (61.8% - 78.6%)
  const ote = smc.ote || {};
  if (ote.fib_618 != null && ote.fib_786 != null) {
    const oTop = Math.max(ote.fib_618, ote.fib_786);
    const oBot = Math.min(ote.fib_618, ote.fib_786);
    if (oBot >= minP && oTop <= maxP) {
      const y1 = yOf(oTop);
      const y2 = yOf(oBot);
      svg += `<rect x="0" y="${y1.toFixed(1)}" width="${chartW}" height="${Math.max(2, y2 - y1).toFixed(1)}" fill="rgba(168,85,247,0.12)" stroke="rgba(168,85,247,0.35)" stroke-width="0.6" stroke-dasharray="3 2" />`;
    }
  }

  // 1. Order Block & Breaker zones
  obs.forEach((ob) => {
    const x1 = Math.max(0, timeToX(ob.t));
    const y1 = yOf(ob.top);
    const y2 = yOf(ob.bottom);
    const hRect = Math.max(2, y2 - y1);
    svg += `<rect x="${x1.toFixed(1)}" y="${y1.toFixed(1)}" width="${(chartW - x1).toFixed(1)}" height="${hRect.toFixed(1)}" fill="rgba(139,92,246,0.18)" stroke="rgba(196,181,253,0.4)" stroke-width="0.7" />`;
  });
  (smc.breakers || []).forEach((br) => {
    const x1 = Math.max(0, timeToX(br.t));
    const y1 = yOf(br.top);
    const y2 = yOf(br.bottom);
    const hRect = Math.max(2, y2 - y1);
    svg += `<rect x="${x1.toFixed(1)}" y="${y1.toFixed(1)}" width="${(chartW - x1).toFixed(1)}" height="${hRect.toFixed(1)}" fill="rgba(244,114,182,0.18)" stroke="rgba(244,114,182,0.6)" stroke-width="0.8" stroke-dasharray="2 2" />`;
  });

  // 2. Unmitigated FVGs & IFVGs
  fvgs.forEach((f) => {
    const x1 = Math.max(0, timeToX(f.t));
    const y1 = yOf(f.top);
    const y2 = yOf(f.bottom);
    const hRect = Math.max(2, y2 - y1);
    const fill = f.type === "bullish" ? "rgba(16,185,129,0.22)" : "rgba(239,68,68,0.22)";
    const stroke = f.type === "bullish" ? "rgba(16,185,129,0.55)" : "rgba(239,68,68,0.55)";
    svg += `<rect x="${x1.toFixed(1)}" y="${y1.toFixed(1)}" width="${(chartW - x1).toFixed(1)}" height="${hRect.toFixed(1)}" fill="${fill}" stroke="${stroke}" stroke-width="0.7" />`;
  });
  (smc.ifvgs || []).forEach((iv) => {
    const x1 = Math.max(0, timeToX(iv.t));
    const y1 = yOf(iv.top);
    const y2 = yOf(iv.bottom);
    const hRect = Math.max(2, y2 - y1);
    svg += `<rect x="${x1.toFixed(1)}" y="${y1.toFixed(1)}" width="${(chartW - x1).toFixed(1)}" height="${hRect.toFixed(1)}" fill="rgba(250,204,21,0.16)" stroke="rgba(250,204,21,0.55)" stroke-width="0.8" />`;
  });

  // 3. Key Liquidity, Cash Open, Signal Levels & Equilibrium Lines
  const po3 = smc.power_of_3 || {};
  const priSig = (smc.signals && smc.signals.primary) || null;
  const hLines = [
    { label: "OPEN", val: po3.cash_open, col: "#eab308" },
    { label: "PDH", val: liq.pdh, col: "#f59e0b" },
    { label: "PDL", val: liq.pdl, col: "#f59e0b" },
    { label: "EQ 50%", val: dr.equilibrium, col: "#38bdf8" },
  ];
  if (priSig) {
    hLines.push({ label: "ENTRY", val: priSig.entry_price, col: "#38bdf8" });
    hLines.push({ label: "SL", val: priSig.stop_loss, col: "#ef4444" });
    hLines.push({ label: "TP1", val: priSig.tp1, col: "#10b981" });
    hLines.push({ label: "TP2", val: priSig.tp2, col: "#10b981" });
  }
  hLines.forEach((hl) => {
    if (hl.val == null || hl.val < minP || hl.val > maxP) return;
    const y = yOf(hl.val);
    svg += `<line x1="0" y1="${y.toFixed(1)}" x2="${chartW}" y2="${y.toFixed(1)}" stroke="${hl.col}" stroke-width="1" stroke-dasharray="4 3" opacity="0.85" />`;
    svg += `<text x="${chartW + 4}" y="${(y + 3).toFixed(1)}" fill="${hl.col}" font-size="9" font-family="monospace">${hl.label} ${Math.round(hl.val)}</text>`;
  });

  // 4. OHLC Candlesticks
  candles.forEach((c, i) => {
    const cx = i * stepX + stepX / 2;
    const isBull = c.c >= c.o;
    const col = isBull ? "#10b981" : "#ef4444";
    const yH = yOf(c.h);
    const yL = yOf(c.l);
    const yO = yOf(c.o);
    const yC = yOf(c.c);
    const bodyTop = Math.min(yO, yC);
    const bodyH = Math.max(1.5, Math.abs(yC - yO));
    svg += `<line x1="${cx.toFixed(1)}" y1="${yH.toFixed(1)}" x2="${cx.toFixed(1)}" y2="${yL.toFixed(1)}" stroke="${col}" stroke-width="1" />`;
    svg += `<rect x="${(cx - candleW / 2).toFixed(1)}" y="${bodyTop.toFixed(1)}" width="${candleW.toFixed(1)}" height="${bodyH.toFixed(1)}" fill="${col}" />`;
  });

  // 5. BOS / CHoCH Labels
  events.slice(-4).forEach((ev) => {
    const x = timeToX(ev.t);
    const y = yOf(ev.price);
    if (y < 10 || y > H - 10) return;
    const col = ev.dir === "bullish" ? "#34d399" : "#f87171";
    svg += `<text x="${Math.min(chartW - 35, x).toFixed(1)}" y="${(y - 4).toFixed(1)}" fill="${col}" font-size="9" font-weight="bold" font-family="monospace">${ev.type}</text>`;
  });

  els.smcCandleChart.innerHTML = svg;
  els.smcStructureLbl.textContent = `15m Structure: ${smc.structure_trend} | ${fvgs.length} Active FVGs | ${obs.length} OBs`;
}

function renderSmcSuite(smc) {
  if (!smc) return;

  // Killzone bar
  const kz = smc.killzone || {};
  els.kzClock.textContent = `${kz.frankfurt_time || "--:--"} ${kz.tz || "CET"}`;
  els.kzTag.textContent = kz.tag || "SESSION";
  els.kzTag.className = `badge ${kz.is_killzone ? "badge-bull" : "badge-neut"}`;
  els.kzPhase.textContent = kz.phase || "";
  els.kzGuidance.textContent = kz.guidance || "";

  renderSmcCandleChart(smc);
  if (!smc.available) return;

  // Panel A: Execution Verdict & Checklist
  const ex = smc.execution || {};
  els.smcVerdictBadge.textContent = ex.verdict || "--";
  els.smcVerdictBadge.className = `badge badge-${ex.tone || "neut"}`;
  els.smcVerdictSummary.textContent = ex.summary || "";
  els.smcChecklist.innerHTML = (ex.checklist || []).map((line) => `<li>${esc(line)}</li>`).join("");

  // Panel B: Dealing Range & Liquidity Pools
  const liq = smc.liquidity || {};
  const dr = liq.dealing_range || {};
  const zoneTone = dr.zone === "Premium" ? "bear" : dr.zone === "Discount" ? "bull" : "neut";
  els.dealingZoneBadge.textContent = `${dr.zone || "--"} (${dr.position_pct ?? 50}%)`;
  els.dealingZoneBadge.className = `badge badge-${zoneTone}`;
  els.rangePointer.style.left = `${Math.max(2, Math.min(98, dr.position_pct ?? 50))}%`;
  els.drLowLbl.textContent = `Low: ${dr.low ?? "--"}`;
  els.drEqLbl.textContent = `EQ: ${dr.equilibrium ?? "--"}`;
  els.drHighLbl.textContent = `High: ${dr.high ?? "--"}`;

  const liqItems = [
    { lbl: "PWH (Prev Week Hi)", val: liq.pwh },
    { lbl: "PDH (Prev Day Hi)", val: liq.pdh },
    { lbl: "Frankfurt ORH", val: liq.orh },
    { lbl: "PWL (Prev Week Lo)", val: liq.pwl },
    { lbl: "PDL (Prev Day Lo)", val: liq.pdl },
    { lbl: "Frankfurt ORL", val: liq.orl },
  ];
  els.liquidityGrid.innerHTML = liqItems
    .map((x) => `<div class="liq-box"><span>${x.lbl}</span><strong>${x.val != null ? x.val.toLocaleString() : "--"}</strong></div>`)
    .join("");

  const sweeps = liq.sweeps || [];
  els.sweepsBox.innerHTML = sweeps.length
    ? `<strong>Recent Sweeps (4h):</strong> ` + sweeps.map((s) => `${esc(s.level)} (${s.price}) — ${esc(s.side)}`).join(" | ")
    : `<strong>Recent Sweeps (4h):</strong> No external PDH/PDL or ORH/ORL sweep yet — price still engineering liquidity.`;

  // Panel C: SMT Divergence & FVGs / OBs
  const smt = smc.smt || {};
  const smtList = [smt.stoxx50, smt.sp500].filter(Boolean);
  els.smtCards.innerHTML = smtList
    .map((s) => {
      const cls = s.type === "bearish" ? "bear" : s.type === "bullish" ? "bull" : "neut";
      return `
        <div class="smt-card">
          <div class="smt-head">
            <span>vs ${esc(s.peer)}</span>
            <span class="badge badge-${cls}">${esc(s.status)}</span>
          </div>
          <div class="muted-xs">${esc(s.detail)}</div>
        </div>
      `;
    })
    .join("");

  const fvgs = (smc.fvgs || []).slice().reverse().slice(0, 5);
  els.fvgList.innerHTML = fvgs.length
    ? fvgs
        .map((f) => {
          const cls = f.type === "bullish" ? "text-bull" : "text-bear";
          return `<li class="${cls}">${f.type.toUpperCase()} ${f.bottom}–${f.top} (CE ${f.ce})</li>`;
        })
        .join("")
    : `<li>No unmitigated 15m FVGs detected.</li>`;

  const obs = (smc.order_blocks || []).slice().reverse().slice(0, 4);
  els.obList.innerHTML = obs.length
    ? obs
        .map((o) => {
          const cls = o.type === "bullish" ? "text-bull" : "text-bear";
          return `<li class="${cls}">${o.type.toUpperCase()} OB ${o.bottom}–${o.top}</li>`;
        })
        .join("")
    : `<li>No unmitigated 15m Order Blocks detected.</li>`;

  // Panel D: Power of 3 (AMD) & Intermarket Triad
  const po3 = smc.power_of_3 || {};
  const openLbl = po3.open_label || (state.activeInstrument === "GOLD" ? "COMEX/LDN Open" : state.activeInstrument === "BTC" ? "UTC Daily Open" : "Xetra Open");
  els.amdPhaseBadge.textContent = po3.amd_phase || "--";
  els.amdPhaseBadge.className = `badge badge-${po3.amd_tone || "neut"}`;
  els.opensGrid.innerHTML = [
    { lbl: `${openLbl} (${po3.above_cash_open ? "Above" : "Below"})`, val: po3.cash_open },
    { lbl: `Weekly Open (${po3.above_weekly_open ? "Above" : "Below"})`, val: po3.weekly_open },
    { lbl: "Monthly Open", val: po3.monthly_open },
  ]
    .map((x) => `<div class="liq-box"><span>${x.lbl}</span><strong>${x.val != null ? x.val.toLocaleString() : "--"}</strong></div>`)
    .join("");
  els.amdNoteBox.innerHTML = `<strong>AMD Delivery:</strong> ${esc(po3.amd_note || "")}`;

  const triad = smc.intermarket || {};
  els.triadBadge.textContent = triad.regime || "--";
  els.triadBadge.className = `badge badge-${triad.tone || "neut"}`;
  els.triadDetail.textContent = triad.detail || "";

  // Panel E: IPDA 20/40/60D Lookbacks & Daily FVGs
  const ipda = smc.ipda || {};
  const ipdaCards = [
    { title: "20-Day IPDA", data: ipda.d20 },
    { title: "40-Day IPDA", data: ipda.d40 },
    { title: "60-Day IPDA", data: ipda.d60 },
  ];
  els.ipdaGrid.innerHTML = ipdaCards
    .map((c) => {
      if (!c.data) return "";
      const zCls = c.data.zone === "Premium" ? "text-bear" : c.data.zone === "Discount" ? "text-bull" : "text-neut";
      return `
        <div class="ipda-card">
          <div class="ipda-title"><span>${c.title}</span><span class="${zCls} mono">${c.data.pct}%</span></div>
          <div class="ipda-nums">H: ${c.data.high.toLocaleString()}<br/>L: ${c.data.low.toLocaleString()}<br/>EQ: ${c.data.eq.toLocaleString()}</div>
        </div>
      `;
    })
    .join("");

  const dfvgs = (ipda.daily_fvgs || []).slice().reverse();
  els.dailyFvgList.innerHTML = dfvgs.length
    ? dfvgs
        .map((f) => `<li class="${f.type === "bullish" ? "text-bull" : "text-bear"}">1D ${f.type.toUpperCase()} ${f.bottom}–${f.top} (CE ${f.ce})</li>`)
        .join("")
    : `<li>No unmitigated Daily FVGs in last 45 days.</li>`;

  // Panel F: OTE, SD Targets, IFVGs & Breakers
  const ote = smc.ote || {};
  const sd = smc.sd_targets || {};
  els.oteStatusBadge.textContent = ote.in_ote
    ? `IN OTE${ote.fvg_confluence ? " + FVG" : ""}`
    : `${ote.direction || "OTE"}`;
  els.oteStatusBadge.className = `badge ${ote.in_ote ? "badge-bull" : "badge-outline"}`;

  els.oteSdGrid.innerHTML = [
    { lbl: "OTE 61.8%", val: ote.fib_618 },
    { lbl: "OTE 70.5% Sweet", val: ote.fib_705 },
    { lbl: "OTE 78.6%", val: ote.fib_786 },
    { lbl: "SD -1.5 Target", val: sd.sd_15 },
    { lbl: "SD -2.0 Target", val: sd.sd_20 },
    { lbl: "SD -2.5 Terminus", val: sd.sd_25 },
  ]
    .map((x) => `<div class="liq-box"><span>${x.lbl}</span><strong>${x.val != null ? x.val.toLocaleString() : "--"}</strong></div>`)
    .join("");

  const ifvgs = (smc.ifvgs || []).slice().reverse();
  els.ifvgList.innerHTML = ifvgs.length
    ? ifvgs
        .map((iv) => `<li class="${iv.type.includes("bull") ? "text-bull" : "text-bear"}">${iv.type.replace("_", " ").toUpperCase()} ${iv.bottom}–${iv.top}</li>`)
        .join("")
    : `<li>No recent IFVG flips on 15m.</li>`;

  const breakers = (smc.breakers || []).slice().reverse();
  els.breakerList.innerHTML = breakers.length
    ? breakers
        .map((b) => `<li class="${b.type.includes("bull") ? "text-bull" : "text-bear"}">${b.type.replace("_", " ").toUpperCase()} ${b.bottom}–${b.top}${b.unicorn ? " ★ UNICORN" : ""}</li>`)
        .join("")
    : `<li>No active 15m Breaker Blocks.</li>`;

  renderTradeSignals(smc.signals);
  renderPerformanceSection(smc.backtest, smc.ledger);
}

function renderWinrateGates(gates) {
  if (!gates) {
    els.winrateGatesStrip.innerHTML = "";
    return;
  }
  const htf = gates.htf_1h || {};
  const adr = gates.adr || {};
  const blk = gates.blackout || {};
  const brd = gates.breadth || {};
  const pa = gates.price_action || {};

  const htfTone = htf.trend_1h === "Bullish" ? "bull" : htf.trend_1h === "Bearish" ? "bear" : "neut";
  const htfNest = htf.bear_nested ? ` + ${htf.bear_nest_src}` : htf.bull_nested ? ` + ${htf.bull_nest_src}` : "";

  const paText = pa.bear_sweep_disp
    ? "BSL Sweep + Bear Disp"
    : pa.bull_sweep_disp
    ? "SSL Sweep + Bull Disp"
    : pa.trig_note || "Awaiting Sweep/Pin";
  const paTone = pa.bear_sweep_disp ? "bear" : pa.bull_sweep_disp ? "bull" : "neut";

  const pills = [
    {
      lbl: "1H HTF Structure",
      val: `${htf.trend_1h || "Neutral"}${htfNest}`,
      sub: `EQH: ${pa.eqh ?? "--"} | EQL: ${pa.eql ?? "--"}`,
      tone: htfTone,
    },
    {
      lbl: "14D ADR Exhaustion",
      val: adr.available ? `${adr.consumed_pct}% (${adr.today_range}/${adr.adr_14d} pts)` : "--",
      sub: adr.status || "",
      tone: adr.tone || "neut",
    },
    {
      lbl: "News Blackout Gate",
      val: blk.active ? "BLACKOUT ACTIVE" : blk.upcoming_soon ? "PRE-NEWS CAUTION" : "CLEAR",
      sub: blk.status || "",
      tone: blk.tone || "bull",
    },
    {
      lbl: state.activeInstrument === "GOLD" ? "Gold Peers (DXY / SI=F)" : state.activeInstrument === "BTC" ? "BTC Peers (DXY / ETH)" : "DAX 20 Breadth",
      val: state.activeInstrument === "GOLD"
        ? "USD + Silver SMT"
        : state.activeInstrument === "BTC"
          ? "ETH SMT + DXY"
          : brd.available ? `${brd.advancers}↑ / ${brd.decliners}↓ (${brd.bull_pct}%↑)` : "--",
      sub: state.activeInstrument === "GOLD"
        ? "Tracks DXY, US10Y & Silver SMT"
        : state.activeInstrument === "BTC"
          ? "Tracks ETH-USD SMT, DXY & S&P 500"
          : (brd.regime || ""),
      tone: (state.activeInstrument === "GOLD" || state.activeInstrument === "BTC") ? "neut" : (brd.tone || "neut"),
    },
    {
      lbl: "Sweep & Trigger Gate",
      val: paText,
      sub: (pa.sweep_notes || []).join(" · ") || "2-step Sweep → Disp required",
      tone: paTone,
    },
  ];

  els.winrateGatesStrip.innerHTML = pills
    .map(
      (p) => `
      <div class="gate-pill gate-${p.tone}">
        <span class="gate-lbl">${esc(p.lbl)}</span>
        <span class="gate-val text-${p.tone}">${esc(p.val)}</span>
        <span class="muted-xs" style="font-size:10px;">${esc(p.sub)}</span>
      </div>
    `
    )
    .join("");
}

function renderPerformanceSection(bt, ledger) {
  if (bt && bt.available) {
    const wrTone = bt.win_rate_pct >= 55 ? "bull" : bt.win_rate_pct >= 45 ? "neut" : "bear";
    els.btSummaryBadge.textContent = `${bt.win_rate_pct}% WIN RATE`;
    els.btSummaryBadge.className = `badge badge-${wrTone}`;
    els.btKpis.innerHTML = `
      <div class="liq-box"><span>Trades Graded</span><strong>${bt.trades_count} (${bt.wins}W/${bt.losses}L)</strong></div>
      <div class="liq-box"><span>Win Rate</span><strong class="text-${wrTone}">${bt.win_rate_pct}%</strong></div>
      <div class="liq-box"><span>Profit Factor</span><strong>${bt.profit_factor}</strong></div>
      <div class="liq-box"><span>Net Expectancy</span><strong class="${bt.net_r >= 0 ? "text-bull" : "text-bear"}">${fmtSigned(bt.net_r)}R</strong></div>
    `;
    els.btTableBody.innerHTML = (bt.recent_trades || []).length
      ? bt.recent_trades
          .map(
            (t) => `
          <tr>
            <td>${esc(t.time)}</td>
            <td class="${t.direction === "LONG" ? "text-bull" : "text-bear"}">${t.direction}</td>
            <td>${esc(t.setup)}</td>
            <td>${t.entry}</td>
            <td>${t.sl}</td>
            <td>${t.tp1} / ${t.tp2}</td>
            <td class="${t.r > 0 ? "text-bull" : "text-bear"}">${esc(t.outcome)} (${fmtSigned(t.r)}R)</td>
          </tr>`
          )
          .join("")
      : `<tr><td colspan="7" class="muted-xs">No closed 5-day setups met strict Killzone rejection criteria.</td></tr>`;
  }

  if (ledger) {
    const wr = ledger.win_rate_pct;
    els.ledgerSummaryBadge.textContent = wr != null ? `${wr}% LIVE WR` : `${ledger.total_logged} LOGGED`;
    els.ledgerSummaryBadge.className = `badge ${wr != null && wr >= 55 ? "badge-bull" : "badge-outline"}`;
    els.ledgerKpis.innerHTML = `
      <div class="liq-box"><span>Total Logged</span><strong>${ledger.total_logged}</strong></div>
      <div class="liq-box"><span>Graded Closed</span><strong>${ledger.graded_count}</strong></div>
      <div class="liq-box"><span>Live Win Rate</span><strong>${wr != null ? wr + "%" : "Pending"}</strong></div>
      <div class="liq-box"><span>Net Live R</span><strong class="${ledger.net_r >= 0 ? "text-bull" : "text-bear"}">${fmtSigned(ledger.net_r)}R</strong></div>
    `;
    els.ledgerTableBody.innerHTML = (ledger.entries || []).length
      ? ledger.entries
          .map(
            (e) => `
          <tr>
            <td>${esc(e.time)}</td>
            <td class="${e.direction === "LONG" ? "text-bull" : "text-bear"}">${e.direction}</td>
            <td>${e.confidence}%</td>
            <td>${e.entry}</td>
            <td>${e.sl}</td>
            <td>${e.tp1} / ${e.tp2}</td>
            <td class="${e.r > 0 ? "text-bull" : e.r < 0 ? "text-bear" : ""}">${esc(e.status)}${e.r ? " (" + fmtSigned(e.r) + "R)" : ""}</td>
          </tr>`
          )
          .join("")
      : `<tr><td colspan="7" class="muted-xs">Waiting for >=60% active-session signal to log automatically.</td></tr>`;
  }
}

function getActiveSlice() {
  const d = state.dashboard || {};
  if (state.activeInstrument === "BTC" && d.btc) {
    return {
      inst: "BTC",
      name: "BITCOIN (BTC-USD)",
      symbol: "BTC-USD",
      currency: "$",
      analytics: d.btc.analytics,
      smc: d.btc.smc,
      articles: d.btc.articles || [],
      history: d.btc.history || [],
    };
  }
  if (state.activeInstrument === "GOLD" && d.gold) {
    return {
      inst: "GOLD",
      name: "GOLD (GC=F / XAU)",
      symbol: "GC=F",
      currency: "$",
      analytics: d.gold.analytics,
      smc: d.gold.smc,
      articles: d.gold.articles || [],
      history: d.gold.history || [],
    };
  }
  return {
    inst: "DAX",
    name: "DAX 40 (GER40)",
    symbol: "^GDAXI",
    currency: "€",
    analytics: d.analytics,
    smc: d.smc,
    articles: d.articles || [],
    history: d.history || [],
  };
}

function renderInstrumentSwitcher(data) {
  if (!data) return;
  const quotes = data.macro_quotes || [];
  const daxQ = quotes.find((q) => q.symbol === "^GDAXI");
  const goldQ = quotes.find((q) => q.symbol === "GC=F");
  const btcQ = quotes.find((q) => q.symbol === "BTC-USD");

  if (daxQ) {
    els.instDaxPrice.textContent = `${daxQ.price.toLocaleString()} (${fmtSigned(daxQ.change_pct.toFixed(2))}%)`;
  }
  if (goldQ) {
    els.instGoldPrice.textContent = `$${goldQ.price.toLocaleString()} (${fmtSigned(goldQ.change_pct.toFixed(2))}%)`;
  }
  if (btcQ) {
    els.instBtcPrice.textContent = `$${btcQ.price.toLocaleString()} (${fmtSigned(btcQ.change_pct.toFixed(2))}%)`;
  }

  const daxAn = data.analytics || {};
  const daxPri = data.smc?.signals?.primary;
  els.instDaxSent.textContent = `Sentiment: ${fmtSigned(daxAn.overall_score || 0)} (${daxAn.overall_label || "--"})`;
  els.instDaxSig.textContent = daxPri ? `${daxPri.direction} ${daxPri.confidence}%` : "--";

  const gAn = data.gold?.analytics || {};
  const gPri = data.gold?.smc?.signals?.primary;
  els.instGoldSent.textContent = `Sentiment: ${fmtSigned(gAn.overall_score || 0)} (${gAn.overall_label || "--"})`;
  els.instGoldSig.textContent = gPri ? `${gPri.direction} ${gPri.confidence}%` : "--";

  const bAn = data.btc?.analytics || {};
  const bPri = data.btc?.smc?.signals?.primary;
  els.instBtcSent.textContent = `Sentiment: ${fmtSigned(bAn.overall_score || 0)} (${bAn.overall_label || "--"})`;
  els.instBtcSig.textContent = bPri ? `${bPri.direction} ${bPri.confidence}%` : "--";

  els.instrumentSwitcher.querySelectorAll(".inst-tab").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.inst === state.activeInstrument);
  });
}

function updatePositionSizer() {
  const slice = getActiveSlice();
  const sig = slice.smc?.signals?.primary;
  const cur = slice.currency;
  const bal = Math.max(0, parseFloat(els.acctBalanceInput.value) || 0);
  const pct = Math.max(0, parseFloat(els.riskPctInput.value) || 0);
  const ptVal = Math.max(0.01, parseFloat(els.ptValInput.value) || 1.0);
  const riskAmt = bal * (pct / 100);

  if (!sig || !sig.risk_pts) {
    els.sizerOutput.textContent = `Risk: ${cur}${riskAmt.toFixed(0)} | Lots: --`;
    return;
  }
  const lots = riskAmt / (sig.risk_pts * ptVal);
  els.sizerOutput.textContent = `Risk: ${cur}${riskAmt.toFixed(0)} | SL: ${sig.risk_pts} pts | Size: ${lots.toFixed(2)} lots`;
}

function renderTradeSignals(signals) {
  if (!signals || !signals.available) {
    renderWinrateGates(null);
    els.signalsGrid.innerHTML = `<div class="card muted-xs">Signal engine awaiting 15m OHLC candles.</div>`;
    return;
  }
  renderWinrateGates(signals.gates);

  const cards = [
    { label: "PRIMARY SETUP", data: signals.primary, isPrimary: true },
    { label: "ALTERNATIVE / COUNTER-SCENARIO", data: signals.alternative, isPrimary: false },
  ];

  els.signalsGrid.innerHTML = cards
    .map(({ label, data, isPrimary }) => {
      if (!data) return "";
      const isShort = data.direction === "SHORT";
      const dirBadge = isShort ? "badge-bear" : "badge-bull";
      const cardCls = isPrimary ? (isShort ? "signal-primary-short" : "signal-primary-long") : "";
      const reasonsHtml = (data.reasons || []).map((r) => `<li>${esc(r)}</li>`).join("");

      return `
        <div class="signal-card ${cardCls}">
          <div class="signal-top">
            <div class="badge-cluster">
              <span class="badge badge-outline">${label}</span>
              <span class="badge ${dirBadge}">${esc(data.direction)}</span>
              <span class="badge badge-${data.status_tone}">${esc(data.status)}</span>
            </div>
            <span class="mono" style="font-size:12px;font-weight:700;color:var(--accent);">Confluence: ${data.confidence}%</span>
          </div>

          <div class="muted-xs">POI Trigger: <strong style="color:#e2e8f0;">${esc(data.entry_source)}</strong> &middot; 15m ATR: <span class="mono">${signals.atr_15m} pts</span></div>

          <div class="signal-levels">
            <div class="lvl-box">
              <span>Entry Zone</span>
              <strong style="color:var(--accent);">${data.entry_price}</strong>
              <small>${data.entry_zone}</small>
            </div>
            <div class="lvl-box">
              <span>Stop Loss</span>
              <strong class="text-bear">${data.stop_loss}</strong>
              <small>-${data.risk_pts} pts</small>
            </div>
            <div class="lvl-box">
              <span>TP1 (BE)</span>
              <strong class="text-bull">${data.tp1}</strong>
              <small>${data.rr1}R</small>
            </div>
            <div class="lvl-box">
              <span>TP2 (DOL)</span>
              <strong class="text-bull">${data.tp2}</strong>
              <small>${data.rr2}R</small>
            </div>
            <div class="lvl-box">
              <span>TP3 (Runner)</span>
              <strong class="text-bull">${data.tp3}</strong>
              <small>${data.rr3}R</small>
            </div>
          </div>

          <ul class="signal-reasons">${reasonsHtml}</ul>
          <div class="muted-xs" style="border-top:1px solid var(--border);padding-top:6px;">
            <strong>Invalidation:</strong> ${esc(data.invalidation)}
          </div>
        </div>
      `;
    })
    .join("");

  updatePositionSizer();
}

function renderDaxChart(quotes, constituents) {
  const slice = getActiveSlice();
  const sym = slice.symbol;
  const target = (quotes || []).find((q) => q.symbol === sym);
  if (target) {
    const up = target.change_pct >= 0;
    const cls = up ? "text-bull" : "text-bear";
    const prefix = (slice.inst === "GOLD" || slice.inst === "BTC") ? "$" : "";
    els.daxPriceHead.innerHTML = `
      <span class="mono price-big">${prefix}${target.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
      <span class="mono change-pill ${cls}">${fmtSigned(target.change.toFixed(2))} (${fmtSigned(target.change_pct.toFixed(2))}%)</span>
    `;

    const series = target.series || [];
    if (series.length > 1) {
      const vals = series.map((p) => p.v);
      const minV = Math.min(...vals);
      const maxV = Math.max(...vals);
      const span = maxV - minV || 1;
      const w = 520;
      const h = 155;
      const pad = 10;

      const pts = series.map((p, i) => {
        const x = (i / (series.length - 1)) * w;
        const y = h - pad - ((p.v - minV) / span) * (h - pad * 2);
        return [x.toFixed(1), y.toFixed(1)];
      });

      const linePath = pts.map((pt, i) => `${i === 0 ? "M" : "L"}${pt[0]},${pt[1]}`).join(" ");
      const areaPath = `${linePath} L${w},${h} L0,${h} Z`;
      const strokeCol = up ? "#10b981" : "#ef4444";
      const fillCol = up ? "rgba(16,185,129,0.16)" : "rgba(239,68,68,0.16)";

      els.daxPriceChart.innerHTML = `
        <path d="${areaPath}" fill="${fillCol}" />
        <path d="${linePath}" fill="none" stroke="${strokeCol}" stroke-width="2.2" stroke-linejoin="round" />
      `;
      els.chartMinLbl.textContent = `Low: ${minV.toLocaleString()}`;
      els.chartMaxLbl.textContent = `High: ${maxV.toLocaleString()}`;
    }
  }

  const chipItems =
    slice.inst === "GOLD"
      ? (quotes || []).filter((q) => ["DX-Y.NYB", "SI=F", "^TNX", "^VIX", "EURUSD=X", "^GSPC"].includes(q.symbol))
      : slice.inst === "BTC"
        ? (quotes || []).filter((q) => ["ETH-USD", "DX-Y.NYB", "^GSPC", "^TNX", "^VIX", "GC=F"].includes(q.symbol))
        : constituents;
  renderConstituentChips(els.constituentsStrip, chipItems);
  renderConstituentChips(els.constituentsStripSmc, chipItems);
}

function renderDivergenceChart(history) {
  const pts = (history || []).filter((p) => p.dax_price != null);
  els.divPointsLbl.textContent = `${pts.length} tracked scan(s)`;

  if (pts.length < 2) {
    els.divergenceChart.innerHTML = `
      <text x="260" y="92" text-anchor="middle" fill="#8b9bb4" font-size="13">
        Collecting sentiment history... Click "Scan Now" or wait for next auto-scan to plot divergence trend.
      </text>
    `;
    return;
  }

  const w = 520;
  const h = 185;
  const pad = 16;

  const prices = pts.map((p) => p.dax_price);
  const pMin = Math.min(...prices);
  const pMax = Math.max(...prices);
  const pSpan = pMax - pMin || 1;

  const priceLine = pts
    .map((p, i) => {
      const x = (i / (pts.length - 1)) * w;
      const y = h - pad - ((p.dax_price - pMin) / pSpan) * (h - pad * 2);
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");

  const sentLine = pts
    .map((p, i) => {
      const x = (i / (pts.length - 1)) * w;
      const y = h - pad - ((p.overall_score + 100) / 200) * (h - pad * 2);
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");

  const zeroY = (h - pad - 0.5 * (h - pad * 2)).toFixed(1);

  els.divergenceChart.innerHTML = `
    <line x1="0" y1="${zeroY}" x2="${w}" y2="${zeroY}" stroke="#1e2d45" stroke-dasharray="4 4" />
    <path d="${priceLine}" fill="none" stroke="#38bdf8" stroke-width="2.2" />
    <path d="${sentLine}" fill="none" stroke="#10b981" stroke-width="2.2" />
  `;

  const latest = pts[pts.length - 1];
  const first = pts[0];
  const priceDelta = latest.dax_price - first.dax_price;
  const sentDelta = latest.overall_score - first.overall_score;
  let divMsg = `Tracked ${pts.length} snapshots. DAX Δ: ${fmtSigned(priceDelta.toFixed(1))} pts | Sentiment Δ: ${fmtSigned(sentDelta)}.`;
  if (priceDelta > 20 && sentDelta < -8) {
    divMsg += " Bearish Divergence: Price rising while fundamental news sentiment deteriorates.";
  } else if (priceDelta < -20 && sentDelta > 8) {
    divMsg += " Bullish Divergence: Fundamentals improving while price remains pressured.";
  }
  els.divergenceNote.innerHTML = `<strong>Divergence Tracker:</strong> ${esc(divMsg)}`;
}

function renderSectorHeatmap(heatmap) {
  if (!heatmap || !heatmap.length) {
    els.sectorHeatmapGrid.innerHTML = `<div class="muted-xs">No sector data available.</div>`;
    return;
  }
  els.sectorHeatmapGrid.innerHTML = heatmap
    .map((sec) => {
      const sCls = sentimentClass(sec.avg_sentiment);
      const pCls = sec.avg_change_pct >= 0 ? "text-bull" : "text-bear";
      const stockPills = (sec.stocks || [])
        .map((st) => {
          const stCls = st.change_pct >= 0 ? "text-bull" : "text-bear";
          return `<span class="heat-stock-pill">${esc(st.symbol.replace(".DE", ""))} <span class="${stCls}">${fmtSigned(st.change_pct.toFixed(1))}%</span></span>`;
        })
        .join("");

      return `
        <div class="heat-tile">
          <div class="heat-head">
            <span>${esc(sec.sector)}</span>
            <span class="${pCls} mono">${fmtSigned(sec.avg_change_pct.toFixed(2))}%</span>
          </div>
          <div class="heat-meta">
            News Sentiment: <strong class="text-${sCls} mono">${fmtSigned(sec.avg_sentiment)}</strong> (${sec.news_count} news)
          </div>
          <div class="heat-stocks">${stockPills}</div>
        </div>
      `;
    })
    .join("");
}

function renderCatalysts(catalysts) {
  if (!catalysts || !catalysts.length) {
    els.catalystStrip.innerHTML = `<div class="muted-xs">No upcoming scheduled events found.</div>`;
    return;
  }
  els.catalystStrip.innerHTML = catalysts
    .map((c) => {
      const daysTxt =
        c.days_away <= 0 ? "TODAY" : c.days_away === 1 ? "TOMORROW" : `In ${c.days_away} days`;
      const dirCls = c.impact_type === "direct" ? "badge-direct" : "badge-indirect";
      const impCls = c.importance === "High" ? "badge-bear" : "badge-neut";
      return `
        <div class="catalyst-card">
          <div class="cat-top">
            <span class="mono" style="color:var(--accent);font-weight:700;">${esc(c.date)} &middot; ${esc(c.time)}</span>
            <span class="badge ${impCls}">${esc(daysTxt)}</span>
          </div>
          <div class="cat-title">${esc(c.event)}</div>
          <div class="cat-note">${esc(c.note)}</div>
          ${c.killzone_note ? `<div class="cat-kz">${esc(c.killzone_note)}</div>` : ""}
          <div class="cat-bot">
            <span class="badge ${dirCls}">${c.impact_type.toUpperCase()}</span>
            <button class="btn btn-xs btn-secondary" data-cat-query="${esc(c.query)}">Scan Prep &rarr;</button>
          </div>
        </div>
      `;
    })
    .join("");
}

function renderAnalytics(analytics) {
  if (!analytics) return;
  const sc = analytics.overall_score || 0;
  const cls = sentimentClass(sc);

  els.overallBadge.textContent = analytics.overall_label;
  els.overallBadge.className = `badge badge-${cls}`;
  els.overallScoreNum.textContent = fmtSigned(sc);
  els.overallScoreNum.className = `score-big text-${cls}`;
  els.langMixLbl.textContent = `${analytics.en_count || 0} EN / ${analytics.de_count || 0} DE Sources`;

  const deg = Math.max(-90, Math.min(90, (sc / 100) * 90));
  els.gaugeNeedle.setAttribute("transform", `rotate(${deg} 120 115)`);

  const total = Math.max(1, analytics.total_articles || 1);
  els.bullCountLbl.textContent = `${analytics.bullish_count} Bullish`;
  els.neutCountLbl.textContent = `${analytics.neutral_count} Neutral`;
  els.bearCountLbl.textContent = `${analytics.bearish_count} Bearish`;

  els.barBull.style.width = `${((analytics.bullish_count / total) * 100).toFixed(1)}%`;
  els.barNeut.style.width = `${((analytics.neutral_count / total) * 100).toFixed(1)}%`;
  els.barBear.style.width = `${((analytics.bearish_count / total) * 100).toFixed(1)}%`;

  const dCls = sentimentClass(analytics.direct_score);
  const iCls = sentimentClass(analytics.indirect_score);
  els.directScoreVal.textContent = fmtSigned(analytics.direct_score);
  els.directScoreVal.className = `mono text-${dCls}`;
  els.directCountVal.textContent = `${analytics.direct_count} items`;

  els.indirectScoreVal.textContent = fmtSigned(analytics.indirect_score);
  els.indirectScoreVal.className = `mono text-${iCls}`;
  els.indirectCountVal.textContent = `${analytics.indirect_count} items`;

  els.channelsList.innerHTML = (analytics.channels || [])
    .map((ch) => {
      const cCls = sentimentClass(ch.avg_score);
      const widthPct = Math.max(6, Math.min(100, Math.abs(ch.avg_score)));
      const barCol = cCls === "bull" ? "var(--bull)" : cCls === "bear" ? "var(--bear)" : "var(--neut)";
      return `
        <div class="channel-row">
          <div class="channel-name-wrap">
            <span class="channel-tag">${ch.impact_type === "direct" ? "DIR" : "IND"}</span>
            <span class="channel-name" title="${esc(ch.label)}">${esc(ch.label)} (${ch.count})</span>
          </div>
          <div class="channel-bar-bg">
            <div class="channel-bar-fill" style="width:${widthPct}%; background:${barCol}"></div>
          </div>
          <div class="channel-score text-${cCls}">${fmtSigned(ch.avg_score)}</div>
        </div>
      `;
    })
    .join("");

  const br = analytics.briefing || {};
  els.briefingHeadline.textContent = br.headline || "";
  els.topBullList.innerHTML =
    (br.bullish_drivers || []).length > 0
      ? br.bullish_drivers.map((d) => `<li><strong>${fmtSigned(d.score)}</strong> [${d.lang || "EN"}] ${esc(d.title)}</li>`).join("")
      : `<li>No strong bullish catalysts detected.</li>`;

  els.topBearList.innerHTML =
    (br.bearish_drivers || []).length > 0
      ? br.bearish_drivers.map((d) => `<li><strong>${fmtSigned(d.score)}</strong> [${d.lang || "EN"}] ${esc(d.title)}</li>`).join("")
      : `<li>No strong bearish risks detected.</li>`;
}

function getFilteredArticles() {
  return (state.activeArticles || []).filter((art) => {
    if (state.channelFilter === "direct" && art.impact_type !== "direct") return false;
    if (state.channelFilter === "indirect" && art.impact_type !== "indirect") return false;
    if (!["all", "direct", "indirect"].includes(state.channelFilter) && art.channel_key !== state.channelFilter) return false;

    if (state.langFilter !== "all" && (art.lang || "EN") !== state.langFilter) return false;

    if (state.sentimentFilter === "bullish" && art.sentiment_score < 12) return false;
    if (state.sentimentFilter === "bearish" && art.sentiment_score > -12) return false;
    if (state.sentimentFilter === "neutral" && (art.sentiment_score >= 12 || art.sentiment_score <= -12)) return false;

    if (state.impactFilter === "High" && art.impact_level !== "High") return false;
    if (state.impactFilter === "MediumPlus" && art.impact_level === "Low") return false;

    if (state.localTextFilter) {
      const q = state.localTextFilter.toLowerCase();
      const hay = `${art.title} ${art.summary} ${art.source} ${art.sectors.join(" ")}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });
}

function renderNewsFeed() {
  const items = getFilteredArticles();
  const total = (state.activeArticles || []).length;
  els.feedCountText.textContent = `Showing ${items.length} of ${total} live analyzed items (Bilingual EN + DE)`;

  if (!items.length) {
    els.newsFeed.innerHTML = `
      <div class="card" style="grid-column: 1 / -1; text-align:center; padding: 32px;">
        <p class="muted-xs">No fundamental news matches your current filters.</p>
      </div>
    `;
    return;
  }

  els.newsFeed.innerHTML = items
    .map((art) => {
      const sCls = sentimentClass(art.sentiment_score);
      const dirCls = art.impact_type === "direct" ? "badge-direct" : "badge-indirect";
      const dirTxt = art.impact_type === "direct" ? "DIRECT DAX" : "INDIRECT";
      const impCls = art.impact_level === "High" ? "badge-accent" : "badge-outline";
      const langCls = art.lang === "DE" ? "badge-de" : "badge-outline";
      const sectorPills = (art.sectors || []).map((s) => `<span class="sector-pill">${esc(s)}</span>`).join("");

      return `
        <article class="news-card">
          <div>
            <div class="news-top-badges">
              <div class="badge-cluster">
                <span class="badge badge-${sCls}">${esc(art.sentiment_label)} (${fmtSigned(art.sentiment_score)})</span>
                <span class="badge ${dirCls}">${dirTxt}</span>
                <span class="badge ${impCls}">${esc(art.impact_level)}</span>
                <span class="badge ${langCls}">${esc(art.lang || "EN")}</span>
              </div>
              <span class="muted-xs">${esc(art.channel_label)}</span>
            </div>

            <h3 class="news-title" style="margin-top: 10px;">
              <a href="${esc(art.url)}" target="_blank" rel="noopener noreferrer">${esc(art.title)}</a>
            </h3>

            ${art.summary ? `<p class="news-summary" style="margin-top:6px;">${esc(art.summary)}</p>` : ""}
          </div>

          <div>
            <div class="transmission-box">
              <strong>DAX Impact:</strong> ${esc(art.transmission_note)}
            </div>

            <div class="sector-tags" style="margin-top:8px;">
              ${sectorPills}
            </div>

            <div class="news-footer" style="margin-top:10px;">
              <span><strong>${esc(art.source)}</strong> &middot; ${timeAgo(art.published_ts)}</span>
              <div class="news-actions">
                <button class="btn btn-xs btn-secondary" data-deep-id="${esc(art.id)}">Deep Analyze</button>
                <a class="btn btn-xs btn-ghost" href="${esc(art.url)}" target="_blank" rel="noopener noreferrer">Source &nearr;</a>
              </div>
            </div>
          </div>
        </article>
      `;
    })
    .join("");
}

function renderChannelTabsForAnalytics(analytics) {
  const chs = (analytics && analytics.channels) || [];
  const baseTabs = [
    { key: "all", label: "All News" },
    { key: "direct", label: "Direct Impact" },
    { key: "indirect", label: "Indirect Impact" },
    ...chs.map((c) => ({ key: c.key, label: c.label })),
  ];
  if (!baseTabs.some((t) => t.key === state.channelFilter)) {
    state.channelFilter = "all";
  }
  els.channelTabs.innerHTML = baseTabs
    .map(
      (t) =>
        `<button class="tab ${t.key === state.channelFilter ? "active" : ""}" data-channel="${esc(t.key)}">${esc(t.label)}</button>`
    )
    .join("");
}

function renderActiveInstrument() {
  const data = state.dashboard;
  if (!data) return;
  const slice = getActiveSlice();
  const isGold = slice.inst === "GOLD";
  const isBtc = slice.inst === "BTC";

  els.sentimentHeading.textContent = isGold
    ? "Gold (XAU) Fundamental Sentiment"
    : isBtc
      ? "Bitcoin (BTC-USD) Fundamental Sentiment"
      : "DAX Fundamental Sentiment";
  els.chartTitleHeading.textContent = isGold
    ? "Gold (GC=F) Structure & Liquidity"
    : isBtc
      ? "Bitcoin (BTC-USD) Structure & Liquidity"
      : "DAX 40 Structure & Liquidity";
  els.chartRangeLbl.textContent = isGold ? "5D Hourly (GC=F)" : isBtc ? "5D Hourly (BTC-USD)" : "5D Hourly (^GDAXI)";
  els.directSplitTitle.textContent = isGold ? "Direct Gold / Fed / DXY" : isBtc ? "Direct ETF / Macro / Reg" : "Direct DAX / DE";
  els.indirectSplitTitle.textContent = isGold ? "Indirect Geo / Macro" : isBtc ? "Indirect On-Chain / Crypto" : "Indirect Global / ECB";
  els.signalsHeading.textContent = isGold
    ? "SMC + Fundamental Trade Signals (GOLD / GC=F)"
    : isBtc
      ? "SMC + Fundamental Trade Signals (BTC-USD)"
      : "SMC + Fundamental Trade Signals (GER40)";
  els.sizerAcctLbl.textContent = (isGold || isBtc) ? "Account ($)" : "Account (€)";
  els.sizerPtLbl.textContent = (isGold || isBtc) ? "$/pt per lot" : "€/pt per 1.0 lot";
  els.btSubLbl.textContent = isGold
    ? "Causal bar-by-bar GC=F simulation with Move-SL-to-BE at TP1"
    : isBtc
      ? "Causal bar-by-bar BTC-USD simulation with Move-SL-to-BE at TP1"
      : "Causal bar-by-bar ^GDAXI simulation with Move-SL-to-BE at TP1";
  els.smtPeersLbl.textContent = isGold
    ? "Gold vs Silver (SI=F) & S&P 500"
    : isBtc
      ? "Bitcoin vs Ethereum (ETH-USD) & S&P 500"
      : "DAX vs STOXX50E & S&P 500";
  els.liveSearchInput.placeholder = isGold
    ? "Search live web (EN + DE) for Gold/Fed/DXY catalysts (e.g. Fed yields, PBOC, CPI)..."
    : isBtc
      ? "Search live web (EN + DE) for Bitcoin catalysts (e.g. BlackRock ETF, Fed, SEC, halving)..."
      : "Search live web (EN + DE) for any DAX catalyst (e.g. EZB, Ifo, SAP, tariffs)...";

  renderInstrumentSwitcher(data);

  if (!state.isSearchMode) {
    state.activeArticles = slice.articles;
    state.activeAnalytics = slice.analytics;
    renderChannelTabsForAnalytics(state.activeAnalytics);
    renderAnalytics(state.activeAnalytics);
    renderNewsFeed();
  }

  renderTickers(data.macro_quotes);
  renderDaxChart(data.macro_quotes, data.dax_constituents);
  renderDivergenceChart(slice.history);
  renderSectorHeatmap(data.sector_heatmap);
  renderCatalysts(data.catalysts);
  renderSmcSuite(slice.smc);
}

async function loadDashboard(force = false) {
  els.refreshBtn.disabled = true;
  els.refreshIcon.classList.add("spinning");
  els.lastUpdatedText.textContent = force ? "Scanning DAX + Gold EN/DE & OHLC..." : "Updating...";

  try {
    const resp = await fetch(`api/dashboard?force=${force ? "1" : "0"}`);
    const data = await resp.json();
    state.dashboard = data;

    checkAndFireAlerts(data);
    renderActiveInstrument();
    if (data.bot) renderBotPanel(data.bot);

    const dt = new Date(data.updated_at);
    els.lastUpdatedText.textContent = `Live scan: ${dt.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`;
  } catch (err) {
    els.lastUpdatedText.textContent = "Scan error — retry";
    console.error(err);
  } finally {
    els.refreshBtn.disabled = false;
    els.refreshIcon.classList.remove("spinning");
  }
}

async function runLiveSearch(query) {
  const q = query.trim();
  if (!q) return;
  els.liveSearchInput.value = q;
  els.lastUpdatedText.textContent = `Searching ${state.activeInstrument} web for "${q}"...`;
  try {
    const resp = await fetch(`api/search?q=${encodeURIComponent(q)}&instrument=${encodeURIComponent(state.activeInstrument)}`);
    const data = await resp.json();
    state.isSearchMode = true;
    state.searchQuery = q;
    state.activeArticles = data.articles || [];
    state.activeAnalytics = data.analytics;

    els.clearSearchBtn.classList.remove("hidden");
    els.searchBanner.classList.remove("hidden");
    els.searchBannerText.textContent = `Showing ${state.activeArticles.length} bilingual EN/DE results analyzed for ${state.activeInstrument} sentiment on "${q}"`;

    renderChannelTabsForAnalytics(state.activeAnalytics);
    renderAnalytics(state.activeAnalytics);
    renderNewsFeed();
    els.lastUpdatedText.textContent = `Web search ready`;
  } catch (err) {
    console.error(err);
    els.lastUpdatedText.textContent = "Search failed";
  }
}

function exitSearchMode() {
  state.isSearchMode = false;
  state.searchQuery = "";
  els.liveSearchInput.value = "";
  els.clearSearchBtn.classList.add("hidden");
  els.searchBanner.classList.add("hidden");
  if (state.dashboard) {
    const slice = getActiveSlice();
    state.activeArticles = slice.articles;
    state.activeAnalytics = slice.analytics;
    renderChannelTabsForAnalytics(state.activeAnalytics);
    renderAnalytics(state.activeAnalytics);
    renderNewsFeed();
    const dt = new Date(state.dashboard.updated_at);
    els.lastUpdatedText.textContent = `Live scan: ${dt.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`;
  }
}

async function openDeepModal(articleId) {
  const art = (state.activeArticles || []).find((a) => a.id === articleId);
  if (!art) return;
  state.currentModalArticle = art;
  state.currentModalText = art.summary || art.title;

  const sCls = sentimentClass(art.sentiment_score);
  els.modalImpactBadge.textContent = `${art.sentiment_label} (${fmtSigned(art.sentiment_score)})`;
  els.modalImpactBadge.className = `badge badge-${sCls}`;
  els.modalChannelBadge.textContent = `${art.lang || "EN"} • ${art.impact_type.toUpperCase()} • ${art.channel_label}`;
  els.modalTitle.textContent = art.title;
  els.modalMeta.textContent = `${art.source} • Published ${new Date(art.published_at).toLocaleString()} • ${art.impact_level} Impact`;
  els.modalTransmission.innerHTML = `<strong>DAX Transmission Analysis:</strong> ${esc(art.transmission_note)}`;
  els.modalExternalLink.href = art.url;
  els.aiThesisBox.classList.add("hidden");
  els.aiThesisBox.textContent = "";
  els.modalBody.innerHTML = `<div class="loading-spinner">Fetching article content from the internet &amp; running deep analysis...</div>`;
  els.deepModal.classList.remove("hidden");

  try {
    const params = new URLSearchParams({ url: art.url, title: art.title, summary: art.summary || "" });
    const resp = await fetch(`api/article?${params.toString()}`);
    const data = await resp.json();

    const deep = data.deep_analysis || {};
    const dCls = sentimentClass(deep.sentiment_score ?? art.sentiment_score);
    let html = `
      <div class="split-box" style="margin-bottom:10px;">
        <span class="split-title">Deep Full-Text Sentiment Assessment</span>
        <strong class="text-${dCls}">${esc(deep.sentiment_label || art.sentiment_label)} (${fmtSigned(deep.sentiment_score ?? art.sentiment_score)})</strong>
        <small>Detected signals: ${esc((deep.signals || []).join(", ") || "Contextual macro rules")}</small>
      </div>
    `;
    if (data.fetched_ok && data.paragraphs && data.paragraphs.length) {
      state.currentModalText = data.paragraphs.join("\n\n");
      html += data.paragraphs.map((p) => `<p>${esc(p)}</p>`).join("");
    } else {
      html += `<p class="muted-xs">${esc(art.summary || "Publisher restricts automated full-text extraction. Use 'Open Original Source' below.")}</p>`;
    }
    els.modalBody.innerHTML = html;
  } catch (err) {
    els.modalBody.innerHTML = `<p class="muted-xs">Could not load full article text. Click 'Open Original Source' below.</p>`;
  }
}

async function runAiThesis() {
  const art = state.currentModalArticle;
  if (!art) return;
  const apiUrl = localStorage.getItem("dax_ai_url") || "";
  const apiKey = localStorage.getItem("dax_ai_key") || "";
  const model = localStorage.getItem("dax_ai_model") || "gpt-4o-mini";

  if (!apiUrl) {
    els.aiConfigModal.classList.remove("hidden");
    return;
  }

  els.aiThesisBox.classList.remove("hidden");
  els.aiThesisBox.textContent = "Generating AI fundamental thesis...";
  try {
    const resp = await fetch("api/ai-analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: art.title,
        text: state.currentModalText,
        api_url: apiUrl,
        api_key: apiKey,
        model: model,
      }),
    });
    const res = await resp.json();
    if (res.ok) {
      els.aiThesisBox.textContent = `AI FUNDAMENTAL THESIS (${model}):\n\n${res.thesis}`;
    } else {
      els.aiThesisBox.textContent = `AI Analysis Error: ${res.error || "Unknown error"}`;
    }
  } catch (e) {
    els.aiThesisBox.textContent = `AI Request Failed: ${e}`;
  }
}

function downloadFile(filename, content, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function exportMarkdownBriefing() {
  const d = state.dashboard;
  if (!d) return;
  const slice = getActiveSlice();
  const an = state.activeAnalytics || slice.analytics;
  const q = (d.macro_quotes || []).find((x) => x.symbol === slice.symbol);
  const smc = slice.smc || {};
  const liq = smc.liquidity || {};
  const ex = smc.execution || {};
  const pri = smc.signals?.primary;
  const lines = [
    `# ${slice.name} Fundamental & SMC Sentinel Briefing`,
    `Generated: ${new Date().toISOString()}`,
    ``,
    `## SMC & Macro Execution Bias`,
    q ? `- **${slice.name} (${slice.symbol}):** ${q.price} (${fmtSigned(q.change_pct)}%)` : `- **${slice.name}:** N/A`,
    `- **SMC Verdict:** ${ex.verdict || "N/A"}`,
    `- **SMC Narrative:** ${ex.summary || ""}`,
    `- **Key DOL:** PWH ${liq.pwh ?? "--"} / PWL ${liq.pwl ?? "--"} | PDH ${liq.pdh ?? "--"} / PDL ${liq.pdl ?? "--"} | ORH ${liq.orh ?? "--"} / ORL ${liq.orl ?? "--"}`,
    `- **Aggregate Sentiment:** ${an.overall_label} (${fmtSigned(an.overall_score)})`,
    ...(pri
      ? [
          ``,
          `## Primary Trade Signal (${pri.direction} — ${pri.status})`,
          `- **Confluence:** ${pri.confidence}% (${pri.entry_source})`,
          `- **Entry Zone:** ${pri.entry_zone} (Mid: ${pri.entry_price})`,
          `- **Stop Loss (SL):** ${pri.stop_loss} (-${pri.risk_pts} pts)`,
          `- **Take Profits:** TP1 ${pri.tp1} (${pri.rr1}R) | TP2 ${pri.tp2} (${pri.rr2}R) | TP3 ${pri.tp3} (${pri.rr3}R)`,
          `- **Invalidation:** ${pri.invalidation}`,
        ]
      : []),
    ``,
    `## Executive Fundamental Summary`,
    `${an.briefing?.headline || ""}`,
    ``,
    `### Top Bullish Catalysts`,
    ...(an.briefing?.bullish_drivers || []).map((x) => `- [${fmtSigned(x.score)}] ${x.title} (${x.source})`),
    ``,
    `### Top Bearish Risks`,
    ...(an.briefing?.bearish_drivers || []).map((x) => `- [${fmtSigned(x.score)}] ${x.title} (${x.source})`),
    ``,
    `## Latest Analyzed Headlines`,
    ...(state.activeArticles || []).slice(0, 30).map(
      (a) => `- **${fmtSigned(a.sentiment_score)} (${a.sentiment_label})** [${a.impact_type.toUpperCase()} | ${a.lang}] ${a.title} — *${a.source}*\n  - ${a.transmission_note}`
    ),
  ];
  downloadFile(`${slice.inst}_SMC_Briefing_${new Date().toISOString().slice(0, 10)}.md`, lines.join("\n"), "text/markdown");
}

function exportCsv() {
  const items = getFilteredArticles();
  const header = ["Published", "Lang", "SentimentScore", "SentimentLabel", "ImpactType", "ImpactLevel", "Channel", "Sectors", "Source", "Title", "Transmission", "URL"];
  const csvEsc = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const rows = items.map((a) =>
    [a.published_at, a.lang, a.sentiment_score, a.sentiment_label, a.impact_type, a.impact_level, a.channel_label, (a.sectors || []).join("; "), a.source, a.title, a.transmission_note, a.url]
      .map(csvEsc)
      .join(",")
  );
  downloadFile(`${state.activeInstrument}_News_Sentiment_${new Date().toISOString().slice(0, 10)}.csv`, [header.join(","), ...rows].join("\n"), "text/csv");
}

function setupAutoRefresh() {
  if (state.autoRefreshTimer) {
    clearInterval(state.autoRefreshTimer);
    state.autoRefreshTimer = null;
  }
  if (els.autoRefreshToggle.checked) {
    state.autoRefreshTimer = setInterval(() => loadDashboard(true), 180000);
  }
}

// Event Listeners
els.instrumentSwitcher.addEventListener("click", (e) => {
  const btn = e.target.closest(".inst-tab");
  if (!btn) return;
  const nextInst = btn.dataset.inst;
  if (!nextInst || nextInst === state.activeInstrument) return;
  state.activeInstrument = nextInst;
  state.channelFilter = "all";
  if (state.isSearchMode) {
    exitSearchMode();
  }
  renderActiveInstrument();
});

els.refreshBtn.addEventListener("click", () => loadDashboard(true));
els.autoRefreshToggle.addEventListener("change", setupAutoRefresh);
els.exportMdBtn.addEventListener("click", exportMarkdownBriefing);
els.exportCsvBtn.addEventListener("click", exportCsv);
els.acctBalanceInput.addEventListener("input", updatePositionSizer);
els.riskPctInput.addEventListener("input", updatePositionSizer);
els.ptValInput.addEventListener("input", updatePositionSizer);

els.alertsToggleBtn.addEventListener("click", async () => {
  if (!state.alertsEnabled && "Notification" in window && Notification.permission !== "granted") {
    try { await Notification.requestPermission(); } catch (e) {}
  }
  state.alertsEnabled = !state.alertsEnabled;
  els.alertsToggleBtn.textContent = state.alertsEnabled ? "Alerts: ON" : "Alerts: OFF";
  els.alertsToggleBtn.classList.toggle("btn-active-alert", state.alertsEnabled);
  if (state.alertsEnabled) playAlertChime();
});

els.chartViewTabs.addEventListener("click", (e) => {
  const btn = e.target.closest(".vtab");
  if (!btn) return;
  els.chartViewTabs.querySelectorAll(".vtab").forEach((b) => b.classList.remove("active"));
  btn.classList.add("active");
  const v = btn.dataset.view;
  els.viewSmc.classList.toggle("hidden", v !== "smc");
  els.viewPrice.classList.toggle("hidden", v !== "price");
  els.viewDivergence.classList.toggle("hidden", v !== "divergence");
  els.viewHeatmap.classList.toggle("hidden", v !== "heatmap");
});

els.catalystStrip.addEventListener("click", (e) => {
  const btn = e.target.closest("[data-cat-query]");
  if (btn) runLiveSearch(btn.dataset.catQuery);
});

els.liveSearchForm.addEventListener("submit", (e) => {
  e.preventDefault();
  runLiveSearch(els.liveSearchInput.value);
});
els.clearSearchBtn.addEventListener("click", exitSearchMode);
els.bannerClearBtn.addEventListener("click", exitSearchMode);

els.channelTabs.addEventListener("click", (e) => {
  const btn = e.target.closest(".tab");
  if (!btn) return;
  els.channelTabs.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
  btn.classList.add("active");
  state.channelFilter = btn.dataset.channel;
  renderNewsFeed();
});

els.localFilterInput.addEventListener("input", (e) => { state.localTextFilter = e.target.value.trim(); renderNewsFeed(); });
els.langFilter.addEventListener("change", (e) => { state.langFilter = e.target.value; renderNewsFeed(); });
els.sentimentFilter.addEventListener("change", (e) => { state.sentimentFilter = e.target.value; renderNewsFeed(); });
els.impactFilter.addEventListener("change", (e) => { state.impactFilter = e.target.value; renderNewsFeed(); });

els.newsFeed.addEventListener("click", (e) => {
  const btn = e.target.closest("[data-deep-id]");
  if (btn) openDeepModal(btn.dataset.deepId);
});

els.closeModalBtn.addEventListener("click", () => els.deepModal.classList.add("hidden"));
els.deepModal.addEventListener("click", (e) => { if (e.target === els.deepModal) els.deepModal.classList.add("hidden"); });
els.runAiThesisBtn.addEventListener("click", runAiThesis);

els.aiSettingsBtn.addEventListener("click", () => {
  els.cfgApiUrl.value = localStorage.getItem("dax_ai_url") || "https://api.openai.com/v1";
  els.cfgApiKey.value = localStorage.getItem("dax_ai_key") || "";
  els.cfgModel.value = localStorage.getItem("dax_ai_model") || "gpt-4o-mini";
  els.aiConfigModal.classList.remove("hidden");
});
els.closeAiConfigBtn.addEventListener("click", () => els.aiConfigModal.classList.add("hidden"));
els.saveAiConfigBtn.addEventListener("click", () => {
  localStorage.setItem("dax_ai_url", els.cfgApiUrl.value.trim());
  localStorage.setItem("dax_ai_key", els.cfgApiKey.value.trim());
  localStorage.setItem("dax_ai_model", els.cfgModel.value.trim());
  els.aiConfigModal.classList.add("hidden");
});

loadDashboard(false);
setupAutoRefresh();

// --- Real-Time Execution Bot UI & Exness MT5 Bridge Controls ---
let _botConfigSyncedOnce = false;

function renderBotPanel(bot) {
  if (!bot) return;
  const cfg = bot.config || {};
  const tel = bot.mt5_telemetry || {};
  const ds = bot.daily_stats || {};
  const stats = bot.stats || {};

  if (cfg.enabled) {
    els.botStatusBadge.textContent = cfg.mode === "MT5_BRIDGE" ? "ARMED (EXNESS MT5)" : "ARMED (PAPER)";
    els.botStatusBadge.className = "badge badge-bull";
    els.botToggleBtn.textContent = "Pause Bot";
  } else {
    els.botStatusBadge.textContent = "PAUSED";
    els.botStatusBadge.className = "badge badge-neut";
    els.botToggleBtn.textContent = "Start Bot";
  }

  if (tel.connected) {
    els.mt5ConnBadge.textContent = `MT5 LIVE (${tel.server || "Exness"})`;
    els.mt5ConnBadge.className = "badge badge-bull";
  } else {
    els.mt5ConnBadge.textContent = cfg.mode === "MT5_BRIDGE" ? "MT5 WAITING HEARTBEAT" : "MT5 OFFLINE";
    els.mt5ConnBadge.className = "badge badge-outline";
  }

  if (!_botConfigSyncedOnce) {
    _botConfigSyncedOnce = true;
    els.botModeSelect.value = cfg.mode || "PAPER";
    els.botBalInput.value = cfg.balance ?? 10000;
    els.botRiskInput.value = cfg.risk_pct ?? 0.75;
    els.botConfInput.value = cfg.min_confidence ?? 65;
    els.botDdInput.value = cfg.daily_max_loss_pct ?? 2.5;
    els.botDaxSymInput.value = cfg.dax_symbol || "DE30m";
    els.botGoldSymInput.value = cfg.gold_symbol || "XAUUSDm";
    els.botBtcSymInput.value = cfg.btc_symbol || "BTCUSDm";
    els.botTradeDaxChk.checked = cfg.trade_dax !== false;
    els.botTradeGoldChk.checked = cfg.trade_gold !== false;
    els.botTradeBtcChk.checked = cfg.trade_btc !== false;
  }

  const dayPnl = ds.realized_pnl || 0;
  const netPnl = stats.net_pnl_usd || 0;
  els.botKpis.innerHTML = `
    <div class="liq-box"><span>Effective Equity</span><strong>$${(bot.effective_balance || 0).toLocaleString()}</strong></div>
    <div class="liq-box"><span>Today Realized PnL</span><strong class="${dayPnl >= 0 ? "text-bull" : "text-bear"}">$${fmtSigned(dayPnl.toFixed(2))}</strong></div>
    <div class="liq-box"><span>Trades Today</span><strong>${ds.trades_taken || 0} / ${cfg.max_daily_trades || 3}</strong></div>
    <div class="liq-box"><span>Bot Win Rate</span><strong>${stats.win_rate_pct != null ? stats.win_rate_pct + "%" : "Pending"}</strong></div>
    <div class="liq-box"><span>Total Net PnL</span><strong class="${netPnl >= 0 ? "text-bull" : "text-bear"}">$${fmtSigned(netPnl.toFixed(2))}</strong></div>
  `;

  const active = bot.active_orders || [];
  els.botActiveBody.innerHTML = active.length
    ? active
        .map((o) => {
          const pnl = o.unrealized_pnl || 0;
          const stTxt = o.be_armed ? `${o.status} (BE)` : o.status;
          return `
            <tr>
              <td><strong>${esc(o.instrument)}</strong><br/><small class="muted-xs">${esc(o.broker_symbol)}</small></td>
              <td class="${o.direction === "LONG" ? "text-bull" : "text-bear"}">${o.order_type} ${o.direction}</td>
              <td>${o.entry}</td>
              <td>${o.sl}</td>
              <td>${o.tp1} / ${o.tp2}</td>
              <td>${o.lots}</td>
              <td class="${pnl >= 0 ? "text-bull" : "text-bear"}">$${fmtSigned(pnl.toFixed(2))}</td>
              <td>${esc(stTxt)}</td>
              <td><button type="button" class="btn btn-xs btn-ghost" data-bot-close="${esc(o.id)}">${o.status === "PENDING" ? "Cancel" : "Close"}</button></td>
            </tr>
          `;
        })
        .join("")
    : `<tr><td colspan="9" class="muted-xs">No active bot positions or pending limit orders.</td></tr>`;

  const logs = bot.decision_log || [];
  els.botDecisionLog.innerHTML = logs.length
    ? logs
        .map((l) => `<li><span class="muted-xs">${esc(l.time)}</span> <strong class="text-${l.tone}">[${esc(l.instrument)} ${esc(l.action)}]</strong> ${esc(l.detail)}</li>`)
        .join("")
    : `<li class="muted-xs">Bot idle — press "Start Bot" or "Evaluate Now" to run institutional gates.</li>`;

  const closed = bot.closed_trades || [];
  els.botClosedStat.textContent = `${stats.closed_count || 0} closed (${stats.wins || 0} wins)`;
  els.botClosedBody.innerHTML = closed.length
    ? closed
        .map(
          (c) => `
          <tr>
            <td>${esc(c.closed_time)}</td>
            <td>${esc(c.instrument)}</td>
            <td class="${c.direction === "LONG" ? "text-bull" : "text-bear"}">${c.direction}</td>
            <td>${c.entry} &rarr; ${c.exit}</td>
            <td>${esc(c.reason)}</td>
            <td class="${c.pnl_usd >= 0 ? "text-bull" : "text-bear"}">$${fmtSigned(c.pnl_usd.toFixed(2))} (${fmtSigned(c.r_multiple)}R)</td>
          </tr>`
        )
        .join("")
    : `<tr><td colspan="6" class="muted-xs">No closed bot trades yet.</td></tr>`;
}

async function postBotJson(url, payload = {}) {
  const resp = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const st = await resp.json();
  renderBotPanel(st);
}

els.botSaveCfgBtn.addEventListener("click", () => {
  postBotJson("api/bot/config", {
    mode: els.botModeSelect.value,
    balance: parseFloat(els.botBalInput.value) || 10000,
    risk_pct: parseFloat(els.botRiskInput.value) || 0.75,
    min_confidence: parseInt(els.botConfInput.value, 10) || 65,
    daily_max_loss_pct: parseFloat(els.botDdInput.value) || 2.5,
    dax_symbol: els.botDaxSymInput.value.trim() || "DE30m",
    gold_symbol: els.botGoldSymInput.value.trim() || "XAUUSDm",
    btc_symbol: els.botBtcSymInput.value.trim() || "BTCUSDm",
    trade_dax: els.botTradeDaxChk.checked,
    trade_gold: els.botTradeGoldChk.checked,
    trade_btc: els.botTradeBtcChk.checked,
  });
});

els.botToggleBtn.addEventListener("click", async () => {
  const curArmed = els.botToggleBtn.textContent.includes("Pause");
  await postBotJson("api/bot/config", { enabled: !curArmed });
  if (!curArmed) {
    await postBotJson("api/bot/run");
  }
});

els.botRunNowBtn.addEventListener("click", () => postBotJson("api/bot/run"));
els.botKillBtn.addEventListener("click", () => postBotJson("api/bot/kill"));
els.botActiveBody.addEventListener("click", (e) => {
  const btn = e.target.closest("[data-bot-close]");
  if (btn) postBotJson("api/bot/close", { order_id: btn.dataset.botClose });
});

setInterval(async () => {
  try {
    const r = await fetch("api/bot/status");
    if (r.ok) renderBotPanel(await r.json());
  } catch (e) {}
}, 20000);


const quitBtn = document.getElementById("quitDesktopBtn");
if (quitBtn) {
  quitBtn.addEventListener("click", async () => {
    try { await fetch("api/shutdown"); } catch (e) {}
    document.body.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100vh;font-family:sans-serif;background:#080d16;color:#e2e8f0;text-align:center"><div><h2>DAX, Gold &amp; BTC Sentinel Stopped</h2><p style="color:#8b9bb4">You can safely close this browser tab.</p></div></div>';
  });
}
"""

# ==============================================================================
# 4B. REAL-TIME WIN-WORLD SMC EXECUTION BOT & EXNESS MT5 BRIDGE
# ==============================================================================

def fetch_fast_spot_quotes() -> Dict[str, Optional[float]]:
    dax_q = _fetch_yahoo_quote({"symbol": "^GDAXI", "name": "DAX 40"}, include_series=False)
    gold_q = _fetch_yahoo_quote({"symbol": "GC=F", "name": "Gold"}, include_series=False)
    btc_q = _fetch_yahoo_quote({"symbol": "BTC-USD", "name": "Bitcoin"}, include_series=False)
    return {
        "DAX": dax_q["price"] if dax_q else None,
        "GOLD": gold_q["price"] if gold_q else None,
        "BTC": btc_q["price"] if btc_q else None,
    }



DEFAULT_CONFIG = {
    "enabled": False,
    "mode": "PAPER",  # "PAPER" or "MT5_BRIDGE"
    "balance": 10000.0,
    "risk_pct": 0.75,
    "min_confidence": 65,
    "min_rr2": 1.8,
    "daily_max_loss_pct": 2.5,
    "max_daily_trades": 4,
    "max_open_positions": 3,
    "trade_dax": True,
    "trade_gold": True,
    "trade_btc": True,
    "dax_symbol": "DE30m",
    "gold_symbol": "XAUUSDm",
    "btc_symbol": "BTCUSDm",
    "dax_max_spread": 4.5,
    "gold_max_spread": 0.65,
    "btc_max_spread": 45.0,
    "dax_pt_value": 1.0,      # $1 per point per 1.0 lot (adjust to broker contract)
    "gold_pt_value": 100.0,   # $100 per $1 move per 1.00 lot XAUUSD (0.01 lot = $1/pt)
    "btc_pt_value": 1.0,      # $1 per $1 move per 1.00 lot BTCUSD (0.01 lot = $0.01/pt)
    "partial_tp1_pct": 50,
    "allow_pending_limits": True,
}


class SmcExecutionBot:
    def __init__(self, state_path: Optional[Path] = None):
        self.state_path = state_path or (Path(__file__).resolve().parent / "bot_state.json")
        self.state = self._load_state()

    def _load_state(self) -> Dict:
        today_de = to_frankfurt_dt()[0].strftime("%Y-%m-%d")
        base = {
            "config": dict(DEFAULT_CONFIG),
            "active_orders": [],
            "closed_trades": [],
            "outbox_commands": [],
            "mt5_telemetry": {
                "connected": False,
                "last_heartbeat_ts": 0,
                "account_login": None,
                "server": "",
                "balance": None,
                "equity": None,
                "dax_spread": None,
                "gold_spread": None,
                "btc_spread": None,
                "broker_positions": [],
            },
            "daily_stats": {
                "date": today_de,
                "trades_taken": 0,
                "realized_pnl": 0.0,
                "halted_reason": "",
            },
            "decision_log": [],
            "last_eval_ts": 0,
        }
        if self.state_path.exists():
            try:
                saved = json.loads(self.state_path.read_text(encoding="utf-8"))
                if isinstance(saved, dict):
                    cfg = dict(DEFAULT_CONFIG)
                    cfg.update(saved.get("config") or {})
                    base["config"] = cfg
                    base["active_orders"] = saved.get("active_orders") or []
                    base["closed_trades"] = saved.get("closed_trades") or []
                    base["outbox_commands"] = saved.get("outbox_commands") or []
                    if saved.get("mt5_telemetry"):
                        base["mt5_telemetry"].update(saved["mt5_telemetry"])
                    if saved.get("daily_stats"):
                        base["daily_stats"].update(saved["daily_stats"])
                    base["decision_log"] = saved.get("decision_log") or []
                    base["last_eval_ts"] = saved.get("last_eval_ts") or 0
            except Exception:
                pass
        self._roll_daily_stats_if_needed(base)
        return base

    def _save(self):
        try:
            self.state_path.write_text(json.dumps(self.state, indent=2), encoding="utf-8")
        except Exception:
            pass

    def _roll_daily_stats_if_needed(self, st: Optional[Dict] = None):
        st = st or self.state
        today_de = to_frankfurt_dt()[0].strftime("%Y-%m-%d")
        if st["daily_stats"].get("date") != today_de:
            st["daily_stats"] = {
                "date": today_de,
                "trades_taken": 0,
                "realized_pnl": 0.0,
                "halted_reason": "",
            }

    def _log(self, instrument: str, action: str, detail: str, tone: str = "neut"):
        dt_de, tz = to_frankfurt_dt()
        entry = {
            "ts": int(time.time()),
            "time": dt_de.strftime("%H:%M:%S ") + tz,
            "instrument": instrument,
            "action": action,
            "detail": detail,
            "tone": tone,
        }
        # Avoid spamming identical consecutive log lines
        logs = self.state["decision_log"]
        if logs and logs[0]["instrument"] == instrument and logs[0]["action"] == action and logs[0]["detail"] == detail:
            logs[0]["ts"] = entry["ts"]
            logs[0]["time"] = entry["time"]
        else:
            logs.insert(0, entry)
            self.state["decision_log"] = logs[:50]

    def _queue_bridge_cmd(self, cmd_type: str, payload: Dict):
        if self.state["config"].get("mode") != "MT5_BRIDGE":
            return
        cmd = {
            "cmd_id": f"cmd-{int(time.time() * 1000)}-{len(self.state['outbox_commands'])}",
            "created_ts": int(time.time()),
            "type": cmd_type,
            **payload,
        }
        self.state["outbox_commands"].append(cmd)
        self.state["outbox_commands"] = self.state["outbox_commands"][-40:]

    def update_config(self, updates: Dict) -> Dict:
        cfg = self.state["config"]
        for k, v in updates.items():
            if k not in DEFAULT_CONFIG:
                continue
            if isinstance(DEFAULT_CONFIG[k], bool):
                cfg[k] = bool(v)
            elif isinstance(DEFAULT_CONFIG[k], int):
                cfg[k] = int(v)
            elif isinstance(DEFAULT_CONFIG[k], float):
                cfg[k] = float(v)
            else:
                cfg[k] = str(v).strip()
        if cfg["mode"] not in ("PAPER", "MT5_BRIDGE"):
            cfg["mode"] = "PAPER"
        cfg["risk_pct"] = max(0.1, min(5.0, cfg["risk_pct"]))
        cfg["min_confidence"] = max(45, min(95, cfg["min_confidence"]))
        cfg["daily_max_loss_pct"] = max(0.5, min(10.0, cfg["daily_max_loss_pct"]))
        cfg["max_daily_trades"] = max(1, min(20, cfg["max_daily_trades"]))
        cfg["max_open_positions"] = max(1, min(6, cfg["max_open_positions"]))
        self._log("SYSTEM", "CONFIG UPDATED", f"Mode={cfg['mode']} | Enabled={cfg['enabled']} | Risk={cfg['risk_pct']}% | MinConf={cfg['min_confidence']}%", "neut")
        self._save()
        return self.get_status()

    def kill_switch(self) -> Dict:
        cfg = self.state["config"]
        cfg["enabled"] = False
        closed_cnt = 0
        for order in list(self.state["active_orders"]):
            if order["status"] == "PENDING":
                self._queue_bridge_cmd("CANCEL_ORDER", {"order_id": order["id"], "symbol": order["broker_symbol"], "ticket": order.get("broker_ticket")})
                self.state["active_orders"].remove(order)
                closed_cnt += 1
            elif order["status"] == "OPEN":
                self._queue_bridge_cmd("CLOSE_POSITION", {"order_id": order["id"], "symbol": order["broker_symbol"], "ticket": order.get("broker_ticket")})
                self._finalize_trade(order, order.get("last_price", order["entry"]), "KILL SWITCH")
                closed_cnt += 1
        self._log("SYSTEM", "KILL SWITCH", f"Bot paused & {closed_cnt} active order(s)/position(s) terminated.", "bear")
        self._save()
        return self.get_status()

    def close_order_by_id(self, order_id: str) -> Dict:
        for order in list(self.state["active_orders"]):
            if order["id"] == order_id:
                if order["status"] == "PENDING":
                    self._queue_bridge_cmd("CANCEL_ORDER", {"order_id": order["id"], "symbol": order["broker_symbol"], "ticket": order.get("broker_ticket")})
                    self.state["active_orders"].remove(order)
                    self._log(order["instrument"], "ORDER CANCELLED", f"Cancelled pending {order['direction']} @ {order['entry']}", "neut")
                else:
                    self._queue_bridge_cmd("CLOSE_POSITION", {"order_id": order["id"], "symbol": order["broker_symbol"], "ticket": order.get("broker_ticket")})
                    self._finalize_trade(order, order.get("last_price", order["entry"]), "MANUAL CLOSE")
                self._save()
                break
        return self.get_status()

    def _effective_balance(self) -> float:
        tel = self.state["mt5_telemetry"]
        if self.state["config"]["mode"] == "MT5_BRIDGE" and tel.get("connected") and tel.get("equity"):
            return float(tel["equity"])
        return float(self.state["config"]["balance"])

    def _finalize_trade(self, order: Dict, exit_price: float, reason: str):
        if order in self.state["active_orders"]:
            self.state["active_orders"].remove(order)
        pt_val = order["pt_value"]
        sign = 1.0 if order["direction"] == "LONG" else -1.0
        rem_pnl = round(sign * (exit_price - order["entry"]) * order["lots"] * pt_val, 2)
        total_pnl = round(order.get("realized_pnl", 0.0) + rem_pnl, 2)
        r_mult = round(total_pnl / max(1.0, order["risk_usd"]), 2)

        self.state["daily_stats"]["realized_pnl"] = round(self.state["daily_stats"]["realized_pnl"] + rem_pnl, 2)
        if self.state["config"]["mode"] == "PAPER":
            self.state["config"]["balance"] = round(self.state["config"]["balance"] + rem_pnl, 2)

        dt_de, tz = to_frankfurt_dt()
        self.state["closed_trades"].insert(0, {
            "id": order["id"],
            "instrument": order["instrument"],
            "broker_symbol": order["broker_symbol"],
            "direction": order["direction"],
            "entry": order["entry"],
            "exit": round(exit_price, 2),
            "orig_sl": order["orig_sl"],
            "tp1": order["tp1"],
            "tp2": order["tp2"],
            "orig_lots": order["orig_lots"],
            "pnl_usd": total_pnl,
            "r_multiple": r_mult,
            "reason": reason,
            "closed_time": dt_de.strftime("%m-%d %H:%M ") + tz,
            "mode": order.get("mode", "PAPER"),
        })
        self.state["closed_trades"] = self.state["closed_trades"][:80]
        tone = "bull" if total_pnl > 0 else ("bear" if total_pnl < 0 else "neut")
        self._log(order["instrument"], f"CLOSED ({reason})", f"{order['direction']} exit {round(exit_price, 2)} | PnL: ${total_pnl:+.2f} ({r_mult:+.2f}R)", tone)

    def manage_live_prices(self, prices: Dict[str, Optional[float]]) -> Dict:
        """Fast price tick for active pending limits and open positions (TP1 partial + BE, TP2, TP3, SL)."""
        self._roll_daily_stats_if_needed()
        changed = False

        for order in list(self.state["active_orders"]):
            inst = order["instrument"]
            px = prices.get(inst)
            if px is None:
                continue
            order["last_price"] = px
            changed = True

            # 1. Check PENDING limit fill
            if order["status"] == "PENDING":
                if order["direction"] == "SHORT":
                    if px >= order["sl"]:
                        self._queue_bridge_cmd("CANCEL_ORDER", {"order_id": order["id"], "symbol": order["broker_symbol"]})
                        self.state["active_orders"].remove(order)
                        self._log(inst, "LIMIT INVALIDATED", f"Price {px} breached SL {order['sl']} before fill.", "neut")
                        continue
                    if px >= order["entry_low"]:
                        order["status"] = "OPEN"
                        order["entry"] = round(px, 2)
                        self._log(inst, "LIMIT FILLED", f"SHORT filled @ {order['entry']} ({order['lots']} lots)", "bear")
                else:
                    if px <= order["sl"]:
                        self._queue_bridge_cmd("CANCEL_ORDER", {"order_id": order["id"], "symbol": order["broker_symbol"]})
                        self.state["active_orders"].remove(order)
                        self._log(inst, "LIMIT INVALIDATED", f"Price {px} breached SL {order['sl']} before fill.", "neut")
                        continue
                    if px <= order["entry_high"]:
                        order["status"] = "OPEN"
                        order["entry"] = round(px, 2)
                        self._log(inst, "LIMIT FILLED", f"LONG filled @ {order['entry']} ({order['lots']} lots)", "bull")
                continue

            # 2. Manage OPEN position
            sign = 1.0 if order["direction"] == "LONG" else -1.0
            pt_val = order["pt_value"]
            order["unrealized_pnl"] = round(sign * (px - order["entry"]) * order["lots"] * pt_val, 2)

            # Check Stop Loss
            if (order["direction"] == "SHORT" and px >= order["sl"]) or (order["direction"] == "LONG" and px <= order["sl"]):
                self._queue_bridge_cmd("CLOSE_POSITION", {"order_id": order["id"], "symbol": order["broker_symbol"], "ticket": order.get("broker_ticket")})
                reason = "BE STOP" if order.get("be_armed") else "SL HIT"
                self._finalize_trade(order, order["sl"], reason)
                continue

            # Check TP1 Partial Close + Move SL to Breakeven
            if not order.get("tp1_hit"):
                hit_tp1 = (order["direction"] == "SHORT" and px <= order["tp1"]) or (order["direction"] == "LONG" and px >= order["tp1"])
                if hit_tp1:
                    order["tp1_hit"] = True
                    order["be_armed"] = True
                    be_buf = 1.5 if inst == "DAX" else (0.30 if inst == "GOLD" else 15.0)
                    new_sl = round(order["entry"] - be_buf if order["direction"] == "SHORT" else order["entry"] + be_buf, 2)
                    order["sl"] = new_sl

                    # Partial close (respect Exness 0.01 lot step)
                    pct = self.state["config"]["partial_tp1_pct"] / 100.0
                    close_lots = round(order["lots"] * pct, 2)
                    if close_lots >= 0.01 and order["lots"] - close_lots >= 0.01:
                        part_pnl = round(sign * (px - order["entry"]) * close_lots * pt_val, 2)
                        order["realized_pnl"] = round(order.get("realized_pnl", 0.0) + part_pnl, 2)
                        order["lots"] = round(order["lots"] - close_lots, 2)
                        self.state["daily_stats"]["realized_pnl"] = round(self.state["daily_stats"]["realized_pnl"] + part_pnl, 2)
                        if self.state["config"]["mode"] == "PAPER":
                            self.state["config"]["balance"] = round(self.state["config"]["balance"] + part_pnl, 2)
                        self._queue_bridge_cmd("PARTIAL_CLOSE", {"order_id": order["id"], "symbol": order["broker_symbol"], "lots": close_lots, "ticket": order.get("broker_ticket")})
                        self._log(inst, "TP1 PARTIAL + BE", f"Closed {close_lots} lots @ {px} (+${part_pnl:.2f}), SL -> BE {new_sl}", "bull")
                    else:
                        self._log(inst, "TP1 HIT -> BE ARMED", f"TP1 {order['tp1']} tagged, SL moved to BE {new_sl}", "bull")

                    self._queue_bridge_cmd("MODIFY_SL", {"order_id": order["id"], "symbol": order["broker_symbol"], "sl": new_sl, "tp": order["tp2"], "ticket": order.get("broker_ticket")})

            # Check TP2 Target
            hit_tp2 = (order["direction"] == "SHORT" and px <= order["tp2"]) or (order["direction"] == "LONG" and px >= order["tp2"])
            if hit_tp2:
                self._queue_bridge_cmd("CLOSE_POSITION", {"order_id": order["id"], "symbol": order["broker_symbol"], "ticket": order.get("broker_ticket")})
                self._finalize_trade(order, order["tp2"], "TP2 TARGET WIN")

        if changed:
            self._save()
        return self.get_status()

    def evaluate_dashboard_and_execute(self, dashboard_data: Dict) -> Dict:
        """Full SMC institutional evaluation on DAX 40, GOLD (GC=F), and BTC (BTC-USD) signals."""
        self._roll_daily_stats_if_needed()
        self.state["last_eval_ts"] = int(time.time())
        cfg = self.state["config"]

        quotes = {q["symbol"]: q["price"] for q in (dashboard_data.get("macro_quotes") or [])}
        prices = {"DAX": quotes.get("^GDAXI"), "GOLD": quotes.get("GC=F"), "BTC": quotes.get("BTC-USD")}
        self.manage_live_prices(prices)

        if not cfg["enabled"]:
            self._save()
            return self.get_status()

        # Daily Max Loss Circuit Breaker
        bal = self._effective_balance()
        max_loss_usd = bal * (cfg["daily_max_loss_pct"] / 100.0)
        if self.state["daily_stats"]["realized_pnl"] <= -max_loss_usd:
            reason = f"Daily Max Loss (-{cfg['daily_max_loss_pct']}%) reached (${self.state['daily_stats']['realized_pnl']:.2f})."
            self.state["daily_stats"]["halted_reason"] = reason
            self._log("SYSTEM", "CIRCUIT BREAKER", reason, "bear")
            self._save()
            return self.get_status()

        if self.state["daily_stats"]["trades_taken"] >= cfg["max_daily_trades"]:
            self.state["daily_stats"]["halted_reason"] = f"Max daily trades ({cfg['max_daily_trades']}) reached."
            self._save()
            return self.get_status()

        instruments = []
        if cfg["trade_dax"]:
            instruments.append(("DAX", cfg["dax_symbol"], cfg["dax_pt_value"], cfg["dax_max_spread"], dashboard_data.get("smc", {}), prices.get("DAX")))
        if cfg["trade_gold"]:
            g_smc = (dashboard_data.get("gold") or {}).get("smc", {})
            instruments.append(("GOLD", cfg["gold_symbol"], cfg["gold_pt_value"], cfg["gold_max_spread"], g_smc, prices.get("GOLD")))
        if cfg.get("trade_btc", True):
            b_smc = (dashboard_data.get("btc") or {}).get("smc", {})
            instruments.append(("BTC", cfg.get("btc_symbol", "BTCUSDm"), cfg.get("btc_pt_value", 1.0), cfg.get("btc_max_spread", 45.0), b_smc, prices.get("BTC")))

        tel = self.state["mt5_telemetry"]
        mt5_alive = (time.time() - (tel.get("last_heartbeat_ts") or 0)) < 35

        for inst, broker_sym, pt_val, max_spread, smc, spot in instruments:
            if not smc or not smc.get("available") or spot is None:
                continue

            signals = smc.get("signals") or {}
            pri = signals.get("primary")
            gates = signals.get("gates") or {}
            kz = smc.get("killzone") or {}
            if not pri:
                continue

            # Cancel any pending limit order if Killzone closed or News Blackout active
            for ord_item in list(self.state["active_orders"]):
                if ord_item["instrument"] == inst and ord_item["status"] == "PENDING":
                    if kz.get("is_deadzone") or (gates.get("blackout") or {}).get("active"):
                        self._queue_bridge_cmd("CANCEL_ORDER", {"order_id": ord_item["id"], "symbol": broker_sym})
                        self.state["active_orders"].remove(ord_item)
                        self._log(inst, "AUTO-CANCELLED LIMIT", "Entered deadzone or news blackout before fill.", "neut")

            # Already has open/pending order on this instrument?
            if any(o["instrument"] == inst for o in self.state["active_orders"]):
                continue
            if len(self.state["active_orders"]) >= cfg["max_open_positions"]:
                continue

            # Institutional Pre-Flight Gates
            if (gates.get("blackout") or {}).get("active"):
                self._log(inst, "BLOCKED (NEWS)", gates["blackout"].get("status", "High-impact news blackout"), "neut")
                continue
            if kz.get("is_deadzone"):
                self._log(inst, "BLOCKED (DEADZONE)", f"{kz.get('phase')} — outside London/NY Killzone", "neut")
                continue
            if (gates.get("adr") or {}).get("exhausted"):
                self._log(inst, "BLOCKED (ADR)", f"ADR {gates['adr'].get('consumed_pct')}% exhausted — no chasing", "neut")
                continue
            if pri["confidence"] < cfg["min_confidence"]:
                self._log(inst, "SKIPPED (CONF)", f"{pri['direction']} {pri['confidence']}% < {cfg['min_confidence']}% floor", "neut")
                continue
            if pri["rr2"] < cfg["min_rr2"]:
                self._log(inst, "SKIPPED (R:R)", f"TP2 R:R {pri['rr2']} < {cfg['min_rr2']} minimum", "neut")
                continue

            # Exness Spread Check when MT5 connected
            cur_spread = tel.get("dax_spread") if inst == "DAX" else (tel.get("gold_spread") if inst == "GOLD" else tel.get("btc_spread"))
            if cfg["mode"] == "MT5_BRIDGE":
                if not mt5_alive:
                    self._log(inst, "MT5 WAITING", "Armed for MT5_BRIDGE — start Exness_SMC_Bridge.mq5 or exness_mt5_worker.py", "neut")
                    continue
                if cur_spread is not None and cur_spread > max_spread:
                    self._log(inst, "BLOCKED (SPREAD)", f"Exness spread {cur_spread} > max {max_spread}", "bear")
                    continue

            # Determine Market vs Limit Order
            is_active_trigger = pri["status"].startswith("ACTIVE")
            is_pending_limit = cfg["allow_pending_limits"] and "PULLBACK" in pri["status"]
            if not is_active_trigger and not is_pending_limit:
                self._log(inst, "WATCHING", f"{pri['direction']} ({pri['confidence']}%) — {pri['status']}", "neut")
                continue

            entry_px = round(spot, 2) if is_active_trigger else pri["entry_price"]
            sl_px = pri["stop_loss"]
            risk_pts = abs(entry_px - sl_px)
            if risk_pts <= 0:
                continue

            risk_usd = round(bal * (cfg["risk_pct"] / 100.0), 2)
            raw_lots = risk_usd / (risk_pts * pt_val)
            lots = round(max(0.01, min(20.0, raw_lots)), 2)

            order_type = "MARKET" if is_active_trigger else "LIMIT"
            order_id = f"bot-{inst.lower()}-{int(time.time())}"
            new_order = {
                "id": order_id,
                "instrument": inst,
                "broker_symbol": broker_sym,
                "direction": pri["direction"],
                "order_type": order_type,
                "status": "OPEN" if is_active_trigger else "PENDING",
                "entry": entry_px,
                "entry_low": pri["entry_low"],
                "entry_high": pri["entry_high"],
                "sl": sl_px,
                "orig_sl": sl_px,
                "tp1": pri["tp1"],
                "tp2": pri["tp2"],
                "tp3": pri["tp3"],
                "lots": lots,
                "orig_lots": lots,
                "pt_value": pt_val,
                "risk_usd": risk_usd,
                "confidence": pri["confidence"],
                "setup_source": pri["entry_source"],
                "tp1_hit": False,
                "be_armed": False,
                "unrealized_pnl": 0.0,
                "realized_pnl": 0.0,
                "last_price": spot,
                "created_ts": int(time.time()),
                "created_time": to_frankfurt_dt()[0].strftime("%m-%d %H:%M ") + to_frankfurt_dt()[1],
                "mode": cfg["mode"],
                "broker_ticket": None,
            }
            self.state["active_orders"].append(new_order)
            self.state["daily_stats"]["trades_taken"] += 1

            cmd_name = "PLACE_MARKET" if is_active_trigger else "PLACE_LIMIT"
            self._queue_bridge_cmd(cmd_name, {
                "order_id": order_id,
                "symbol": broker_sym,
                "direction": pri["direction"],
                "lots": lots,
                "price": entry_px,
                "sl": sl_px,
                "tp1": pri["tp1"],
                "tp2": pri["tp2"],
                "comment": f"SMC_{inst}_{pri['confidence']}pct",
            })
            tone = "bull" if pri["direction"] == "LONG" else "bear"
            self._log(
                inst,
                f"{order_type} {pri['direction']}",
                f"{broker_sym} {lots} lots @ {entry_px} | SL {sl_px} | TP1 {pri['tp1']} | TP2 {pri['tp2']} (${risk_usd} risk)",
                tone,
            )

        self._save()
        return self.get_status()

    def poll_bridge_commands(self, single: bool = False) -> Dict:
        """Called by Exness MT5 EA / Python worker to pop pending execution commands."""
        if single:
            cmds = self.state["outbox_commands"][:1]
            self.state["outbox_commands"] = self.state["outbox_commands"][1:]
        else:
            cmds = list(self.state["outbox_commands"])
            self.state["outbox_commands"] = []
        self._save()
        return {"commands": cmds, "ts": int(time.time())}

    def ingest_mt5_report(self, report: Dict) -> Dict:
        """Called by Exness MT5 EA / Python worker to push account equity, spreads, and fills."""
        tel = self.state["mt5_telemetry"]
        tel["connected"] = True
        tel["last_heartbeat_ts"] = int(time.time())
        if "login" in report:
            tel["account_login"] = report["login"]
        if "server" in report:
            tel["server"] = report["server"]
        if "balance" in report:
            tel["balance"] = report["balance"]
        if "equity" in report:
            tel["equity"] = report["equity"]
        if "dax_spread" in report:
            tel["dax_spread"] = report["dax_spread"]
        if "gold_spread" in report:
            tel["gold_spread"] = report["gold_spread"]
        if "btc_spread" in report:
            tel["btc_spread"] = report["btc_spread"]
        if "fills" in report and isinstance(report["fills"], list):
            for fill in report["fills"]:
                oid = fill.get("order_id")
                for o in self.state["active_orders"]:
                    if o["id"] == oid:
                        if fill.get("ticket"):
                            o["broker_ticket"] = fill["ticket"]
                        if fill.get("filled_price"):
                            o["entry"] = float(fill["filled_price"])
                            o["status"] = "OPEN"
        self._save()
        return {"ok": True, "ts": tel["last_heartbeat_ts"]}

    def get_status(self) -> Dict:
        tel = dict(self.state["mt5_telemetry"])
        tel["connected"] = (time.time() - (tel.get("last_heartbeat_ts") or 0)) < 35
        closed = self.state["closed_trades"]
        wins = sum(1 for c in closed if c["pnl_usd"] > 0)
        tot_closed = len(closed)
        win_rate = round((wins / tot_closed) * 100.0, 1) if tot_closed else None
        net_pnl = round(sum(c["pnl_usd"] for c in closed), 2)
        return {
            "config": self.state["config"],
            "effective_balance": round(self._effective_balance(), 2),
            "mt5_telemetry": tel,
            "daily_stats": self.state["daily_stats"],
            "active_orders": self.state["active_orders"],
            "closed_trades": closed[:20],
            "stats": {
                "closed_count": tot_closed,
                "wins": wins,
                "win_rate_pct": win_rate,
                "net_pnl_usd": net_pnl,
            },
            "decision_log": self.state["decision_log"][:25],
            "last_eval_ts": self.state["last_eval_ts"],
        }


# Ready-to-use Exness MT5 MQL5 Expert Advisor & Python MT5 Worker templates

EXNESS_MQL5_EA = r"""//+------------------------------------------------------------------+
//|                                            Exness_SMC_Bridge.mq5 |
//|   Real-Time Exness MT5 Execution Bridge (DAX, Gold & BTC Bot)    |
//|                                                                  |
//|  REQUIRED MT5 SETUP:                                             |
//|   1. Tools -> Options -> Expert Advisors:                        |
//|      [x] Allow algorithmic trading                               |
//|      [x] Allow WebRequest for listed URL:                        |
//|          http://127.0.0.1:8765                                   |
//|   2. Click "Algo Trading" button in top toolbar (turn GREEN)     |
//|   3. Attach to ANY chart -> Check Experts tab for "MT5 LIVE"     |
//+------------------------------------------------------------------+
#property copyright "DAX, Gold & BTC SMC Sentinel v6"
#property version   "2.00"
#include <Trade\Trade.mqh>

input string InpServerUrl  = "http://127.0.0.1:8765"; // Desktop port (:8765) or Web (:8000)
input string InpDaxSymbol  = "";                      // Leave blank to auto-detect (DE30m/DE30/GER40m)
input string InpGoldSymbol = "";                      // Leave blank to auto-detect (XAUUSDm/XAUUSD)
input string InpBtcSymbol  = "";                      // Leave blank to auto-detect (BTCUSDm/BTCUSD)
input int    InpPollSecs   = 2;
input ulong  InpMagic      = 260601;

CTrade trade;
string gDaxSym = "DE30m";
string gGoldSym = "XAUUSDm";
string gBtcSym = "BTCUSDm";
bool   gConnectedOnce = false;
int    gLastErrCode = -999;

string AutoDetectSymbol(string overrideSym, string candidatesCsv, string fallback) {
   if (StringLen(overrideSym) > 0 && SymbolSelect(overrideSym, true)) {
      if (SymbolInfoDouble(overrideSym, SYMBOL_BID) > 0 || SymbolInfoInteger(overrideSym, SYMBOL_DIGITS) > 0)
         return overrideSym;
   }
   string parts[];
   int n = StringSplit(candidatesCsv, ',', parts);
   for (int i = 0; i < n; i++) {
      string s = parts[i];
      if (SymbolSelect(s, true)) {
         if (SymbolInfoDouble(s, SYMBOL_BID) > 0 || SymbolInfoInteger(s, SYMBOL_DIGITS) > 0)
            return s;
      }
   }
   return fallback;
}

string ResolveOrderSymbol(string reqSym) {
   string u = reqSym;
   StringToUpper(u);
   if (StringFind(u, "DE30") >= 0 || StringFind(u, "DE40") >= 0 || StringFind(u, "GER") >= 0 || StringFind(u, "DAX") >= 0)
      return gDaxSym;
   if (StringFind(u, "XAU") >= 0 || StringFind(u, "GOLD") >= 0)
      return gGoldSym;
   if (StringFind(u, "BTC") >= 0)
      return gBtcSym;
   if (SymbolSelect(reqSym, true)) return reqSym;
   return gGoldSym;
}

int OnInit() {
   trade.SetExpertMagicNumber(InpMagic);
   trade.SetDeviationInPoints(30);
   gDaxSym  = AutoDetectSymbol(InpDaxSymbol,  "DE30m,DE30,GER40m,GER40,DE40m,DE40", "DE30m");
   gGoldSym = AutoDetectSymbol(InpGoldSymbol, "XAUUSDm,XAUUSD,XAUUSDc,GOLD", "XAUUSDm");
   gBtcSym  = AutoDetectSymbol(InpBtcSymbol,  "BTCUSDm,BTCUSD,BTCUSDc", "BTCUSDm");

   PrintFormat("Exness_SMC_Bridge v2 initialized | URL=%s | Symbols: DAX=%s, GOLD=%s, BTC=%s",
               InpServerUrl, gDaxSym, gGoldSym, gBtcSym);
   if (!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED))
      Print("WARNING: Top toolbar 'Algo Trading' is OFF! Click Algo Trading to enable orders.");

   EventSetTimer(InpPollSecs);
   SendHeartbeat();
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason) { EventKillTimer(); }

void OnTimer() {
   SendHeartbeat();
   PollCommands();
}

void ReportWebRequestError(string step, int code) {
   int err = GetLastError();
   if (err == gLastErrCode && code == -1) return;
   gLastErrCode = err;
   gConnectedOnce = false;
   if (err == 4014 || err == 4060) {
      PrintFormat("EXNESS BRIDGE ERROR [%s]: WebRequest blocked (err=%d). FIX: MT5 -> Tools -> Options -> Expert Advisors -> check 'Allow WebRequest for listed URL' and add: %s",
                  step, err, InpServerUrl);
   } else if (err == 5203 || code == -1) {
      PrintFormat("EXNESS BRIDGE ERROR [%s]: Cannot reach Sentinel app at %s (code=%d err=%d). Make sure Start_DAX_Sentinel_Windows.bat is running!",
                  step, InpServerUrl, code, err);
   } else {
      PrintFormat("EXNESS BRIDGE HTTP %d on %s (err=%d)", code, step, err);
   }
}

void SendHeartbeat() {
   double daxSp = SymbolInfoInteger(gDaxSym, SYMBOL_SPREAD) * SymbolInfoDouble(gDaxSym, SYMBOL_POINT);
   double gldSp = SymbolInfoInteger(gGoldSym, SYMBOL_SPREAD) * SymbolInfoDouble(gGoldSym, SYMBOL_POINT);
   double btcSp = SymbolInfoInteger(gBtcSym, SYMBOL_SPREAD) * SymbolInfoDouble(gBtcSym, SYMBOL_POINT);
   string json = StringFormat(
      "{\"login\":%I64d,\"server\":\"%s\",\"balance\":%.2f,\"equity\":%.2f,\"dax_spread\":%.2f,\"gold_spread\":%.2f,\"btc_spread\":%.2f}",
      AccountInfoInteger(ACCOUNT_LOGIN), AccountInfoString(ACCOUNT_SERVER),
      AccountInfoDouble(ACCOUNT_BALANCE), AccountInfoDouble(ACCOUNT_EQUITY), daxSp, gldSp, btcSp
   );
   char post[], res[]; string hdrs;
   StringToCharArray(json, post, 0, StringLen(json));
   ResetLastError();
   int code = WebRequest("POST", InpServerUrl + "/api/bot/mt5-report", "Content-Type: application/json\r\n", 2000, post, res, hdrs);
   if (code == 200) {
      gLastErrCode = -999;
      if (!gConnectedOnce) {
         gConnectedOnce = true;
         PrintFormat("EXNESS BRIDGE CONNECTED! Account=%I64d | Server=%s | Balance=%.2f | Equity=%.2f",
                     AccountInfoInteger(ACCOUNT_LOGIN), AccountInfoString(ACCOUNT_SERVER),
                     AccountInfoDouble(ACCOUNT_BALANCE), AccountInfoDouble(ACCOUNT_EQUITY));
      }
   } else {
      ReportWebRequestError("HEARTBEAT", code);
   }
}

void PollCommands() {
   char post[], res[]; string hdrs;
   ResetLastError();
   int code = WebRequest("GET", InpServerUrl + "/api/bot/bridge/poll?single=1", "", 2000, post, res, hdrs);
   if (code != 200) {
      if (code != -1 || !gConnectedOnce) ReportWebRequestError("POLL", code);
      return;
   }
   string body = CharArrayToString(res);
   if (StringFind(body, "\"PLACE_MARKET\"") >= 0 || StringFind(body, "\"PLACE_LIMIT\"") >= 0 ||
       StringFind(body, "\"MODIFY_SL\"") >= 0 || StringFind(body, "\"PARTIAL_CLOSE\"") >= 0 ||
       StringFind(body, "\"CLOSE_POSITION\"") >= 0 || StringFind(body, "\"CANCEL_ORDER\"") >= 0) {
      Print("Bridge received command: ", body);
      ExecuteBridgePayload(body);
   }
}

string ExtractStr(string src, string key) {
   int p = StringFind(src, "\"" + key + "\":");
   if (p < 0) return "";
   int q1 = StringFind(src, "\"", p + StringLen(key) + 3);
   int q2 = StringFind(src, "\"", q1 + 1);
   if (q1 < 0 || q2 < 0) return "";
   return StringSubstr(src, q1 + 1, q2 - q1 - 1);
}

double ExtractNum(string src, string key) {
   int p = StringFind(src, "\"" + key + "\":");
   if (p < 0) return 0;
   int s = p + StringLen(key) + 3;
   while (s < StringLen(src) && (StringGetCharacter(src, s) == ' ' || StringGetCharacter(src, s) == ':')) s++;
   int e = s;
   while (e < StringLen(src)) {
      ushort ch = StringGetCharacter(src, e);
      if ((ch >= '0' && ch <= '9') || ch == '.' || ch == '-') e++; else break;
   }
   return StringToDouble(StringSubstr(src, s, e - s));
}

void ExecuteBridgePayload(string body) {
   string cmdType = ExtractStr(body, "type");
   string rawSym  = ExtractStr(body, "symbol");
   string sym     = ResolveOrderSymbol(rawSym);
   string dir     = ExtractStr(body, "direction");
   string comment = ExtractStr(body, "order_id");
   double lots    = NormalizeDouble(ExtractNum(body, "lots"), 2);
   double price   = ExtractNum(body, "price");
   double sl      = ExtractNum(body, "sl");
   double tp      = ExtractNum(body, "tp2");
   if (tp <= 0) tp = ExtractNum(body, "tp");

   SymbolSelect(sym, true);
   trade.SetTypeFillingBySymbol(sym);
   int digits = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);
   sl    = NormalizeDouble(sl, digits);
   tp    = NormalizeDouble(tp, digits);
   price = NormalizeDouble(price, digits);

   bool ok = false;
   if (cmdType == "PLACE_MARKET") {
      ok = (dir == "BUY" || dir == "LONG") ? trade.Buy(lots, sym, 0, sl, tp, comment) : trade.Sell(lots, sym, 0, sl, tp, comment);
   } else if (cmdType == "PLACE_LIMIT") {
      ok = (dir == "BUY" || dir == "LONG") ? trade.BuyLimit(lots, price, sym, sl, tp, ORDER_TIME_DAY, 0, comment) : trade.SellLimit(lots, price, sym, sl, tp, ORDER_TIME_DAY, 0, comment);
   } else if (cmdType == "MODIFY_SL") {
      for (int i = PositionsTotal() - 1; i >= 0; i--) {
         ulong tk = PositionGetTicket(i);
         if (PositionGetString(POSITION_SYMBOL) == sym) ok = trade.PositionModify(tk, sl, tp);
      }
   } else if (cmdType == "PARTIAL_CLOSE") {
      for (int i = PositionsTotal() - 1; i >= 0; i--) {
         ulong tk = PositionGetTicket(i);
         if (PositionGetString(POSITION_SYMBOL) == sym) ok = trade.PositionClosePartial(tk, lots);
      }
   } else if (cmdType == "CLOSE_POSITION") {
      for (int i = PositionsTotal() - 1; i >= 0; i--) {
         ulong tk = PositionGetTicket(i);
         if (PositionGetString(POSITION_SYMBOL) == sym) ok = trade.PositionClose(tk);
      }
   } else if (cmdType == "CANCEL_ORDER") {
      for (int i = OrdersTotal() - 1; i >= 0; i--) {
         ulong tk = OrderGetTicket(i);
         if (OrderGetString(ORDER_SYMBOL) == sym) ok = trade.OrderDelete(tk);
      }
   }
   PrintFormat("Executed %s on %s (raw=%s) -> ok=%s retcode=%d (%s)",
               cmdType, sym, rawSym, ok ? "true" : "false", trade.ResultRetcode(), trade.ResultRetcodeDescription());
}
"""

EXNESS_PYTHON_WORKER = r'''#!/usr/bin/env python3
"""
Standalone Exness MT5 Python Bridge Worker (Windows + Exness MetaTrader 5 Desktop)
Requires: Python 3.10-3.12 (64-bit) + pip install MetaTrader5 requests
Run alongside your logged-in Exness MT5 Terminal.
"""
import sys
import requests
import MetaTrader5 as mt5

SERVER_URL = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8765"
DAX_CANDIDATES = ["DE30m", "DE30", "GER40m", "GER40", "DE40m", "DE40"]
GOLD_CANDIDATES = ["XAUUSDm", "XAUUSD", "XAUUSDc", "GOLD"]
BTC_CANDIDATES = ["BTCUSDm", "BTCUSD", "BTCUSDc"]


def pick_symbol(candidates):
    for s in candidates:
        info = mt5.symbol_info(s)
        if info is not None:
            mt5.symbol_select(s, True)
            return s
    return candidates[0]


def resolve_symbol(req_sym, dax_sym, gold_sym, btc_sym):
    u = (req_sym or "").upper()
    if any(k in u for k in ("DE30", "DE40", "GER", "DAX")):
        return dax_sym
    if any(k in u for k in ("XAU", "GOLD")):
        return gold_sym
    if "BTC" in u:
        return btc_sym
    return req_sym or gold_sym


def filling_mode_for(sym):
    info = mt5.symbol_info(sym)
    if info is not None:
        fm = info.filling_mode
        if fm & 2:
            return mt5.ORDER_FILLING_IOC
        if fm & 1:
            return mt5.ORDER_FILLING_FOK
    return mt5.ORDER_FILLING_RETURN


def main():
    if not mt5.initialize():
        raise RuntimeError(f"MT5 initialize() failed: {mt5.last_error()}")
    dax_sym = pick_symbol(DAX_CANDIDATES)
    gold_sym = pick_symbol(GOLD_CANDIDATES)
    btc_sym = pick_symbol(BTC_CANDIDATES)
    print(f"Connected to Exness MT5 | Server={SERVER_URL} | DAX={dax_sym} | GOLD={gold_sym} | BTC={btc_sym}")

    try:
        while True:
            acct = mt5.account_info()
            d_tick = mt5.symbol_info_tick(dax_sym)
            g_tick = mt5.symbol_info_tick(gold_sym)
            b_tick = mt5.symbol_info_tick(btc_sym)
            payload = {
                "login": acct.login if acct else None,
                "server": acct.server if acct else "",
                "balance": acct.balance if acct else None,
                "equity": acct.equity if acct else None,
                "dax_spread": round(d_tick.ask - d_tick.bid, 2) if d_tick else None,
                "gold_spread": round(g_tick.ask - g_tick.bid, 2) if g_tick else None,
                "btc_spread": round(b_tick.ask - b_tick.bid, 2) if b_tick else None,
            }
            try:
                requests.post(f"{SERVER_URL}/api/bot/mt5-report", json=payload, timeout=3)
                cmds = requests.get(f"{SERVER_URL}/api/bot/bridge/poll", timeout=3).json().get("commands", [])
                for c in cmds:
                    sym = resolve_symbol(c.get("symbol"), dax_sym, gold_sym, btc_sym)
                    mt5.symbol_select(sym, True)
                    tick = mt5.symbol_info_tick(sym)
                    if not tick:
                        print("No tick for", sym)
                        continue
                    fill_mode = filling_mode_for(sym)
                    ctype = c["type"]
                    if ctype == "PLACE_MARKET":
                        is_buy = c["direction"] == "LONG"
                        req = {
                            "action": mt5.TRADE_ACTION_DEAL,
                            "symbol": sym,
                            "volume": float(c["lots"]),
                            "type": mt5.ORDER_TYPE_BUY if is_buy else mt5.ORDER_TYPE_SELL,
                            "price": tick.ask if is_buy else tick.bid,
                            "sl": float(c["sl"]),
                            "tp": float(c["tp2"]),
                            "deviation": 30,
                            "comment": c.get("order_id", "SMC_BOT"),
                            "type_filling": fill_mode,
                        }
                        print("MT5 Market:", mt5.order_send(req))
                    elif ctype == "PLACE_LIMIT":
                        is_buy = c["direction"] == "LONG"
                        req = {
                            "action": mt5.TRADE_ACTION_PENDING,
                            "symbol": sym,
                            "volume": float(c["lots"]),
                            "type": mt5.ORDER_TYPE_BUY_LIMIT if is_buy else mt5.ORDER_TYPE_SELL_LIMIT,
                            "price": float(c["price"]),
                            "sl": float(c["sl"]),
                            "tp": float(c["tp2"]),
                            "comment": c.get("order_id", "SMC_BOT"),
                            "type_time": mt5.ORDER_TIME_DAY,
                        }
                        print("MT5 Limit:", mt5.order_send(req))
                    elif ctype == "MODIFY_SL":
                        for pos in mt5.positions_get(symbol=sym) or []:
                            mt5.order_send({"action": mt5.TRADE_ACTION_SLTP, "position": pos.ticket, "symbol": sym, "sl": float(c["sl"]), "tp": float(c["tp"])})
                    elif ctype in ("PARTIAL_CLOSE", "CLOSE_POSITION"):
                        for pos in mt5.positions_get(symbol=sym) or []:
                            vol = float(c.get("lots", pos.volume)) if ctype == "PARTIAL_CLOSE" else pos.volume
                            is_buy = pos.type == mt5.POSITION_TYPE_BUY
                            mt5.order_send({
                                "action": mt5.TRADE_ACTION_DEAL, "position": pos.ticket, "symbol": sym,
                                "volume": min(vol, pos.volume),
                                "type": mt5.ORDER_TYPE_SELL if is_buy else mt5.ORDER_TYPE_BUY,
                                "price": tick.bid if is_buy else tick.ask, "deviation": 30,
                                "type_filling": fill_mode,
                            })
                    elif ctype == "CANCEL_ORDER":
                        for od in mt5.orders_get(symbol=sym) or []:
                            mt5.order_send({"action": mt5.TRADE_ACTION_REMOVE, "order": od.ticket})
            except Exception as e:
                print("Bridge error:", e)
            time.sleep(2)
    finally:
        mt5.shutdown()


if __name__ == "__main__":
    main()
'''

BOT = SmcExecutionBot(state_path=Path(__file__).resolve().parent / "bot_state.json")
_bot_lock = threading.Lock()

# ==============================================================================
# 5. LOCAL DESKTOP HTTP SERVER & AUTO-LAUNCH
# ==============================================================================

CACHE_TTL_SECONDS = 180
_cache = {"data": None, "ts": 0.0, "lock": threading.Lock()}
_server_ref = {"httpd": None, "port": 8765}


def get_dashboard_data(force: bool = False) -> Dict:
    now = time.time()
    if not force and _cache["data"] is not None and (now - _cache["ts"] < CACHE_TTL_SECONDS):
        data = dict(_cache["data"])
        with _bot_lock:
            data["bot"] = BOT.get_status()
        return data
    with _cache["lock"]:
        now = time.time()
        if not force and _cache["data"] is not None and (now - _cache["ts"] < CACHE_TTL_SECONDS):
            data = dict(_cache["data"])
            with _bot_lock:
                data["bot"] = BOT.get_status()
            return data
        data = fetch_full_dashboard()
        _cache["data"] = data
        _cache["ts"] = time.time()
        out = dict(data)
        with _bot_lock:
            out["bot"] = BOT.get_status()
        return out


def realtime_bot_loop():
    while True:
        time.sleep(20)
        try:
            with _bot_lock:
                enabled = BOT.state["config"].get("enabled", False)
                has_active = bool(BOT.state["active_orders"])
            if not enabled and not has_active:
                continue
            quotes = fetch_fast_spot_quotes()
            dash = _cache["data"] if _cache["data"] is not None else get_dashboard_data(force=False)
            with _bot_lock:
                BOT.manage_live_prices(quotes)
                if BOT.state["config"].get("enabled") and dash:
                    BOT.evaluate_dashboard_and_execute(dash)
        except Exception:
            pass


class DesktopHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def _send_bytes(self, status: int, content_type: str, data: bytes, extra_headers: Optional[Dict[str, str]] = None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        if extra_headers:
            for k, v in extra_headers.items():
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def _send_json(self, status: int, payload: Dict):
        self._send_bytes(status, "application/json; charset=utf-8", json.dumps(payload).encode("utf-8"))

    def _read_json_body(self) -> Optional[Dict]:
        try:
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length) if length > 0 else b"{}"
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return None

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        qs = urllib.parse.parse_qs(parsed.query)

        if path in ("/", "/index.html"):
            return self._send_bytes(200, "text/html; charset=utf-8", INDEX_HTML.encode("utf-8"))
        if path == "/manifest.json":
            return self._send_bytes(200, "application/json; charset=utf-8", MANIFEST_JSON.encode("utf-8"))
        if path == "/icon.svg":
            return self._send_bytes(200, "image/svg+xml; charset=utf-8", ICON_SVG.encode("utf-8"))
        if path == "/static/styles.css":
            return self._send_bytes(200, "text/css; charset=utf-8", STYLES_CSS.encode("utf-8"))
        if path == "/static/app.js":
            return self._send_bytes(200, "application/javascript; charset=utf-8", APP_JS.encode("utf-8"))
        if path == "/api/health":
            return self._send_json(200, {"status": "ok", "cached": _cache["data"] is not None})
        if path == "/api/dashboard":
            force = qs.get("force", ["0"])[0] in ("1", "true", "yes")
            return self._send_json(200, get_dashboard_data(force=force))
        if path == "/api/search":
            q = qs.get("q", [""])[0].strip()
            if not q:
                return self._send_json(400, {"error": "Missing query parameter 'q'"})
            inst = qs.get("instrument", ["DAX"])[0].upper()
            if inst not in ("DAX", "GOLD", "BTC"):
                inst = "DAX"
            return self._send_json(200, search_internet_for_dax(q, instrument=inst))
        if path == "/api/article":
            url = qs.get("url", [""])[0].strip()
            title = qs.get("title", [""])[0].strip()
            summary = qs.get("summary", [""])[0].strip()
            return self._send_json(200, fetch_article_deep_read(url, title, summary))
        if path == "/api/bot/status":
            with _bot_lock:
                return self._send_json(200, BOT.get_status())
        if path == "/api/bot/bridge/poll":
            single = qs.get("single", ["0"])[0] in ("1", "true")
            with _bot_lock:
                return self._send_json(200, BOT.poll_bridge_commands(single=single))
        if path == "/api/bot/download/ea":
            ea_txt = EXNESS_MQL5_EA.replace("http://127.0.0.1:8765", f"http://127.0.0.1:{_server_ref['port']}")
            return self._send_bytes(
                200, "text/plain; charset=utf-8", ea_txt.encode("utf-8"),
                {"Content-Disposition": 'attachment; filename="Exness_SMC_Bridge.mq5"'}
            )
        if path == "/api/bot/download/worker":
            wk_txt = EXNESS_PYTHON_WORKER.replace("http://127.0.0.1:8765", f"http://127.0.0.1:{_server_ref['port']}")
            return self._send_bytes(
                200, "text/plain; charset=utf-8", wk_txt.encode("utf-8"),
                {"Content-Disposition": 'attachment; filename="exness_mt5_worker.py"'}
            )
        if path == "/api/shutdown":
            self._send_json(200, {"status": "shutting_down"})
            if _server_ref["httpd"] is not None:
                threading.Thread(target=_server_ref["httpd"].shutdown, daemon=True).start()
            return
        self._send_bytes(404, "text/plain; charset=utf-8", b"Not found")

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == "/api/ai-analyze":
            body = self._read_json_body()
            if body is None:
                return self._send_json(400, {"ok": False, "error": "Invalid JSON body"})
            res = run_ai_fundamental_thesis(
                title=body.get("title", ""),
                text=body.get("text", ""),
                api_url=body.get("api_url", ""),
                api_key=body.get("api_key", ""),
                model=body.get("model", ""),
            )
            return self._send_json(200, res)
        if path == "/api/bot/config":
            body = self._read_json_body()
            if body is None:
                return self._send_json(400, {"error": "Invalid JSON"})
            with _bot_lock:
                return self._send_json(200, BOT.update_config(body))
        if path == "/api/bot/run":
            data = get_dashboard_data(force=False)
            with _bot_lock:
                return self._send_json(200, BOT.evaluate_dashboard_and_execute(data))
        if path == "/api/bot/kill":
            with _bot_lock:
                return self._send_json(200, BOT.kill_switch())
        if path == "/api/bot/close":
            body = self._read_json_body()
            if body is None:
                return self._send_json(400, {"error": "Invalid JSON"})
            oid = str(body.get("order_id", "")).strip()
            with _bot_lock:
                return self._send_json(200, BOT.close_order_by_id(oid))
        if path == "/api/bot/mt5-report":
            body = self._read_json_body()
            if body is None:
                return self._send_json(400, {"error": "Invalid JSON"})
            with _bot_lock:
                return self._send_json(200, BOT.ingest_mt5_report(body))

        self._send_bytes(404, "text/plain; charset=utf-8", b"Not found")


def _find_free_port(preferred: int = 8765) -> int:
    for port in [preferred] + list(range(8766, 8790)):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port
    return 0


def main():
    port = _find_free_port(int(os.environ.get("PORT", "8765")))
    httpd = ThreadingHTTPServer(("127.0.0.1", port), DesktopHandler)
    _server_ref["httpd"] = httpd
    actual_port = httpd.server_address[1]
    _server_ref["port"] = actual_port
    url = f"http://127.0.0.1:{actual_port}"

    threading.Thread(target=get_dashboard_data, kwargs={"force": True}, daemon=True).start()
    threading.Thread(target=realtime_bot_loop, daemon=True).start()

    print("=" * 64)
    print("  DAX & Gold Sentinel v6.0 + SMC Execution Bot (Desktop Edition)")
    print(f"  Running locally at: {url}")
    print("  Close this window or click 'Quit' in the browser to stop.")
    print("=" * 64)

    threading.Timer(0.6, lambda: webbrowser.open(url)).start()

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()
