//+------------------------------------------------------------------+
//|                                            Exness_SMC_Bridge.mq5 |
//|   Real-Time Exness MT5 Execution Bridge (DAX, Gold & BTC Bot)    |
//|                                                                  |
//|  REQUIRED MT5 SETUP:                                             |
//|   1. Tools -> Options -> Expert Advisors:                        |
//|      [x] Allow algorithmic trading                               |
//|      [x] Allow WebRequest for listed URL:                        |
//|          http://127.0.0.1:8765                                   |
//|   2. Click "Algo Trading" button in top toolbar (turn GREEN)     |
//|   3. Attach to ANY chart -> Check Experts tab for "MT5 LIVE"     |
//+------------------------------------------------------------------+
#property copyright "DAX, Gold & BTC SMC Sentinel v6"
#property version   "2.00"
#include <Trade\Trade.mqh>

input string InpServerUrl  = "http://127.0.0.1:8765"; // Desktop port (:8765) or Web (:8000)
input string InpDaxSymbol  = "";                      // Leave blank to auto-detect (DE30m/DE30/GER40m)
input string InpGoldSymbol = "";                      // Leave blank to auto-detect (XAUUSDm/XAUUSD)
input string InpBtcSymbol  = "";                      // Leave blank to auto-detect (BTCUSDm/BTCUSD)
input int    InpPollSecs   = 2;
input ulong  InpMagic      = 260601;

CTrade trade;
string gDaxSym = "DE30m";
string gGoldSym = "XAUUSDm";
string gBtcSym = "BTCUSDm";
bool   gConnectedOnce = false;
int    gLastErrCode = -999;

string AutoDetectSymbol(string overrideSym, string candidatesCsv, string fallback) {
   if (StringLen(overrideSym) > 0 && SymbolSelect(overrideSym, true)) {
      if (SymbolInfoDouble(overrideSym, SYMBOL_BID) > 0 || SymbolInfoInteger(overrideSym, SYMBOL_DIGITS) > 0)
         return overrideSym;
   }
   string parts[];
   int n = StringSplit(candidatesCsv, ',', parts);
   for (int i = 0; i < n; i++) {
      string s = parts[i];
      if (SymbolSelect(s, true)) {
         if (SymbolInfoDouble(s, SYMBOL_BID) > 0 || SymbolInfoInteger(s, SYMBOL_DIGITS) > 0)
            return s;
      }
   }
   return fallback;
}

string ResolveOrderSymbol(string reqSym) {
   string u = reqSym;
   StringToUpper(u);
   if (StringFind(u, "DE30") >= 0 || StringFind(u, "DE40") >= 0 || StringFind(u, "GER") >= 0 || StringFind(u, "DAX") >= 0)
      return gDaxSym;
   if (StringFind(u, "XAU") >= 0 || StringFind(u, "GOLD") >= 0)
      return gGoldSym;
   if (StringFind(u, "BTC") >= 0)
      return gBtcSym;
   if (SymbolSelect(reqSym, true)) return reqSym;
   return gGoldSym;
}

int OnInit() {
   trade.SetExpertMagicNumber(InpMagic);
   trade.SetDeviationInPoints(30);
   gDaxSym  = AutoDetectSymbol(InpDaxSymbol,  "DE30m,DE30,GER40m,GER40,DE40m,DE40", "DE30m");
   gGoldSym = AutoDetectSymbol(InpGoldSymbol, "XAUUSDm,XAUUSD,XAUUSDc,GOLD", "XAUUSDm");
   gBtcSym  = AutoDetectSymbol(InpBtcSymbol,  "BTCUSDm,BTCUSD,BTCUSDc", "BTCUSDm");

   PrintFormat("Exness_SMC_Bridge v2 initialized | URL=%s | Symbols: DAX=%s, GOLD=%s, BTC=%s",
               InpServerUrl, gDaxSym, gGoldSym, gBtcSym);
   if (!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED))
      Print("WARNING: Top toolbar 'Algo Trading' is OFF! Click Algo Trading to enable orders.");

   EventSetTimer(InpPollSecs);
   SendHeartbeat();
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason) { EventKillTimer(); }

void OnTimer() {
   SendHeartbeat();
   PollCommands();
}

void ReportWebRequestError(string step, int code) {
   int err = GetLastError();
   if (err == gLastErrCode && code == -1) return;
   gLastErrCode = err;
   gConnectedOnce = false;
   if (err == 4014 || err == 4060) {
      PrintFormat("EXNESS BRIDGE ERROR [%s]: WebRequest blocked (err=%d). FIX: MT5 -> Tools -> Options -> Expert Advisors -> check 'Allow WebRequest for listed URL' and add: %s",
                  step, err, InpServerUrl);
   } else if (err == 5203 || code == -1) {
      PrintFormat("EXNESS BRIDGE ERROR [%s]: Cannot reach Sentinel app at %s (code=%d err=%d). Make sure Start_DAX_Sentinel_Windows.bat is running!",
                  step, InpServerUrl, code, err);
   } else {
      PrintFormat("EXNESS BRIDGE HTTP %d on %s (err=%d)", code, step, err);
   }
}

void SendHeartbeat() {
   double daxSp = SymbolInfoInteger(gDaxSym, SYMBOL_SPREAD) * SymbolInfoDouble(gDaxSym, SYMBOL_POINT);
   double gldSp = SymbolInfoInteger(gGoldSym, SYMBOL_SPREAD) * SymbolInfoDouble(gGoldSym, SYMBOL_POINT);
   double btcSp = SymbolInfoInteger(gBtcSym, SYMBOL_SPREAD) * SymbolInfoDouble(gBtcSym, SYMBOL_POINT);
   string json = StringFormat(
      "{\"login\":%I64d,\"server\":\"%s\",\"balance\":%.2f,\"equity\":%.2f,\"dax_spread\":%.2f,\"gold_spread\":%.2f,\"btc_spread\":%.2f}",
      AccountInfoInteger(ACCOUNT_LOGIN), AccountInfoString(ACCOUNT_SERVER),
      AccountInfoDouble(ACCOUNT_BALANCE), AccountInfoDouble(ACCOUNT_EQUITY), daxSp, gldSp, btcSp
   );
   char post[], res[]; string hdrs;
   StringToCharArray(json, post, 0, StringLen(json));
   ResetLastError();
   int code = WebRequest("POST", InpServerUrl + "/api/bot/mt5-report", "Content-Type: application/json\r\n", 2000, post, res, hdrs);
   if (code == 200) {
      gLastErrCode = -999;
      if (!gConnectedOnce) {
         gConnectedOnce = true;
         PrintFormat("EXNESS BRIDGE CONNECTED! Account=%I64d | Server=%s | Balance=%.2f | Equity=%.2f",
                     AccountInfoInteger(ACCOUNT_LOGIN), AccountInfoString(ACCOUNT_SERVER),
                     AccountInfoDouble(ACCOUNT_BALANCE), AccountInfoDouble(ACCOUNT_EQUITY));
      }
   } else {
      ReportWebRequestError("HEARTBEAT", code);
   }
}

void PollCommands() {
   char post[], res[]; string hdrs;
   ResetLastError();
   int code = WebRequest("GET", InpServerUrl + "/api/bot/bridge/poll?single=1", "", 2000, post, res, hdrs);
   if (code != 200) {
      if (code != -1 || !gConnectedOnce) ReportWebRequestError("POLL", code);
      return;
   }
   string body = CharArrayToString(res);
   if (StringFind(body, "\"PLACE_MARKET\"") >= 0 || StringFind(body, "\"PLACE_LIMIT\"") >= 0 ||
       StringFind(body, "\"MODIFY_SL\"") >= 0 || StringFind(body, "\"PARTIAL_CLOSE\"") >= 0 ||
       StringFind(body, "\"CLOSE_POSITION\"") >= 0 || StringFind(body, "\"CANCEL_ORDER\"") >= 0) {
      Print("Bridge received command: ", body);
      ExecuteBridgePayload(body);
   }
}

string ExtractStr(string src, string key) {
   int p = StringFind(src, "\"" + key + "\":");
   if (p < 0) return "";
   int q1 = StringFind(src, "\"", p + StringLen(key) + 3);
   int q2 = StringFind(src, "\"", q1 + 1);
   if (q1 < 0 || q2 < 0) return "";
   return StringSubstr(src, q1 + 1, q2 - q1 - 1);
}

double ExtractNum(string src, string key) {
   int p = StringFind(src, "\"" + key + "\":");
   if (p < 0) return 0;
   int s = p + StringLen(key) + 3;
   while (s < StringLen(src) && (StringGetCharacter(src, s) == ' ' || StringGetCharacter(src, s) == ':')) s++;
   int e = s;
   while (e < StringLen(src)) {
      ushort ch = StringGetCharacter(src, e);
      if ((ch >= '0' && ch <= '9') || ch == '.' || ch == '-') e++; else break;
   }
   return StringToDouble(StringSubstr(src, s, e - s));
}

void ExecuteBridgePayload(string body) {
   string cmdType = ExtractStr(body, "type");
   string rawSym  = ExtractStr(body, "symbol");
   string sym     = ResolveOrderSymbol(rawSym);
   string dir     = ExtractStr(body, "direction");
   string comment = ExtractStr(body, "order_id");
   double lots    = NormalizeDouble(ExtractNum(body, "lots"), 2);
   double price   = ExtractNum(body, "price");
   double sl      = ExtractNum(body, "sl");
   double tp      = ExtractNum(body, "tp2");
   if (tp <= 0) tp = ExtractNum(body, "tp");

   SymbolSelect(sym, true);
   trade.SetTypeFillingBySymbol(sym);
   int digits = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);
   sl    = NormalizeDouble(sl, digits);
   tp    = NormalizeDouble(tp, digits);
   price = NormalizeDouble(price, digits);

   bool ok = false;
   if (cmdType == "PLACE_MARKET") {
      ok = (dir == "BUY" || dir == "LONG") ? trade.Buy(lots, sym, 0, sl, tp, comment) : trade.Sell(lots, sym, 0, sl, tp, comment);
   } else if (cmdType == "PLACE_LIMIT") {
      ok = (dir == "BUY" || dir == "LONG") ? trade.BuyLimit(lots, price, sym, sl, tp, ORDER_TIME_DAY, 0, comment) : trade.SellLimit(lots, price, sym, sl, tp, ORDER_TIME_DAY, 0, comment);
   } else if (cmdType == "MODIFY_SL") {
      for (int i = PositionsTotal() - 1; i >= 0; i--) {
         ulong tk = PositionGetTicket(i);
         if (PositionGetString(POSITION_SYMBOL) == sym) ok = trade.PositionModify(tk, sl, tp);
      }
   } else if (cmdType == "PARTIAL_CLOSE") {
      for (int i = PositionsTotal() - 1; i >= 0; i--) {
         ulong tk = PositionGetTicket(i);
         if (PositionGetString(POSITION_SYMBOL) == sym) ok = trade.PositionClosePartial(tk, lots);
      }
   } else if (cmdType == "CLOSE_POSITION") {
      for (int i = PositionsTotal() - 1; i >= 0; i--) {
         ulong tk = PositionGetTicket(i);
         if (PositionGetString(POSITION_SYMBOL) == sym) ok = trade.PositionClose(tk);
      }
   } else if (cmdType == "CANCEL_ORDER") {
      for (int i = OrdersTotal() - 1; i >= 0; i--) {
         ulong tk = OrderGetTicket(i);
         if (OrderGetString(ORDER_SYMBOL) == sym) ok = trade.OrderDelete(tk);
      }
   }
   PrintFormat("Executed %s on %s (raw=%s) -> ok=%s retcode=%d (%s)",
               cmdType, sym, rawSym, ok ? "true" : "false", trade.ResultRetcode(), trade.ResultRetcodeDescription());
}
