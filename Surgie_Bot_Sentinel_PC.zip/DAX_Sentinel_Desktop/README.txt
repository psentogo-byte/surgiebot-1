================================================================
DAX 40, GOLD (GC=F) & BITCOIN (BTC-USD) SENTINEL v6.0 — DESKTOP
================================================================

WHAT'S NEW: 3-ASSET SENTINEL (DAX 40 + GOLD + BTC) & REAL-TIME BOT
- Instant Instrument Switcher (DAX 40 | GOLD GC=F | BITCOIN BTC-USD):
  Switch seamlessly between DAX 40, Gold Futures, and Bitcoin across
  fundamental sentiment, SMC/IPDA, trade signals, backtest, and ledger.
- Dedicated Bitcoin (BTC-USD) Fundamental & 24/7 SMC Engine:
  Evaluates live EN+DE Spot ETF / BlackRock inflows, Fed liquidity & DXY,
  SEC/MiCA regulation, and On-Chain/Whale feeds (CoinDesk, Cointelegraph,
  BTC-ECHO DE, Google News) + BTC vs ETH-USD SMT divergence.
  BTC trades 24/7 (Asia Range, London Institutional, NY Spot ETF KZ).
- Dedicated Gold Fundamental Sentiment Engine (EN + DE):
  Evaluates live Fed Policy & Real Yields, US Dollar (DXY),
  Safe-Haven & Geopolitics, Central Bank / ETF Reserves, and
  Inflation/CPI feeds with Gold-specific polarity.
- Full Gold SMC / IPDA / Signal Suite:
  - 1H + 15m Multi-Timeframe Nesting & 20/40/60D IPDA Lookbacks
  - Gold vs Silver (SI=F) & S&P 500 SMT Divergence
  - Gold Intermarket Triad (DXY + US 10Y + VIX)
  - 14D ADR Exhaustion, News Blackout & Killzone Gates
  - Gold Trade Signals (Entry, SL, TP1-TP3, R:R) + Position Sizer
  - Separate 5-Day Causal Walk-Forward Backtest & Signal Ledger
- Includes all DAX 40 v1-v6 features (Bilingual EN/DE feeds,
  12 Cross-Assets, 20-Stock Breadth & Sector Heatmap, Power of 3,
  OTE, SD Targets, IFVGs, Breakers/Unicorns, Catalyst Calendar,
  Desktop Alerts, Export .MD/.CSV & optional AI Deep-Dive).

REAL-TIME SMC EXECUTION BOT & EXNESS MT5 BRIDGE
- Built-in Real-Time Bot (20-second quote/trade management loop):
  Runs safely in PAPER mode by default so you can verify live signals,
  partial closes, and breakeven protection risk-free before going live.
- Institutional Pre-Flight Gates:
  - London / NY Killzone enforcement (blocks Deadzones)
  - News Blackout guard around high-impact ECB / Fed / CPI catalysts
  - 14D ADR Exhaustion guard & live Exness Spread gate
  - Minimum Confluence % + Minimum R:R gate + 0.01-lot risk sizing
  - Daily Max Drawdown Circuit Breaker + Max Daily Trades cap
  - Auto 50% TP1 Partial Close + Stop Loss moved to Breakeven
  - Emergency "KILL SWITCH" button (flattens all + pauses bot)

HOW TO CONNECT TO EXNESS METATRADER 5 (WINDOWS)
Option A — Python MT5 Bridge (Recommended for Exness):
  1. Open & log into your Exness MetaTrader 5 Terminal on Windows.
  2. Install dependencies once:  pip install MetaTrader5 requests
  3. Start DAX Sentinel (port 8765), then run:  python exness_mt5_worker.py
  4. In the web UI Execution Bot bar, switch Mode to "Exness MT5 Bridge",
     verify your Exness symbol names (e.g. DE30m / XAUUSDm / BTCUSDm),
     click "Apply Rules", and press "Start Bot".

Option B — Native MQL5 Expert Advisor (Exness_SMC_Bridge.mq5):
  1. In MT5: Tools -> Options -> Expert Advisors -> Allow WebRequest for:
     http://127.0.0.1:8765
  2. Copy Exness_SMC_Bridge.mq5 into MQL5\Experts\, compile in MetaEditor,
     and attach it to any chart (Algo Trading enabled).

*Disclaimer: Trade signals, backtests, and automated execution carry risk.
Always test in PAPER mode or an Exness Demo account before live trading.*

HOW TO RUN ON YOUR PC (ZERO INSTALLATION REQUIRED)
1. Unzip DAX_Sentinel_PC.zip onto your Desktop.
2. Double-click the launcher for your system:
   - Windows:  Start_DAX_Sentinel_Windows.bat
   - Mac:      Start_DAX_Sentinel_Mac.command
   - Linux:    ./Start_DAX_Sentinel_Linux.sh
================================================================
