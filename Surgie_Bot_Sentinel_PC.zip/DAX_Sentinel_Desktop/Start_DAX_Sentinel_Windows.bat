@echo off
title DAX 40 Fundamental Sentinel
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
    echo Starting DAX Fundamental Sentinel...
    py -3 dax_sentinel_desktop.py
    goto :end
)

where python >nul 2>nul
if %errorlevel%==0 (
    echo Starting DAX Fundamental Sentinel...
    python dax_sentinel_desktop.py
    goto :end
)

where python3 >nul 2>nul
if %errorlevel%==0 (
    echo Starting DAX Fundamental Sentinel...
    python3 dax_sentinel_desktop.py
    goto :end
)

echo.
echo Python 3 was not found on your PC.
echo Attempting to open Microsoft Store / Winget Python installer...
where winget >nul 2>nul
if %errorlevel%==0 (
    winget install -e --id Python.Python.3.12 --accept-source-agreements --accept-package-agreements
    if %errorlevel%==0 (
        echo Python installed! Please double-click this file again.
        pause
        exit /b 0
    )
)
echo Please install Python 3 from https://www.python.org/downloads/ (check "Add Python to PATH") and double-click this file again.
start https://www.python.org/downloads/
pause

:end
